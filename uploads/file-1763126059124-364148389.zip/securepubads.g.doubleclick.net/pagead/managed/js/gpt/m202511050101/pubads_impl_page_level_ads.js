window.googletag && typeof googletag._gpt_js_load_2_ == 'function' && googletag._gpt_js_load_2_(function(_, _m) {
    var lna = function(a) {
            var b = _.jc;
            if (!(0, _.Hi)(a)) {
                var c, d;
                b = (d = (c = typeof b === "function" ? b() : b) == null ? void 0 : c.concat("\n")) != null ? d : "";
                throw Error(b + String(a));
            }
            return a
        },
        mna = function(a) {
            a.preventDefault ? a.preventDefault() : a.returnValue = !1
        },
        i4 = function(a) {
            if (!nna.test(a)) return null;
            a = Number(a);
            return isNaN(a) ? null : a
        },
        ona = function(a, b) {
            return a && a.source ? a.source === b || a.source.parent === b : !1
        },
        k4 = function(a) {
            var b = {
                bottom: "auto",
                clear: "none",
                display: "inline",
                "float": "none",
                height: "auto",
                left: "auto",
                margin: 0,
                "margin-bottom": 0,
                "margin-left": 0,
                "margin-right": "0",
                "margin-top": 0,
                "max-height": "none",
                "max-width": "none",
                opacity: 1,
                overflow: "visible",
                padding: 0,
                "padding-bottom": 0,
                "padding-left": 0,
                "padding-right": 0,
                "padding-top": 0,
                position: "static",
                right: "auto",
                top: "auto",
                "vertical-align": "baseline",
                visibility: "visible",
                width: "auto",
                "z-index": "auto"
            };
            _.ik(_.v(Object, "keys").call(Object, b), function(c) {
                var d = a.style[_.gF(c)];
                (typeof d !== "undefined" ? d : a.style[_.MH(a, c)]) || _.dn(a, c, b[c])
            });
            j4(a)
        },
        l4 = function(a, b, c, d) {
            d = d === void 0 ? null : d;
            var e = function(g) {
                try {
                    var h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            _.bh(a, "message", e);
            var f = !1;
            return function() {
                var g = !1;
                f || (f = !0, g = _.ch(a, "message", e));
                return g
            }
        },
        m4 = function(a, b, c, d) {
            c.googMsgType = b;
            a.postMessage(JSON.stringify(c), d)
        },
        n4 = function(a, b, c, d, e) {
            if (!(e <= 0) && (m4(a, b, c, d), a = a.frames))
                for (var f = 0; f < a.length; ++f) e > 1 && n4(a[f], b, c, d, --e)
        },
        o4 = function(a) {
            var b = a.screen.height === 812 && a.screen.width === 375 || a.screen.width === 812 && a.screen.height === 375 || a.screen.width === 414 && a.screen.height === 896 || a.screen.width === 896 && a.screen.height === 414;
            return (a.navigator && a.navigator.userAgent && a.navigator.userAgent.match(/iPhone OS 1[1-9]|[2-9]\d/)) != null && b
        },
        p4 = function(a, b) {
            a = a.getComputedStyle(b);
            return b.offsetWidth > 0 && b.offsetHeight > 0 && a.display !== "none" && a.visibility !== "hidden" && a.opacity !== "0"
        },
        qna = function(a, b) {
            var c = c === void 0 ? pna : c;
            return p4(a, b) && c.some(function(d) {
                var e;
                return (e = b.src) == null ? void 0 : _.v(e, "includes").call(e, d)
            })
        },
        rna = function(a) {
            return _.v(Array, "from").call(Array, a.document.querySelectorAll("video")).some(function(b) {
                return p4(a, b) && !(!b.currentSrc && !b.src)
            }) || _.v(Array, "from").call(Array, a.document.querySelectorAll("iframe")).some(function(b) {
                return qna(a, b)
            })
        },
        r4 = function(a, b, c, d) {
            if (!(a.nodeName in sna))
                if (a.nodeType === 3) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
                else if (a.nodeName in q4) d && a.nodeName === "IMG" && a.hasAttribute("alt") && b.push(" " + a.getAttribute("alt")), b.push(q4[a.nodeName]);
            else
                for (a = a.firstChild; a;) r4(a, b, c, d), a = a.nextSibling
        },
        tna = function(a) {
            var b = new _.y.Set;
            a.forEach(function(c) {
                switch (c) {
                    case 1:
                        b.add(1);
                        break;
                    case 2:
                        b.add(2);
                        break;
                    case 3:
                        b.add(3);
                        break;
                    case 5:
                        b.add(5);
                        break;
                    case 6:
                        b.add(6);
                        break;
                    case 7:
                        b.add(7);
                        break;
                    case 8:
                        b.add(8);
                        break;
                    case 9:
                        b.add(9);
                        break;
                    case 10:
                        b.add(10);
                        break;
                    case 11:
                        b.add(11)
                }
            });
            return b
        },
        una = function(a) {
            switch (a) {
                case 1:
                    return 1;
                case 2:
                    return 2;
                case 3:
                    return 3;
                case 5:
                    return 5;
                case 6:
                    return 6;
                case 7:
                    return 7;
                case 8:
                    return 8;
                case 9:
                    return 9;
                case 10:
                    return 10;
                case 11:
                    return 11;
                default:
                    return 0
            }
        },
        vna = function(a, b, c, d) {
            return l4(a, "fullscreen", d.Qa(952, function(e, f) {
                if (f.source === b) {
                    if (!("eventType" in e)) throw Error("bad message " + JSON.stringify(e));
                    delete e.googMsgType;
                    c(e)
                }
            }))
        },
        wna = function(a, b, c, d, e) {
            a = new s4(1, a, b, c, d, e);
            a.init();
            return a
        },
        xna = function(a) {
            var b;
            a = ((b = a === void 0 ? null : a) != null ? b : window).googletag;
            return (a == null ? 0 : a.apiReady) ? a : void 0
        },
        Ana = function(a) {
            var b = yna(_.EH(_.BH(a))) || [];
            return !!_.ln(a, function(c) {
                if (!_.fb(c) || c.nodeType != 1) return !1;
                var d = c.matches || c.webkitMatchesSelector || c.mozMatchesSelector || c.msMatchesSelector || c.oMatchesSelector;
                return !d || _.bb(b, c) >= 0 || _.Fi(_.v(Object, "values").call(Object, zna), function(e) {
                    return d.call(c, e)
                })
            }, !1, 20)
        },
        yna = function(a) {
            var b = xna(a);
            return b ? _.Mm(_.eF(b.pubads().getSlots(), function(c) {
                return a.document.getElementById(c.getSlotElementId())
            }), function(c) {
                return c != null
            }) : null
        },
        t4 = function(a) {
            var b;
            (b = a.l) == null || b.setAttribute("data-vignette-loaded", "true")
        },
        u4 = function(a, b) {
            var c = a.ownerDocument,
                d = c.createElementNS("http://www.w3.org/2000/svg", "line");
            d.setAttribute("x1", b ? "32" : "22");
            d.setAttribute("y1", "18");
            d.setAttribute("x2", b ? "38" : "28");
            d.setAttribute("y2", "12");
            a.appendChild(d);
            c = c.createElementNS("http://www.w3.org/2000/svg", "line");
            c.setAttribute("x1", b ? "38" : "28");
            c.setAttribute("y1", "12");
            c.setAttribute("x2", b ? "44" : "34");
            c.setAttribute("y2", "18");
            a.appendChild(c)
        },
        v4 = function(a, b) {
            var c = a.ownerDocument,
                d = c.createElementNS("http://www.w3.org/2000/svg", "line");
            d.setAttribute("x1", b ? "32" : "22");
            d.setAttribute("y1", "12");
            d.setAttribute("x2", b ? "38" : "28");
            d.setAttribute("y2", "18");
            a.appendChild(d);
            c = c.createElementNS("http://www.w3.org/2000/svg", "line");
            c.setAttribute("x1", b ? "38" : "28");
            c.setAttribute("y1", "18");
            c.setAttribute("x2", b ? "44" : "34");
            c.setAttribute("y2", "12");
            a.appendChild(c)
        },
        w4 = function(a, b, c) {
            b !== null && i4(a.getAttribute("width")) !== null && a.setAttribute("width", String(b));
            c !== null && i4(a.getAttribute("height")) !== null && a.setAttribute("height", String(c));
            b !== null && (a.style.width = _.F_(b));
            c !== null && (a.style.height = _.F_(c))
        },
        Bna = function(a) {
            a = _.Ah(a);
            a = 100 * (a < 1 ? 1 : a);
            return {
                width: a + "vw",
                height: a + "vh"
            }
        },
        Cna = function(a, b, c, d) {
            if (!(b <= 0)) return function(e) {
                if (e >= b) return a.O({
                    J: 99
                }), !1;
                if ((0, _.Bh)() !== 0) return a.O({
                    J: 100
                }), !1;
                a: {
                    e = d;e = e === void 0 ? window : e;
                    if (_.Oi(c)) try {
                        var f = {
                            value: e.sessionStorage.getItem("lvtd")
                        };
                        break a
                    } catch (g) {
                        f = {
                            error: 1
                        };
                        break a
                    }
                    f = {
                        error: 0
                    }
                }
                e = f.value;
                if (f.error !== void 0) return a.O({
                    J: 101
                }), !1;
                e ? (f = Number(e), f = isNaN(f) ? !1 : Date.now() - f >= _.K(_.MW) * 60 * 1E3) : f = !0;
                if (!f) return a.O({
                    J: 102
                }), !1;
                f = Date.now().toString();
                e = d;
                e = e === void 0 ? window : e;
                if (_.Oi(c)) try {
                    e.sessionStorage.setItem("lvtd", f)
                } catch (g) {}
                return !0
            }
        },
        x4 = function(a) {
            this.o = _.C(a)
        };
    _.V(x4, _.D);
    x4.prototype.A = _.E(_.tS);
    var y4 = function(a) {
        this.o = _.C(a)
    };
    _.V(y4, _.D);
    y4.prototype.A = _.E(_.uS);
    _.n_.prototype.Pf = _.ca(4, function(a) {
        var b = this.g().Qq;
        if (_.cj(this.Z, b)) {
            var c = this.Da,
                d = c.ub,
                e = c.Tb,
                f = c.Ab,
                g = c.Oe,
                h = c.qa,
                k = a.rh,
                l = a.st;
            a = this.G;
            c = a.ik;
            b = _.mS(_.pS(_.oS(b), this.j++));
            e = _.aA(b, 11, e);
            d = _.qS(_.nS(_.lS(_.Zz(e, 8, d), _.mj(_.nj([f]))), g), h());
            f = new y4;
            k = _.aA(f, 2, k);
            f = new x4;
            l = _.Rk(f, 1, l);
            l = _.Ge(l);
            l = _.Gl(k, 1, l);
            l = _.Ge(l);
            l = _.zj(d, 6, _.rS, l);
            c.call(a, _.Ge(l))
        }
    });
    _.UD.prototype.Pf = _.ca(3, function(a) {
        this.g.Pf(a)
    });
    var z4 = function(a, b, c, d) {
            d = d === void 0 ? !1 : d;
            if (!a.La) {
                a.La = [];
                for (var e = a.j.parentElement; e;) {
                    a.La.push(e);
                    if (a.l === e) break;
                    e = e.parentNode && e.parentNode.nodeType === 1 ? e.parentNode : null
                }
            }
            e = a.La.slice();
            !c && a.l === e[e.length - 1] && e.pop();
            var f;
            if (d)
                for (c = e.length - 1; c >= 0; --c)(f = e[c]) && b.call(a, f, c, e);
            else
                for (c = 0; c < e.length; ++c)(f = e[c]) && b.call(a, f, c, e)
        },
        A4 = function(a, b) {
            return new _.Yk(a.x - b.x, a.y - b.y)
        },
        Dna = function(a) {
            var b = a.document,
                c = 0;
            if (b) {
                c = b.body;
                var d = b.documentElement;
                if (!d || !c) return 0;
                a = _.Vk(a).height;
                if (b.compatMode == "CSS1Compat" && d.scrollHeight) c = d.scrollHeight != a ? d.scrollHeight : d.offsetHeight;
                else {
                    b = d.scrollHeight;
                    var e = d.offsetHeight;
                    d.clientHeight != e && (b = c.scrollHeight, e = c.offsetHeight);
                    c = b > a ? b > e ? b : e : b < e ? b : e
                }
            }
            return c
        },
        B4 = function(a) {
            if (a.nodeType == 1) return _.SH(a);
            a = a.changedTouches ? a.changedTouches[0] : a;
            return new _.Yk(a.clientX, a.clientY)
        },
        C4 = function(a, b) {
            if (b instanceof _.Uk) {
                var c = b.height;
                b = b.width
            } else throw Error("missing height argument");
            a.style.width = _.TH(b, !0);
            _.UH(a, c)
        },
        D4 = function(a, b) {
            var c = _.OH(a, b + "Left"),
                d = _.OH(a, b + "Right"),
                e = _.OH(a, b + "Top");
            a = _.OH(a, b + "Bottom");
            return new _.Zg(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c))
        },
        E4 = {
            capture: !0
        },
        nna = /^(-?[0-9.]{1,30})$/,
        Ena = function(a, b) {
            for (a = [a]; a.length;) {
                var c = a.shift();
                b(c) !== !1 && (c = _.Mm(c.children || c.childNodes || [], function(d) {
                    return d.nodeType === 1
                }), c.length && a.unshift.apply(a, _.sm(c)))
            }
        },
        Fna = function(a) {
            var b = {};
            if (a) {
                var c = /\s*:\s*/;
                _.ik((a || "").split(/\s*;\s*/), function(d) {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d && e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        Gna = function(a, b) {
            if ("length" in a.style) {
                a = a.style;
                for (var c = a.length, d = 0; d < c; d++) {
                    var e = a[d];
                    b(a[e], e, a)
                }
            } else a = Fna(a.style.cssText), _.Ch(a, b)
        },
        j4 = function(a, b) {
            b = b === void 0 ? function() {
                return !0
            } : b;
            var c = /!\s*important/i;
            Gna(a, function(d, e) {
                !c.test(d) && b(e, d) ? a.style.setProperty(e, d, "important") : c.test(d) && !b(e, d) && a.style.setProperty(e, d, "")
            })
        },
        Hna = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        Ina = /.*domain\.test$/,
        Jna = /\.prod\.google\.com(:\d+)?$/,
        F4 = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            _.mY.call(this);
            this.F = a;
            this.Bh = c;
            this.W = this.ga = this.I = this.H = this.B = !1;
            this.Ra = null;
            this.va = 0;
            this.P = null;
            if (_.gn(a))
                for (a = _.x(b), b = a.next(); !b.done; b = a.next()) switch (b.value) {
                    case 0:
                        Kna(this);
                        break;
                    case 1:
                        Lna(this);
                        break;
                    case 2:
                        Mna(this);
                        break;
                    case 3:
                        Nna(this);
                        break;
                    case 4:
                        Ona(this);
                        break;
                    case 5:
                        Pna(this);
                        break;
                    case 6:
                        Qna(this)
                } else this.dispose()
        };
    _.V(F4, _.mY);
    F4.prototype.init = function() {
        this.M || this.g(_.gn(this.F))
    };
    var Kna = function(a) {
            var b = function(d) {
                    d.isTrusted && (a.H = !0, a.g(d.timeStamp))
                },
                c = function(d) {
                    d.isTrusted && (a.H = !1, a.g(d.timeStamp))
                };
            _.bh(a.F, "focus", b);
            _.bh(a.F, "blur", c);
            _.dv(a, function() {
                return void a.F.removeEventListener("focus", b)
            });
            _.dv(a, function() {
                return void a.F.removeEventListener("blur", c)
            });
            a.H = a.F.document.hasFocus()
        },
        Lna = function(a) {
            var b = function(c) {
                c.isTrusted && (a.B = _.fl(a.F.document) === 1 ? !0 : !1, a.g(c.timeStamp))
            };
            _.bh(a.F.document, "visibilitychange", b);
            _.dv(a, function() {
                return void a.F.document.removeEventListener("visibilitychange", b)
            });
            a.B = _.fl(a.F.document) === 1
        },
        Mna = function(a) {
            var b = a.F.document.body.getBoundingClientRect().top + 10,
                c = function(d) {
                    d.isTrusted && (a.I = d.clientY < b ? !0 : !1, a.g(d.timeStamp))
                };
            _.bh(a.F.document.body, "mouseleave", c);
            _.bh(a.F.document.body, "mouseenter", c);
            _.dv(a, function() {
                return void a.F.document.body.removeEventListener("mouseleave", c)
            });
            _.dv(a, function() {
                return void a.F.document.body.removeEventListener("mouseenter", c)
            });
            a.I = !1
        },
        Nna = function(a) {
            var b = a.F.document.querySelectorAll("article");
            if (b.length) {
                var c = new IntersectionObserver(function(e) {
                    e = _.x(e);
                    for (var f = e.next(); !f.done; f = e.next()) f = f.value, f.boundingClientRect.bottom <= a.F.innerHeight && (a.Ra = f.target, a.g(f.time), c.unobserve(f.target))
                }, {
                    root: null,
                    threshold: _.zfa
                });
                b = _.x(b);
                for (var d = b.next(); !d.done; d = b.next()) c.observe(d.value);
                _.dv(a, function() {
                    return void c.disconnect()
                })
            }
        },
        Ona = function(a) {
            var b = a.F.scrollY,
                c = function(d) {
                    d.isTrusted && (a.va = a.F.scrollY - b, b = a.F.scrollY, a.g(d.timeStamp, {
                        event: d
                    }))
                };
            _.bh(a.F, "scroll", c);
            _.dv(a, function() {
                return void a.F.removeEventListener("scroll", c)
            })
        },
        Pna = function(a) {
            var b = a.F.navigation;
            if (b && (_.va() || _.ta() || _.sa()) && !b.canGoForward) {
                var c = function(d) {
                    var e = function() {
                        a.ga = !0;
                        a.g(d.timeStamp, {
                            event: d
                        })
                    };
                    if (d.navigationType === "traverse")
                        if (a.Bh) try {
                            d.intercept({
                                handler: function() {
                                    return _.fh(function(f) {
                                        e();
                                        f.g = 0
                                    })
                                }
                            })
                        } catch (f) {} else d.intercept({
                            handler: function() {
                                return _.fh(function(f) {
                                    e();
                                    f.g = 0
                                })
                            }
                        });
                        else d.destination.url === a.F.location.href && d.intercept({
                            handler: function() {
                                return _.fh(function(f) {
                                    f.g = 0
                                })
                            }
                        })
                };
                _.bh(b, "navigate", c);
                _.dv(a, function() {
                    return void b.removeEventListener("navigate", c)
                });
                a.Bh || (history.pushState({}, "", a.F.location.href), a.W = !0)
            }
        },
        Qna = function(a) {
            var b = a.F.navigation;
            if (b && (_.va() || _.ta() || _.sa())) {
                var c = function(d) {
                    d.formData || d.sourceElement && d.sourceElement.tagName === "A" || d.destination.url === a.F.location.href || !d.canIntercept || (a.P = a.F.location.href, d.intercept({
                        handler: function() {
                            return _.fh(function(e) {
                                a.g(d.timeStamp, {
                                    event: d
                                });
                                b.removeEventListener("navigate", c);
                                e.g = 0
                            })
                        }
                    }))
                };
                _.bh(b, "navigate", c);
                _.dv(a, function() {
                    return void b.removeEventListener("navigate", c)
                })
            }
        },
        G4 = function() {
            F4.apply(this, arguments);
            this.oa = new _.kl;
            this.j = this.oa.promise
        };
    _.V(G4, F4);
    var H4 = function(a, b) {
            a.oa.resolve(b);
            a.dispose()
        },
        I4 = function(a, b) {
            G4.call(this, a, [5], b === void 0 ? !1 : b);
            this.init()
        };
    _.V(I4, G4);
    I4.prototype.g = function(a) {
        this.ga && H4(this, a)
    };
    var J4 = function(a, b, c) {
        c = c === void 0 ? null : c;
        _.mY.call(this);
        this.F = a;
        this.Ha = b;
        this.localStorage = c;
        this.j = [];
        this.g = this.Ic = this.button = null
    };
    _.V(J4, _.mY);
    J4.prototype.listen = function(a) {
        Rna(this);
        this.j.push(a)
    };
    var Rna = function(a) {
            if (a.Ha.Um()) {
                var b = a.F.scrollY + a.F.innerHeight,
                    c = a.F.document.documentElement.scrollHeight - b;
                a.button = _.gk(a.F, b + a.Ha.fk, a.F.innerWidth / 2, a.Ha.cv, a.Ha.bp);
                a.Ic = _.hk(a.F, b, c, {
                    "webkit-mask-image": "linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 5px, rgba(0, 0, 0, 1) " + a.Ha.fk + "px, rgba(0, 0, 0, 1) 100%)",
                    "webkit-mask-repeat": "no-repeat",
                    "webkit-mask-size": "cover",
                    "mask-image": "linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 5px, rgba(0, 0, 0, 1) " + a.Ha.fk + "px, rgba(0, 0, 0, 1) 100%)",
                    "mask-repeat": "no-repeat",
                    "mask-size": "cover"
                });
                a.g = new _.NY(a.F, a.F.scrollY + a.Ha.bp + a.Ha.fk + a.Ha.uv);
                a.F.document.body.appendChild(a.button);
                a.F.document.body.appendChild(a.Ic);
                a.g.start();
                var d = new IntersectionObserver(function(f) {
                    f = _.x(f);
                    for (var g = f.next(); !g.done; g = f.next()) g.value.isIntersecting && (_.$Z(_.c_(), a.localStorage, a.Ha.av), d.disconnect())
                }, {
                    root: null,
                    threshold: 0
                });
                d.observe(a.button);
                var e = function() {
                    K4(a);
                    for (var f = {
                            bf: a.F.performance.now()
                        }, g = _.x(a.j), h = g.next(); !h.done; h = g.next()) {
                        h = h.value;
                        try {
                            h(f)
                        } catch (k) {}
                    }
                };
                a.button.addEventListener("click", e);
                _.dv(a, function() {
                    K4(a);
                    var f;
                    (f = a.button) == null || f.removeEventListener("click", e)
                })
            }
        },
        K4 = function(a) {
            var b;
            (b = a.button) == null || b.remove();
            var c;
            (c = a.Ic) == null || c.remove();
            var d;
            (d = a.g) == null || d.stop()
        },
        L4 = function(a, b, c, d, e) {
            G4.call(this, a, [4]);
            this.ya = b;
            this.La = c;
            this.L = 0;
            this.ha = null;
            this.l = [];
            var f = a.document.body.scrollHeight;
            f < a.innerHeight ? this.dispose() : (b = a.document.querySelectorAll("article"), d && b.length !== 1 ? this.dispose() : (this.l = [].concat(_.sm(b)).filter(function(g) {
                g = g.getBoundingClientRect();
                var h = g.top,
                    k = g.bottom;
                return k > 0 && k < a.innerHeight && h > 0 ? !1 : g.height / f >= e
            }), this.l.length === 0 ? this.dispose() : this.init()))
        };
    _.V(L4, G4);
    L4.prototype.g = function(a) {
        var b = this;
        switch (this.L) {
            case 0:
                for (var c = _.x(this.l), d = c.next(); !d.done; d = c.next()) d = d.value.getBoundingClientRect().bottom, d > 0 && d < this.F.innerHeight && (this.ha = setTimeout(function() {
                    H4(b, a + b.ya)
                }, this.ya), this.L = 1);
                break;
            case 1:
                this.va > -this.La || (clearTimeout(this.ha), H4(this, a))
        }
    };
    var pna = "youtube.com youtube-nocookie.com vimeo.com dailymotion.com twitch.tv kick.com rumble.com".split(" "),
        M4 = ["mousemove", "mousedown", "scroll", "keydown"],
        N4 = function(a, b) {
            _.mY.call(this);
            var c = this;
            this.F = a;
            this.dj = b;
            this.g = [];
            this.j = _.Ex(function() {
                Sna(c)
            })
        };
    _.V(N4, _.mY);
    N4.prototype.listen = function(a) {
        this.j();
        this.g.push(a)
    };
    var Sna = function(a) {
            for (var b = null, c = null, d = function(l) {
                    if (b && l.timeStamp - b > a.dj) {
                        if (rna(a.F)) {
                            a.dispose();
                            return
                        }
                        for (var n = {
                                bf: l.timeStamp,
                                Hq: l.timeStamp - b,
                                It: c
                            }, m = _.x(a.g), p = m.next(); !p.done; p = m.next()) {
                            p = p.value;
                            try {
                                p(n)
                            } catch (q) {}
                        }
                    }
                    b = l.timeStamp
                }, e = _.x(M4), f = e.next(); !f.done; f = e.next()) a.F.addEventListener(f.value, d);
            var g = null,
                h, k;
            ((h = a.F.navigator) == null ? 0 : h.userActivation) && ((k = a.F.performance) == null ? 0 : k.now) && (g = a.F.setInterval(function() {
                a.F.navigator.userActivation.isActive && (c = a.F.performance.now())
            }, 1E3));
            _.dv(a, function() {
                for (var l = _.x(M4), n = l.next(); !n.done; n = l.next()) a.F.removeEventListener(n.value, d);
                g && a.F.clearInterval(g)
            })
        },
        O4 = function(a, b) {
            return new N4(a, b === void 0 ? 3E4 : b)
        },
        P4 = function(a) {
            G4.call(this, a, [0, 1, 2]);
            this.l = 0;
            this.init()
        };
    _.V(P4, G4);
    P4.prototype.g = function(a) {
        var b = this;
        switch (this.l) {
            case 0:
                this.H && !this.I && (this.l = 1);
                break;
            case 1:
                if (!this.H && this.B && this.I) {
                    this.l = 2;
                    var c = setTimeout(function() {
                        b.g(a)
                    }, 200);
                    _.dv(this, function() {
                        return void clearTimeout(c)
                    })
                }
                break;
            case 2:
                !this.H && this.B && this.I ? H4(this, a) : this.l = 1
        }
    };
    var Q4 = function(a) {
        G4.call(this, a, [6]);
        this.init()
    };
    _.V(Q4, G4);
    Q4.prototype.g = function(a) {
        this.P !== null && H4(this, a)
    };
    var R4 = function(a) {
        _.mY.call(this);
        var b = this;
        this.F = a;
        this.g = [];
        this.j = _.Ex(function() {
            Tna(b)
        })
    };
    _.V(R4, _.mY);
    R4.prototype.listen = function(a) {
        this.j();
        this.g.push(a)
    };
    var Tna = function(a) {
            var b = !1,
                c = function(e) {
                    e.isTrusted && (b = !0)
                },
                d = function(e) {
                    var f = e.timeStamp;
                    if (e = e.isTrusted && !b) e = (e = a.F.document.referrer) && typeof URL === "function" ? (new URL(e)).origin === a.F.location.origin : !1;
                    if (e) {
                        f = {
                            bf: f
                        };
                        e = _.x(a.g);
                        for (var g = e.next(); !g.done; g = e.next()) {
                            g = g.value;
                            try {
                                g(f)
                            } catch (h) {}
                        }
                    }
                };
            a.F.addEventListener("focus", d);
            a.F.addEventListener("blur", c);
            _.dv(a, function() {
                a.F.removeEventListener("focus", d);
                a.F.removeEventListener("blur", c)
            })
        },
        S4 = function(a, b) {
            G4.call(this, a, []);
            this.Um = b;
            this.init()
        };
    _.V(S4, G4);
    S4.prototype.g = function(a) {
        this.Um(a) && H4(this, a)
    };
    var T4 = function(a, b, c, d) {
        b = b === void 0 ? 250 : b;
        c = c === void 0 ? 1 : c;
        d = d === void 0 ? 2 : d;
        G4.call(this, a, [4]);
        this.Yj = b;
        this.Zm = c;
        this.bn = d;
        this.L = null;
        this.l = [];
        (0, _.Bh)() === 0 ? this.ha = c * this.F.innerHeight : this.ha = d * this.F.innerHeight;
        this.l.push({
            scrollY: this.F.scrollY,
            time: _.gn(this.F)
        });
        this.init()
    };
    _.V(T4, G4);
    T4.prototype.g = function(a, b) {
        var c = this;
        if (b != null && b.event && (this.l.push({
                scrollY: this.F.scrollY,
                time: a
            }), !(this.l.length < 2))) {
            b = this.l.length - 2;
            var d = this.l[b],
                e = this.l[this.l.length - 1];
            for (this.L && clearTimeout(this.L); e.time - d.time <= 1E3;) {
                if (Math.abs(e.scrollY - d.scrollY) > this.ha) {
                    this.L = setTimeout(function() {
                        H4(c, a)
                    }, this.Yj);
                    break
                }
                if (--b < 0) break;
                d = this.l[b]
            }
        }
    };
    var U4 = function(a) {
        G4.call(this, a, [1]);
        this.init()
    };
    _.V(U4, G4);
    U4.prototype.g = function(a) {
        this.l != null || (this.l = 0);
        switch (this.l) {
            case 0:
                this.B && (this.l = 1);
                break;
            case 1:
                this.B || (this.l = 2, this.ha = a);
                break;
            case 2:
                this.B && (this.L = a - this.ha, H4(this, a))
        }
    };
    var V4 = function(a, b, c, d, e) {
        e = e === void 0 ? null : e;
        _.mY.call(this);
        var f = this;
        this.j = !1;
        this.g = void 0;
        c.promise.then(function() {
            return void f.dispose()
        });
        b = _.x(b);
        for (var g = b.next(), h = {}; !g.done; h = {
                hc: void 0
            }, g = b.next()) switch (h.hc = g.value, h.hc) {
            case 2:
                g = new U4(a);
                _.uC(this, g);
                g.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 3:
                if ((0, _.Bh)() !== 0) break;
                g = new P4(a);
                _.uC(this, g);
                g.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 4:
                g = new R4(a);
                _.uC(this, g);
                g.listen(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 5:
                g = O4(a, d.dj);
                _.uC(this, g);
                g.listen(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 6:
                g = void 0;
                var k = new L4(a, d.Qp, d.Op, d.Pp, (g = d.Np) != null ? g : -1);
                _.uC(this, k);
                k.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 7:
                g = new T4(a, d.Yj, d.Zm, d.bn);
                _.uC(this, g);
                g.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 8:
                g = new S4(a, d.Xr);
                _.uC(this, g);
                g.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 9:
                g = void 0;
                k = new I4(a, (g = d.Bh) != null ? g : !1);
                _.uC(this, k);
                k.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                this.j = k.W;
                break;
            case 10:
                this.g = new Q4(a);
                _.uC(this, this.g);
                this.g.j.then(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h));
                break;
            case 11:
                g = new J4(a, d.bv, e === void 0 ? null : e), _.uC(this, g), g.listen(function(l) {
                    return function() {
                        return void c.resolve(l.hc)
                    }
                }(h))
        }
    };
    _.V(V4, _.mY);
    var sna = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1,
            NOSCRIPT: 1
        },
        q4 = {
            IMG: " ",
            BR: "\n"
        },
        Una = / \xAD /g,
        Vna = /\xAD/g,
        Wna = /\u200B/g,
        Xna = / +/g,
        Yna = /^\s*/;
    var s4 = function(a, b, c, d, e, f) {
        _.mY.call(this);
        this.slotType = a;
        this.B = b;
        this.rl = c;
        this.sa = d;
        this.G = e;
        this.Ih = f;
        this.state = 1;
        this.qem = null;
        this.l = new _.kl;
        this.g = new _.kl;
        this.j = new _.kl
    };
    _.V(s4, _.mY);
    var Zna = function(a) {
            return _.fh(function(b) {
                return b.return(a.l.promise)
            })
        },
        $na = function(a) {
            return _.fh(function(b) {
                return b.return(a.g.promise)
            })
        },
        aoa = function(a) {
            return _.fh(function(b) {
                return b.return(a.j.promise)
            })
        };
    s4.prototype.init = function() {
        var a = this,
            b = vna(this.B, this.rl, function(c) {
                if (c.eventType === "adError") a.j.resolve(), a.state = 4;
                else if (c.eventType === "adReady" && a.state === 1) a.qem = c.qem, c.slotType !== a.slotType && (W4(a, {
                    cur_st: a.state,
                    evt: c.eventType,
                    adp_tp: c.slotType
                }), a.state = 4), a.l.resolve(), a.state = 2;
                else if (c.eventType === "adClosed" && a.state === 2) a.g.resolve(c.result), a.state = 3;
                else if (c.eventType !== "adClosed" || a.state !== 3) c.eventType === "adClosed" && c.closeAfterError && (a.g.resolve(c.result), a.state = 3), W4(a, {
                    cur_st: a.state,
                    evt: c.eventType
                }), a.state = 4
            }, this.sa);
        _.dv(this, b)
    };
    var W4 = function(a, b) {
        var c = .25;
        c = c === void 0 ? .01 : c;
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = c;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.Ih.ft;
        b.version = a.Ih.version;
        _.an(a.G, "fullscreen_tag", b, !1, c)
    };
    var zna = {
        Pt: "ins.adsbygoogle-ablated-ad-slot",
        Rt: "body ins.adsbygoogle",
        Qt: "iframe[id^=aswift_],iframe[id^=google_ads_frame]",
        du: ".google-auto-placed",
        eu: "ins.adsbygoogle[data-anchor-status]",
        gu: "iframe[id^=google_ads_iframe]",
        lu: "div[id^=div-gpt-ad]",
        Cu: "ins.adsbygoogle[data-ad-format=autorelaxed]",
        Du: "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]",
        ku: "div.googlepublisherpluginad",
        Mu: "html > ins.adsbygoogle",
        fu: "div.autors-widget"
    };
    var Z4 = function(a, b) {
        var c = this;
        this.bd = a;
        this.j = !1;
        this.g = b.Qa(264, function(d) {
            c.j && (X4 || (d = Date.now()), c.bd(d), X4 ? Y4.call(_.ja, c.g) : _.ja.setTimeout(c.g, 17))
        })
    };
    Z4.prototype.start = function() {
        this.j || (this.j = !0, X4 ? Y4.call(_.ja, this.g) : this.g(0))
    };
    Z4.prototype.stop = function() {
        this.j = !1
    };
    var Y4 = _.ja.requestAnimationFrame || _.ja.webkitRequestAnimationFrame,
        X4 = !!Y4 && !/'iPhone'/.test(_.ja.navigator.userAgent);
    var $4 = function(a, b, c, d) {
        var e = this;
        this.start = a;
        this.end = b;
        this.time = c;
        this.progress = 0;
        this.startTime = null;
        this.j = !1;
        this.g = [];
        this.l = null;
        this.K = new Z4(function(f) {
            if (e.j) e.K.stop();
            else {
                e.startTime === null && (e.startTime = f);
                e.progress = (f - e.startTime) / e.time;
                e.progress >= 1 && (e.progress = 1);
                f = e.l ? e.l(e.progress) : e.progress;
                e.g = [];
                for (var g = 0; g < e.start.length; g++) e.g.push((e.end[g] - e.start[g]) * f + e.start[g]);
                e.H();
                e.progress === 1 && (e.K.stop(), e.M())
            }
        }, d)
    };
    $4.prototype.M = function() {};
    $4.prototype.H = function() {};
    var a5 = function(a) {
        a.j = !1;
        a.K.start()
    };
    $4.prototype.stop = function() {
        this.j = !0
    };
    $4.prototype.reset = function(a, b, c) {
        this.startTime = null;
        this.start = a;
        this.end = b;
        this.time = c;
        this.progress = 0
    };
    var boa = function(a) {
            return a * a * a
        },
        b5 = function(a) {
            a = 1 - a;
            return 1 - a * a * a
        };
    var c5 = function(a, b, c, d, e, f, g, h, k) {
        g = g === void 0 ? null : g;
        h = h === void 0 ? null : h;
        k = k === void 0 ? !1 : k;
        $4.call(this, [b], [c], d, f);
        this.element = a;
        this.I = e;
        this.B = g;
        this.l = h;
        this.wf = k && d === 0
    };
    _.V(c5, $4);
    c5.prototype.H = function() {
        this.wf && _.dn(this.element, "display", "none");
        var a = {};
        a[this.I] = _.F_(this.g[0]);
        _.dn(this.element, a)
    };
    c5.prototype.M = function() {
        this.wf && _.dn(this.element, "display", "block");
        this.B && this.B()
    };
    var d5 = function(a) {
        _.mY.call(this);
        var b = new _.kl,
            c = b.resolve;
        this.promise = b.promise;
        a.onmessage = function() {
            return c()
        };
        _.dv(this, function() {
            a.close()
        })
    };
    _.V(d5, _.mY);
    var coa = function() {
        var a = new _.kl,
            b = a.resolve;
        return {
            Vs: function(c, d) {
                d != null && d.ports.length && b(new d5(d.ports[0]))
            },
            Us: a.promise
        }
    };
    var e5 = function(a) {
        _.mY.call(this);
        var b = this;
        this.F = a;
        this.g = [];
        this.j = _.Ex(function() {
            doa(b)
        })
    };
    _.V(e5, _.mY);
    e5.prototype.listen = function(a) {
        this.j();
        this.g.push(a)
    };
    var doa = function(a) {
        var b = null,
            c = function(e) {
                e.isTrusted && (b = e.timeStamp)
            },
            d = function(e) {
                var f = e.timeStamp;
                if (e.isTrusted) {
                    e = _.v(Object, "assign").call(Object, {}, {
                        bf: f
                    }, b ? {
                        jt: f - b
                    } : null);
                    f = _.x(a.g);
                    for (var g = f.next(); !g.done; g = f.next()) {
                        g = g.value;
                        try {
                            g(e)
                        } catch (h) {}
                    }
                }
            };
        a.F.addEventListener("focus", d);
        a.F.addEventListener("blur", c);
        _.dv(a, function() {
            a.F.removeEventListener("focus", d);
            a.F.removeEventListener("blur", c)
        })
    };
    var f5 = function(a, b, c, d, e, f) {
        _.mY.call(this);
        var g = this;
        this.G = c;
        this.g = d;
        this.Ab = e;
        this.j = Math.floor(_.Fh() * 2147483647);
        this.reportEvent = function(h, k, l) {
            l = l === void 0 ? {} : l;
            h = _.v(Object, "assign").call(Object, {
                etc: g.j,
                e: h,
                t: Math.round(k),
                qqid: g.g,
                ptt: g.Ab
            }, l);
            _.an(g.G, "eit", h, !0, 1)
        };
        this.reportEvent(1, b);
        b = _.x(f);
        d = b.next();
        for (c = {}; !d.done; c = {
                Qd: void 0,
                Lh: void 0
            }, d = b.next()) switch (c.Qd = d.value, c.Qd) {
            case 101:
                d = new P4(a);
                d.j.then(function(h) {
                    return function(k) {
                        return void g.reportEvent(h.Qd, k)
                    }
                }(c));
                _.uC(this, d);
                break;
            case 102:
                c.Lh = new U4(a);
                c.Lh.j.then(function(h) {
                    return function(k) {
                        return void g.reportEvent(h.Qd, k, {
                            tbd: Math.round(h.Lh.L || -1)
                        })
                    }
                }(c));
                _.uC(this, c.Lh);
                break;
            case 103:
                d = new e5(a);
                d.listen(function(h) {
                    return function(k) {
                        var l;
                        g.reportEvent(h.Qd, k.bf, {
                            tsb: (l = k.jt) != null ? l : -1
                        })
                    }
                }(c));
                _.uC(this, d);
                break;
            case 104:
                d = O4(a);
                d.listen(function(h) {
                    return function(k) {
                        var l;
                        g.reportEvent(h.Qd, k.bf, {
                            it: k.Hq,
                            ualta: (l = k.It) != null ? l : -1
                        })
                    }
                }(c));
                _.uC(this, d);
                break;
            case 105:
                d = new R4(a), d.listen(function(h) {
                    return function(k) {
                        g.reportEvent(h.Qd, k.bf)
                    }
                }(c)), _.uC(this, d)
        }
    };
    _.V(f5, _.mY);
    var h5 = function(a, b, c) {
            this.D = b;
            this.l = c;
            this.g = null;
            this.j = !1;
            this.hostname = a.match(_.$X)[3] || "";
            this.K = g5(a)
        },
        eoa = function(a, b) {
            b ? a.g = new RegExp("\\b(" + b.join("|").toLowerCase() + ")\\b", "ig") : a.g = null
        },
        i5 = function(a, b, c) {
            if (_.Fi(["data-google-vignette", "data-google-interstitial"], function(g) {
                    return b.getAttribute(g) === "false" || b.closest && !!b.closest("[" + g + '="false"]')
                })) {
                var d;
                (d = a.D) == null || d.O({
                    J: 82
                });
                return !1
            }
            var e = (d = b.href) && (d.match(_.$X)[3] || null);
            if (!foa(a, b, d, e, c)) return !1;
            a.j = !!e && a.Jf(e);
            c = !c && !Ana(b) && /^https?:\/\//i.test(d) && !/((facebook|whatsapp|youtube|google)\.com)|\/ads?\//i.test(d);
            if (!a.j && !c) {
                var f;
                (f = a.D) == null || f.O({
                    J: 87
                })
            }
            return a.j || c
        },
        foa = function(a, b, c, d, e) {
            if (!c) {
                var f;
                (f = a.D) == null || f.O({
                    J: 83
                });
                return !1
            }
            switch (b.target) {
                case "_top":
                case "_parent":
                    break;
                case "":
                case "_self":
                    if (e) {
                        var g;
                        (g = a.D) == null || g.O({
                            J: 84
                        });
                        return !1
                    }
                    break;
                default:
                    var h;
                    (h = a.D) == null || h.O({
                        J: 85
                    });
                    return !1
            }
            if (!d) {
                var k;
                (k = a.D) == null || k.O({
                    J: 86
                });
                return !1
            }
            if (!a.l && a.Jf(d) && g5(c) === a.K) {
                var l;
                (l = a.D) == null || l.O({
                    J: 70
                });
                return !1
            }
            return !0
        };
    h5.prototype.Jf = function(a) {
        return a.replace(j5, "") === this.hostname.replace(j5, "")
    };
    var g5 = function(a) {
            a = a.match(_.$X);
            var b = a[6];
            return (a[5] || "") + (b ? "?" + b : "") || "/"
        },
        j5 = /^(www\.|m\.|mobile\.)*/i;
    var k5 = function(a, b, c, d, e, f) {
        e = e === void 0 ? {} : e;
        f = f === void 0 ? [] : f;
        _.mY.call(this);
        var g = this;
        this.j = a;
        this.eb = b;
        this.sa = c;
        this.G = d;
        this.Ra = f;
        this.messageHandlers = {};
        this.oa = [];
        this.xd = this.sa.Qa(168, function(h, k) {
            return void goa(g, h, k)
        });
        this.zd = this.sa.Qa(169, function(h, k) {
            _.an(g.G, "ras::xsf", {
                c: k.data.substring(0, 500),
                u: g.j.location.href.substring(0, 500)
            }, !0, .1);
            return !0
        });
        this.init(e)
    };
    _.V(k5, _.mY);
    k5.prototype.init = function(a) {
        hoa(this, this.messageHandlers, a);
        this.oa.push(l4(this.j, "sth", this.xd, this.zd))
    };
    var goa = function(a, b, c) {
        try {
            if (!a.lm(c.origin) || !ona(c, a.eb.contentWindow)) return
        } catch (f) {
            return
        }
        var d = b.msg_type,
            e = null;
        typeof d === "string" && (e = a.messageHandlers[d]) && a.sa.qd(168, function() {
            e.call(a, b, c)
        })
    };
    k5.prototype.lm = function(a) {
        var b;
        (b = _.v(this.Ra, "includes").call(this.Ra, a)) || (b = _.CL[a] || Hna.test(a) || Ina.test(a) || Jna.test(a));
        return b
    };
    k5.prototype.K = function() {
        for (var a = _.x(this.oa), b = a.next(); !b.done; b = a.next()) b = b.value, b();
        this.oa.length = 0;
        _.mY.prototype.K.call(this)
    };
    var n5 = function(a, b, c, d, e, f, g, h, k, l, n) {
        var m = {};
        k5.call(this, a, b, c, e, (m.heavyAdInterventionResponse = h.Dq, m));
        var p = this;
        this.I = d;
        this.requestedSize = f;
        this.B = h;
        this.D = l;
        this.Kb = _.fn();
        this.wb = g["i-fvs"] === "true";
        this.rh = g.qid;
        this.L = n != null ? n : new h5(a.location.href, this.D, this.B.ge);
        this.Gi = h.Gi || 1440;
        this.Lb = g.iobs === "true" && "IntersectionObserver" in this.j;
        var q, r;
        eoa(this.L, (r = (q = g.stop_word) == null ? void 0 : q.split(";")) != null ? r : null);
        this.H = {
            fm: !1
        };
        this.g = {};
        this.bb = {
            tag: 0
        };
        this.l = {
            vv: !0,
            ho: !1,
            Ag: !1,
            Pg: !0,
            Xl: !1
        };
        this.xb = this.ha = this.W = !1;
        this.P = l5(this);
        ioa(this);
        if (k.size)
            for (b = new _.kl, b.promise.then(function(z) {
                    p.l.Ee || p.M || m5(p, z)
                }), this.ga = new V4(a, k, b, h), _.uC(this, this.ga), k = _.x(k), b = k.next(); !b.done; b = k.next()) switch (b.value) {
                case 1:
                    this.D.O({
                        J: 91
                    });
                    break;
                case 2:
                    this.D.O({
                        J: 92
                    });
                    break;
                case 3:
                    this.D.O({
                        J: 93
                    });
                    break;
                case 4:
                    this.D.O({
                        J: 94
                    });
                    break;
                case 5:
                    this.D.O({
                        J: 95
                    });
                    break;
                case 6:
                    this.D.O({
                        J: 96
                    });
                    break;
                case 7:
                    this.D.O({
                        J: 97
                    });
                    break;
                case 8:
                    this.D.O({
                        J: 98
                    });
                    break;
                case 9:
                    this.D.O({
                        J: 104
                    });
                    break;
                case 10:
                    this.D.O({
                        J: 105
                    });
                    break;
                case 11:
                    this.D.O({
                        J: 108
                    })
            }
        var t;
        if ((t = h.Hl) == null ? 0 : t.length)
            if (t = _.gn(a)) {
                var w = new f5(a, t, e, this.rh, 17, h.Hl);
                _.uC(this, w);
                this.Wb = function(z) {
                    w.reportEvent(2, z - _.jn(a))
                }
            }
    };
    _.V(n5, k5);
    var l5 = function(a) {
            a.P && a.P.dispose();
            var b = wna(a.j, a.eb.contentWindow, a.sa, a.G, a.B.Ih);
            _.uC(a, b);
            Zna(b).then(function() {
                t4(a.I);
                a.va()
            });
            $na(b).then(function() {
                return void joa(a)
            });
            aoa(b).then(function() {
                return void a.Fj()
            });
            return b
        },
        hoa = function(a, b, c) {
            b["i-blur"] = function() {
                a.D.O({
                    J: 27
                });
                a.l.Ag = !0;
                a.l.th && (a.l.Pg = !0)
            };
            b["i-no"] = function(f) {
                a.D.O({
                    J: 26
                });
                a.bb = {
                    tag: 1,
                    zv: f.i_tslv ? f.i_tslv : void 0
                }
            };
            if (c.heavyAdInterventionResponse) {
                var d = lna(c.heavyAdInterventionResponse);
                if (d) {
                    c = coa();
                    var e = c.Us;
                    b["i-hai-aux"] = c.Vs;
                    e.then(function(f) {
                        _.uC(a, f);
                        f.promise.then(function() {
                            return d()
                        })
                    })
                }
            }
        };
    n5.prototype.va = function() {
        var a = a === void 0 ? !1 : a;
        this.H.um || (this.H.um = _.fn(), a && t4(this.I))
    };
    var joa = function(a) {
        a.D.O({
            J: 33
        });
        a.l.Ag ? (o5(a) ? (a.D.O({
            J: 34
        }), koa(a)) : (a.D.O({
            J: 35
        }), a.Jd()), a.B.ge && a.g.Sa && (a.g.Sa.click(), _.Ki("input")(a.g.Sa) && a.g.Sa.focus(), a.g.Sa = void 0), a.D.O({
            J: 36
        })) : (_.ja.setTimeout(function() {
            a.Jd()
        }, 1E3), a.W && (a.j.history.back(), a.j.history.back()), a.B.ge && a.g.Sa ? (a.l.th && (a.l.Pg = !1), a.B.Ct && o5(a) && a.j.history.back(), a.g.Sa.click(), a.g.Sa = void 0) : a.l.dh ? (a.l.th && (a.l.Pg = !1), p5(a, a.l.dh)) : a.D.O({
            J: 37
        }))
    };
    n5.prototype.Fj = function() {
        this.D.O({
            J: 23
        });
        this.H.fm = !0
    };
    var loa = function(a) {
        if (!o5(a)) {
            var b = new URL(a.j.location.href);
            b.hash = "google_vignette";
            var c;
            ((c = a.ga) == null ? 0 : c.j) && !a.W && !_.v(a.j.location.href, "includes").call(a.j.location.href, "about:blank") ? history.replaceState(a.j.history.state, "", b) : a.B.Gt && !_.v(a.j.location.href, "includes").call(a.j.location.href, "about:blank") ? history.pushState(a.j.history.state, "", b) : a.j.location.hash = "google_vignette"
        }
        a.l.th = a.sa.Qa(526, function() {
            a.D.O({
                J: 62
            });
            if (a.l.Pg) {
                if (o5(a)) a.D.O({
                    J: 64
                }), a.B.ge ? a.g.Sa && (a.g.Sa.click(), a.g.Sa = void 0) : p5(a, a.g.Fb.href);
                else {
                    var d;
                    if ((d = a.ga) == null) d = void 0;
                    else {
                        var e;
                        d = (e = d.g) == null ? void 0 : e.P
                    }
                    e = d;
                    !a.xb && a.ha && e && (p5(a, e), a.xb = !0);
                    a.l.Xl || a.D.O({
                        J: 80
                    });
                    a.l.Xl = !1;
                    a.Jd()
                }
                a.D.O({
                    J: 65
                })
            } else a.D.O({
                J: 63
            })
        });
        _.ja.setTimeout(_.OE(_.bh, a.j, "hashchange", a.l.th), 0)
    };
    n5.prototype.Ze = function(a) {
        this.D.O({
            J: 10
        });
        var b = _.fn(),
            c = _.wn(this.j).wasReactiveAdVisible[9];
        if (a) {
            var d = this.L;
            if (a && d.g) {
                var e = [];
                r4(a, e, !0, !0);
                a = e.join("");
                a = a.replace(Una, " ").replace(Vna, "");
                a = a.replace(Wna, "");
                a = a.replace(Xna, " ");
                a !== " " && (a = a.replace(Yna, ""));
                if (a) {
                    d = a.match(d.g);
                    a = [];
                    for (e = 0; d && e < d.length; e++) {
                        var f = d[e].toLowerCase();
                        _.bb(a, f) >= 0 || a.push(f)
                    }
                    d = a
                } else d = []
            } else d = []
        } else d = [];
        (a = this.B.Gq) || (a = _.ak(this.j), a = Math.abs(a - 1) < .05);
        e = this.requestedSize.width < this.requestedSize.height === _.Zj(this.j);
        if (b - this.Kb >= this.Gi * 60 * 1E3) return this.D.O({
            J: 11
        }), !1;
        a: switch (this.bb.tag) {
            case 0:
                b = !0;
                break a;
            case 1:
                b = !1;
                break a;
            default:
                b = !1
        }
        if (!b) return this.D.O({
            J: 12
        }), !1;
        if (this.H.fm) return this.D.O({
            J: 13
        }), !1;
        if (o5(this)) return this.D.O({
            J: 14
        }), !1;
        if (!this.H.um) return this.D.O({
            J: 15
        }), !1;
        if (!this.wb && c) return this.D.O({
            J: 16
        }), !1;
        this.wb && this.D.O({
            J: 17
        });
        c && this.D.O({
            J: 18
        });
        if (d.length) return this.D.O({
            J: 19
        }), !1;
        if (!a) return this.D.O({
            J: 20
        }), !1;
        if (!e) return this.D.O({
            J: 21
        }), !1;
        this.D.O({
            J: 22
        });
        return !0
    };
    var r5 = function(a, b) {
            var c;
            if (!(c = !a.B.Hp)) {
                a: {
                    try {
                        var d, e;
                        if ((e = (d = HTMLScriptElement).supports) == null || !e.call(d, "speculationrules") || (new URL(b)).origin !== a.j.origin) {
                            var f = !1;
                            break a
                        }
                        var g = a.j.document.createElement("script");
                        g.type = "speculationrules";
                        var h = _.Va(JSON.stringify({
                            prerender: [{
                                urls: [b]
                            }]
                        }).replace(/</g, "\\u003C"));
                        g.textContent = _.Wa(h);
                        _.Xa(g);
                        a.j.document.body.append(g);
                        f = !0;
                        break a
                    } catch (k) {
                        a.sa.Ge(1334, k);
                        f = !1;
                        break a
                    }
                    f = void 0
                }
                c = !f
            }
            c && (a.l.Ne = q5(a, b, "prerender"), a.l.Me = q5(a, b, "prefetch"), a.j.document.body.appendChild(a.l.Ne), a.j.document.body.appendChild(a.l.Me))
        },
        q5 = function(a, b, c) {
            a = _.ei("LINK", a.j.document);
            a.setAttribute("rel", c);
            a.setAttribute("href", b);
            return a
        },
        s5 = function(a, b) {
            for (b = b.target; b;) {
                if ("nodeName" in b && b.nodeName === "A") {
                    if (i5(a.L, b, b.ownerDocument !== a.j.document)) return b;
                    break
                } else {
                    if (a.B.Bt && _.Ki("button")(b)) return b;
                    if (a.B.Ft && _.Ki("input")(b)) return b
                }
                b = "parentElement" in b ? b.parentElement : null
            }
            return null
        };
    n5.prototype.K = function() {
        this.D.O({
            J: 24
        });
        k5.prototype.K.call(this);
        o5(this) && (this.B.ge ? this.g.Sa && (this.g.Sa.click(), this.g.Sa = void 0) : p5(this, this.g.Fb.href));
        this.g.Hc && (_.ch(this.j.document, "click", this.g.Hc), this.g.Hc = void 0);
        this.D.O({
            J: 25
        })
    };
    n5.prototype.Jd = function() {
        this.D.O({
            J: 38
        });
        if (!this.l.Ee)
            if (this.D.O({
                    J: 39
                }), this.B.po) this.P = l5(this);
            else return;
        this.l.ho = !0;
        this.g.Hc && (_.ch(this.j.document, "click", this.g.Hc), this.g.Hc = void 0);
        this.l.Ne && this.l.Ne.parentNode && (this.l.Ne.parentNode.removeChild(this.l.Ne), this.l.Ne = void 0);
        this.l.Me && this.l.Me.parentNode && (this.l.Me.parentNode.removeChild(this.l.Me), this.l.Me = void 0);
        t5(this.I, !1);
        this.D.O({
            J: 40
        })
    };
    var ioa = function(a) {
            a.D.O({
                J: 41
            });
            if (a.g.Hc) a.D.O({
                J: 42
            });
            else {
                a.g.Hc = a.sa.Qa(527, function(e) {
                    if (a.B.ge)
                        if (a.D.O({
                                J: 44
                            }), e)
                            if (e.isTrusted)
                                if (a.l.Ee) a.D.O({
                                    J: 50
                                });
                                else if (a.M) a.D.O({
                        J: 47
                    });
                    else if (a.g.Sa) a.D.O({
                        J: 74
                    });
                    else {
                        var f = s5(a, e);
                        f ? a.Ze(f) ? (a.g.Sa = f, e.stopImmediatePropagation(), e.preventDefault(), a.B.Ps && (_.wn(a.j).clickTriggeredInterstitialMayBeDisplayed = !0), m5(a, 1), a.D.O({
                            J: 53
                        })) : a.D.O({
                            J: 49
                        }) : a.D.O({
                            J: 48
                        })
                    } else a.D.O({
                        J: 73
                    });
                    else a.D.O({
                        J: 45
                    });
                    else moa(a, e)
                });
                if (a.g.Hc !== null) {
                    var b = a.g.Hc;
                    _.bh(a.j.document, "click", function(e) {
                        b(e)
                    }, E4)
                }
                for (var c = a.j.frames, d = 0; d < c.length; d++) try {
                    _.bh(c[d].document, "click", a.g.Hc, E4)
                } catch (e) {}
                a.D.O({
                    J: 43
                })
            }
        },
        p5 = function(a, b) {
            a = a.j.location;
            b = _.Ma(b);
            b !== void 0 && a.replace(b)
        },
        m5 = function(a, b) {
            a.D.O({
                J: 28
            });
            switch (b) {
                case 1:
                    a.D.O({
                        J: 66
                    });
                    break;
                case 2:
                    a.D.O({
                        J: 67
                    });
                    break;
                case 3:
                    a.D.O({
                        J: 68
                    });
                    break;
                case 4:
                    a.D.O({
                        J: 69
                    });
                    break;
                case 5:
                    a.D.O({
                        J: 71
                    });
                    break;
                case 6:
                    a.D.O({
                        J: 72
                    });
                    break;
                case 7:
                    a.D.O({
                        J: 81
                    });
                    break;
                case 8:
                    a.D.O({
                        J: 89
                    });
                    break;
                case 9:
                    a.D.O({
                        J: 103
                    });
                    break;
                case 10:
                    a.D.O({
                        J: 106
                    });
                    break;
                case 11:
                    a.D.O({
                        J: 109
                    })
            }
            if (a.Ze()) {
                var c = a.B.ge ? b === 1 && _.Ki("a")(a.g.Sa) : b === 1;
                a.W = b === 9;
                a.ha = b === 10;
                var d;
                (d = a.l).Ag || (d.Ag = !(c || a.W || a.ha));
                if (a.Kn()) {
                    a.l.Ee = Date.now();
                    _.wn(a.j).wasReactiveAdVisible[8] = !0;
                    a.ha && (a.l.dh = a.j.location.href);
                    c && a.g.Fb && (a.l.dh = a.g.Fb.href);
                    a.Lb || _.ja.IntersectionObserver || m4(a.P.rl, "fullscreen", {
                        eventType: "visible"
                    }, "*");
                    a.g.Fb ? r5(a, a.g.Fb.href) : a.g.Sa && _.Ki("a")(a.g.Sa) && (r5(a, a.g.Sa.href), a.D.O({
                        J: 76
                    }));
                    loa(a);
                    _.bh(a.j, "pagehide", a.sa.Qa(528, function() {
                        a.Jd()
                    }));
                    if (c) {
                        var e;
                        (e = a.Wb) == null || e.call(a, a.l.Ee)
                    }
                    t5(a.I, !0);
                    a.Jm();
                    a.D.Pf({
                        st: una(b),
                        rh: a.rh
                    });
                    var f;
                    (f = a.ga) == null || f.dispose();
                    a.D.O({
                        J: 32
                    })
                } else a.D.O({
                    J: 30
                }), c && a.g.Fb ? (a.D.O({
                    J: 31
                }), p5(a, a.g.Fb.href)) : c && a.g.Sa && (a.D.O({
                    J: 75
                }), a.g.Sa.click(), a.g.Sa = void 0)
            } else a.D.O({
                J: 29
            })
        };
    n5.prototype.Vb = function(a) {
        this.D.O({
            J: 54
        });
        this.l.Ee ? this.D.O({
            J: 56
        }) : this.M ? this.D.O({
            J: 57
        }) : this.g.Fb ? a.preventDefaultTriggered ? (this.D.O({
            J: 59
        }), this.g.Fb = void 0) : i5(this.L, this.g.Fb, this.g.Fb.ownerDocument !== this.j.document) ? this.Ze() ? (m5(this, 1), this.D.O({
            J: 61
        })) : (this.D.O({
            J: 60
        }), p5(this, this.g.Fb.href)) : (this.D.O({
            J: 55
        }), p5(this, this.g.Fb.href)) : this.D.O({
            J: 58
        })
    };
    n5.prototype.Kn = function() {
        return !0
    };
    n5.prototype.Jm = function() {};
    var moa = function(a, b) {
            a.D.O({
                J: 44
            });
            if (b)
                if (a.B.Ip && !b.isTrusted) a.D.O({
                    J: 73
                });
                else if (b.defaultPrevented) a.D.O({
                J: 46
            });
            else if (a.l.Ee) a.D.O({
                J: 50
            });
            else if (a.l.dh) a.D.O({
                J: 51
            });
            else if (a.M) a.D.O({
                J: 47
            });
            else if (a.g.Fb) a.D.O({
                J: 52
            });
            else {
                var c = s5(a, b);
                c ? a.Ze(c) ? (a.g.Fb = c, mna(b), b.preventDefault = function() {
                    return b && (b.preventDefaultTriggered = !0)
                }, _.ja.setTimeout((0, _.NE)(a.Vb, a, b), 0), a.B.Ps && (_.wn(a.j).clickTriggeredInterstitialMayBeDisplayed = !0), a.D.O({
                    J: 53
                })) : a.D.O({
                    J: 49
                }) : a.D.O({
                    J: 48
                })
            } else a.D.O({
                J: 45
            })
        },
        o5 = function(a) {
            return a.j.location.hash.indexOf("google_vignette") !== -1
        },
        koa = function(a) {
            var b = a.j.location.href;
            _.v(b, "includes").call(b, "about:blank#google_vignette") ? a.D.O({
                J: 79
            }) : (a.D.O({
                J: 77
            }), a.j.history.replaceState(a.j.history.state, "", b.replace("#google_vignette", "")));
            a.Jd()
        };
    var u5 = function(a, b, c) {
        _.mY.call(this);
        var d = this;
        this.element = a;
        this.event = b;
        this.handler = this.handler = c;
        _.bh(this.element, this.event, this.handler, E4);
        _.dv(this, function() {
            return void d.remove()
        })
    };
    _.V(u5, _.mY);
    u5.prototype.remove = function() {
        this.element && _.ch(this.element, this.event, this.handler, E4)
    };
    var v5 = function(a) {
        this.g = a;
        this.history = [];
        this.index = 0;
        this.reset()
    };
    v5.prototype.add = function(a) {
        var b = Date.now();
        this.history.push({
            time: b,
            coords: a
        });
        for (a = this.index; a < this.history.length; ++a)
            if (b - this.history[a].time >= this.g) delete this.history[a];
            else break;
        this.index = a;
        a >= this.history.length && this.reset()
    };
    v5.prototype.reset = function() {
        this.history = [];
        this.index = 0
    };
    var x5 = function(a, b, c, d) {
        c = c === void 0 ? b : c;
        d = d === void 0 ? 100 : d;
        _.mY.call(this);
        var e = this;
        this.document = a;
        this.target = b;
        this.handle = c;
        this.wb = d;
        this.I = this.H = this.va = !1;
        this.B = this.g = this.j = this.l = this.ha = this.P = this.ga = this.W = null;
        this.Kb = new u5(this.handle, "mousedown", function(f) {
            f.button === 0 && w5(e, f)
        });
        _.uC(this, this.Kb);
        this.Lb = new u5(this.handle, "touchstart", function(f) {
            w5(e, f)
        });
        _.uC(this, this.Lb);
        this.Eb = new u5(this.handle, "click", function(f) {
            e.va ? e.va = !1 : f.stopPropagation()
        });
        _.uC(this, this.Eb)
    };
    _.V(x5, _.mY);
    var y5 = function(a) {
        a = a.touches && a.touches[0] || a;
        return new _.Yk(a.clientX, a.clientY)
    };
    x5.prototype.ya = function() {
        if (this.l && this.j && this.g) {
            var a = this.l,
                b = A4(this.g, this.j);
            var c = new _.Yk(a.x + b.x, a.y + b.y);
            a = this.target;
            c instanceof _.Yk ? (b = c.x, c = c.y) : (b = c, c = void 0);
            a.style.left = _.TH(b, !1);
            a.style.top = _.TH(c, !1)
        }
    };
    x5.prototype.Ra = function() {};
    x5.prototype.oa = function() {
        var a = this.target,
            b = a.parentElement || null;
        var c = B4(a);
        b = B4(b);
        c = new _.Yk(c.x - b.x, c.y - b.y);
        a = D4(a, "margin");
        return A4(c, new _.Yk(a.left, a.top))
    };
    var w5 = function(a, b) {
            a.H && a.stop();
            a.H = !0;
            a.l = a.oa();
            a.j = y5(b);
            a.g = a.j;
            a.B = new v5(a.wb);
            a.B.add(a.j);
            a.W = new u5(a.document, "mousemove", function(c) {
                z5(a, c)
            });
            _.uC(a, a.W);
            a.ga = new u5(a.document, "touchmove", function(c) {
                z5(a, c)
            });
            _.uC(a, a.ga);
            a.P = new u5(a.document, "mouseup", function(c) {
                A5(a, c)
            });
            _.uC(a, a.P);
            a.ha = new u5(a.document, "touchend", function(c) {
                A5(a, c)
            });
            _.uC(a, a.ha)
        },
        z5 = function(a, b) {
            if (a.H)
                if (b.preventDefault(), a.g = y5(b), a.B.add(a.g), a.I) a.ya();
                else {
                    var c = a.j,
                        d = a.g;
                    b = c.x - d.x;
                    c = c.y - d.y;
                    Math.sqrt(b * b + c * c) >= 10 && (a.ya(), a.I = !0)
                }
        },
        A5 = function(a, b) {
            a.I ? (b.preventDefault(), a.g = y5(b), a.Ra()) : a.va = !0;
            a.stop()
        };
    x5.prototype.stop = function() {
        this.I = this.H = !1;
        this.B = this.g = this.j = this.l = null;
        this.W && this.W.remove();
        this.ga && this.ga.remove();
        this.P && this.P.remove();
        this.ha && this.ha.remove()
    };
    var B5 = {
        Th: !1,
        Cm: !1,
        Pl: !1,
        wf: !1,
        om: void 0
    };
    var E5 = function(a, b, c, d, e, f, g, h, k, l, n, m, p) {
        f = f === void 0 ? function() {} : f;
        g = g === void 0 ? function() {} : g;
        p = p === void 0 ? B5 : p;
        _.mY.call(this);
        var q = this;
        this.config = a;
        this.ra = b;
        this.L = c;
        this.P = d;
        this.g = e;
        this.Lb = f;
        this.wb = g;
        this.sa = h;
        this.G = k;
        this.Kb = l;
        this.Ra = n;
        this.l = m;
        this.ya = p;
        this.I = null;
        this.H = !1;
        this.ha = 0;
        this.La = !1;
        this.j = this.ga = null;
        this.B = m ? 2 : 1;
        _.dv(this, function() {
            C5(q, !0)
        });
        this.W = _.ei("INS", b.document);
        typeof HTMLElement.prototype.attachShadow !== "function" || this.sa.qd(1013, function() {
            q.I = _.ei("DIV", b.document);
            q.I.className = "grippy-host";
            q.I.attachShadow({
                mode: "closed"
            }).appendChild(q.W);
            _.dv(q, function() {
                q.I = null
            });
            return !0
        }) || (this.I = null);
        this.ta = b.innerHeight;
        this.bb = this.config.scroll_detached === "true";
        this.va = this.config.dismissable === "true";
        this.Wb = (this.oa = !this.ya.Cm || !!this.l) && (this.config.draggable === "true" || this.g !== "top");
        this.uc = this.config.expId || "";
        this.Vb = this.config.qemId || "";
        a = parseInt(this.config.z_index_override, 10);
        this.xb = isNaN(a) ? null : a;
        this.Eb = new _.e_(b);
        !this.va && _.ja.navigator.userAgent.match(/iPhone OS 7/) && b.setInterval(function() {
            var r = q.ra.innerHeight;
            if (Math.abs(r - 460) < 2 || Math.abs(r - 529) < 2) r < q.ta && Math.abs(_.ek(q.ra) - q.ha - 68) < 2 && (q.La = !0, q.B === 0 && D5(q)), q.ta = r
        }, 300);
        noa(this, this.W)
    };
    _.V(E5, _.mY);
    var G5 = function(a) {
            return a.g === "top" ? F5(a) ? "rgba(0, 0, 0, 0.5) 0px 4px 12px -4px, rgba(0, 0, 0, 0.3) 0px -4px 8px -3px" : "rgba(0, 0, 0, 0.2) 0px 1px 5px -1px, rgba(0, 0, 0, 0.1) 0px -1px 2px -1px" : F5(a) ? "rgba(0, 0, 0, 0.5) 0px -4px 12px -4px, rgba(0, 0, 0, 0.3) 0px 4px 8px -3px" : "rgba(0, 0, 0, 0.2) 0px -1px 5px -1px, rgba(0, 0, 0, 0.1) 0px 1px 2px -1px"
        },
        H5 = function(a, b) {
            if (a.g === "top") {
                var c;
                _.fk((c = a.I) != null ? c : a.W, {
                    top: _.F_(b)
                })
            }
        },
        F5 = function(a) {
            var b;
            return (b = a.ya.om) != null ? b : !_.yh() && !_.sL()
        },
        noa = function(a, b) {
            k4(b);
            var c = {
                "background-color": "#FAFAFA",
                display: "block",
                position: "relative",
                "z-index": "1",
                height: _.F_(5),
                "box-shadow": G5(a)
            };
            F5(a) && _.v(Object, "assign").call(Object, c, a.g === "bottom" ? {
                "border-top-left-radius": _.F_(5),
                "border-top-right-radius": _.F_(5)
            } : {
                "border-bottom-left-radius": _.F_(5),
                "border-bottom-right-radius": _.F_(5)
            });
            _.fk(b, c);
            if (a.g === "top") {
                c = {
                    position: "absolute",
                    top: _.F_(a.l ? a.l.maxHeight + 5 : a.P.height),
                    width: "100%"
                };
                var d;
                _.fk((d = a.I) != null ? d : b, c)
            }
            if (a.oa) {
                var e = _.ei("SPAN", a.ra.document);
                e.appendChild(ooa(a));
                var f = function(g) {
                    g.target === e && (g.preventDefault && g.preventDefault(), g.stopImmediatePropagation && g.stopImmediatePropagation(), g.stopPropagation && g.stopPropagation())
                };
                _.bh(e, "click", f);
                _.dv(a, function() {
                    _.ch(e, "click", f)
                });
                poa(a, e);
                b.className = "ee";
                b.appendChild(e)
            }
        },
        poa = function(a, b) {
            var c = {};
            c = (c.display = "block", c.width = "80px", c.height = "45px", c[a.g] = "0", c.left = "0%", c.marginLeft = "0px", c["pointer-events"] = "none", c);
            F5(a) && (c.position = "absolute", c.left = "50%", c.transform = "translateX(-50%)");
            a = b.getElementsByTagName("svg")[0];
            _.fk(b, c);
            j4(a)
        },
        I5 = function(a) {
            var b;
            return (b = a.I) != null ? b : a.W
        },
        ooa = function(a) {
            var b = "",
                c = "",
                d = "",
                e = "",
                f = function() {};
            switch (a.g) {
                case "top":
                    b = "dropShadowBottom";
                    c = F5(a) ? "M10,4 L10,22 A6,6 0 0,0 16,28 L60,28 A6,6 0 0,0 66,22 L66,10 66,4 Z" : "M0,4 L0,22 A6,6 0 0,0 6,28 L50,28 A6,6 0 0,0 56,22 L56,10 A6,6 0 0,1 61,4 Z";
                    d = "0";
                    e = "up";
                    f = function(p) {
                        u4(p, F5(a))
                    };
                    break;
                case "bottom":
                    b = "dropShadowTop", c = F5(a) ? "M10,26 L10,6 A6,6 0 0,1 16,1 L60,1 A6,6 0 0,1 66,6 L66,20 66,26 Z" : "M0,26 L0,6 A6,6 0 0,1 6,1 L50,1 A6,6 0 0,1 56,6 L56,20 A6,6 0 0,0 62,26 Z", d = "25", e = "down", f = function(p) {
                        v4(p, F5(a))
                    }
            }
            var g = a.ra.document,
                h = g.createElementNS("http://www.w3.org/2000/svg", "svg");
            h.style.setProperty("margin", "0 0 0 0px", "important");
            h.style.setProperty("position", "absolute", "important");
            h.style.setProperty(a.g, "0", "important");
            h.style.setProperty("left", "0%", "important");
            h.style.setProperty("display", "block", "important");
            h.style.setProperty("width", "80px", "important");
            h.style.setProperty("height", "30px", "important");
            h.style.setProperty("transform", "none", "important");
            h.style.setProperty("pointer-events", "initial", "important");
            var k = g.createElementNS("http://www.w3.org/2000/svg", "defs"),
                l = g.createElementNS("http://www.w3.org/2000/svg", "filter");
            l.setAttribute("id", b);
            l.setAttribute("filterUnits", "userSpaceOnUse");
            l.setAttribute("color-interpolation-filters", "sRGB");
            var n = g.createElementNS("http://www.w3.org/2000/svg", "feComponentTransfer");
            n.setAttribute("in", "SourceAlpha");
            n.setAttribute("result", "TransferredAlpha");
            var m = g.createElementNS("http://www.w3.org/2000/svg", "feFuncR");
            m.setAttribute("type", "discrete");
            m.setAttribute("tableValues", "0.5");
            n.appendChild(m);
            m = g.createElementNS("http://www.w3.org/2000/svg", "feFuncG");
            m.setAttribute("type", "discrete");
            m.setAttribute("tableValues", "0.5");
            n.appendChild(m);
            m = g.createElementNS("http://www.w3.org/2000/svg", "feFuncB");
            m.setAttribute("type", "discrete");
            m.setAttribute("tableValues", "0.5");
            n.appendChild(m);
            l.appendChild(n);
            n = g.createElementNS("http://www.w3.org/2000/svg", "feGaussianBlur");
            n.setAttribute("in", "TransferredAlpha");
            n.setAttribute("stdDeviation", "2");
            l.appendChild(n);
            n = g.createElementNS("http://www.w3.org/2000/svg", "feOffset");
            n.setAttribute("dx", "0");
            n.setAttribute("dy", "0");
            n.setAttribute("result", "offsetblur");
            l.appendChild(n);
            n = g.createElementNS("http://www.w3.org/2000/svg", "feMerge");
            n.appendChild(g.createElementNS("http://www.w3.org/2000/svg", "feMergeNode"));
            m = g.createElementNS("http://www.w3.org/2000/svg", "feMergeNode");
            m.setAttribute("in", "SourceGraphic");
            n.appendChild(m);
            l.appendChild(n);
            k.appendChild(l);
            h.appendChild(k);
            k = g.createElementNS("http://www.w3.org/2000/svg", "path");
            k.setAttribute("d", c);
            k.setAttribute("stroke", "#FAFAFA");
            k.setAttribute("stroke-width", "1");
            k.setAttribute("fill", "#FAFAFA");
            k.style.setProperty("filter", "url(#" + b + ")");
            h.appendChild(k);
            b = g.createElementNS("http://www.w3.org/2000/svg", "rect");
            b.setAttribute("x", "0");
            b.setAttribute("y", d);
            b.setAttribute("width", "80");
            b.setAttribute("height", "5");
            b.style.setProperty("fill", "#FAFAFA");
            h.appendChild(b);
            d = g.createElementNS("http://www.w3.org/2000/svg", "g");
            d.setAttribute("class", e);
            d.setAttribute("stroke", "#616161");
            d.setAttribute("stroke-width", "2px");
            d.setAttribute("stroke-linecap", "square");
            f(d, F5(a));
            h.appendChild(d);
            return h
        },
        J5 = function(a, b) {
            if (a.oa) {
                for (var c = a.W.getElementsByTagName("svg")[0].getElementsByTagName("g")[0], d; d = c.firstChild;) c.removeChild(d);
                switch (a.g) {
                    case "top":
                        (b ? v4 : u4)(c, F5(a));
                        break;
                    case "bottom":
                        (b ? u4 : v4)(c, F5(a))
                }
            }
        },
        K5 = function(a, b, c, d) {
            b = {
                i: b,
                dc: a.B === 0 ? "1" : "0",
                fdc: c ? "1" : "0",
                ds: a.va ? "1" : "0",
                expId: a.uc,
                sc: a.bb ? "1" : "0",
                off: d,
                vw: _.Wj(a.ra),
                req: a.L.src,
                tp: a.g,
                h: a.P.height,
                w: a.P.width,
                qemId: a.Vb
            };
            _.an(a.G, "flgr", b, !0, 1)
        },
        D5 = function(a, b) {
            b = b === void 0 ? a.va : b;
            switch (a.B) {
                case 1:
                    a.show();
                    break;
                case 2:
                    L5(a);
                    break;
                case 0:
                    a.l ? L5(a) : a.show();
                    break;
                case 3:
                    C5(a, b);
                    break;
                case 4:
                    a.show()
            }
        },
        qoa = function(a) {
            var b = a.l.maxHeight,
                c = a.l.maxHeight + 5;
            a.B !== 4 && (a.j.style[a.g] = "-" + (b - (parseInt(a.j.style.height, 10) + parseInt(a.j.style[a.g], 10))) + "px");
            a.j.style.height = c + "px";
            a.L.parentElement.style.height = b + "px";
            a.L.style.height = b + "px";
            a.L.style.maxHeight = "none";
            a.L.height = "100%";
            H5(a, c);
            (a = a.ga) != null && (a.L = c)
        },
        N5 = function(a, b) {
            a.g === "bottom" && o4(a.ra) && a.sa.qd(404, function() {
                M5(a, "0px", b, "ease-out")
            })
        };
    E5.prototype.show = function() {
        var a = this;
        if (!this.H) {
            var b = this.l && parseInt(this.j.style.height, 10) > this.P.height,
                c = parseInt(this.j.style[this.g], 10);
            if (c || b) {
                var d = function() {
                    a.B = 3;
                    if (b) {
                        var g = a.P.height;
                        a.j.style[a.g] = "0";
                        a.j.style.height = g + "px";
                        a.L.parentElement.style.height = g + "px";
                        a.L.height = "" + g;
                        a.L.style.height = g + "px";
                        a.L.style.maxHeight = "30vh";
                        H5(a, g);
                        var h;
                        (h = a.ga) != null && (h.L = g)
                    }
                    a.H = !1;
                    O5(a);
                    a.j.setAttribute("data-anchor-status", "displayed");
                    a.j.setAttribute("data-anchor-shown", "true");
                    J5(a, !1)
                };
                this.H = !0;
                if (c && !b) {
                    var e = -c / P5(this);
                    N5(this, e);
                    J5(this, !1);
                    c = new c5(this.j, c, 0, e, this.g, this.sa, d, b5);
                    this.Ra();
                    a5(c)
                } else if (b) {
                    var f = this.l.maxHeight + 5;
                    e = this.P.height - f;
                    f = (f + c > this.P.height ? -1 : 1) * (e - c) / P5(this);
                    N5(this, f);
                    c === e ? d() : (c = new c5(this.j, c, e, f, this.g, this.sa, d, b5), this.Ra(), a5(c))
                }
            }
        }
    };
    var L5 = function(a) {
            if (!a.H) {
                qoa(a);
                var b = parseInt(a.j.style[a.g], 10),
                    c = function() {
                        a.H = !1;
                        a.B = 4;
                        O5(a);
                        a.j.setAttribute("data-anchor-status", "displayed");
                        a.j.setAttribute("data-anchor-shown", "true");
                        J5(a, !1)
                    };
                if (b) {
                    a.H = !0;
                    var d = -b / P5(a);
                    N5(a, d);
                    J5(a, !1);
                    b = new c5(a.j, b, 0, d, a.g, a.sa, c, b5, a.ya.wf);
                    a.Ra();
                    a5(b)
                } else c()
            }
        },
        C5 = function(a, b) {
            if (!a.H && a.j) {
                var c = parseInt(a.j.style[a.g], 10),
                    d = -(a.B === 4 ? a.l.maxHeight + 5 : a.P.height) - (b ? 30 : 0),
                    e = (c - d) / P5(a);
                a.g === "bottom" && o4(a.ra) && a.sa.qd(405, function() {
                    M5(a, "21px", e, "ease-in")
                });
                b || J5(a, !0);
                c === d ? b || (a.B = 0) : a.Kb() ? (a.H = !0, a5(new c5(a.j, c, d, e, a.g, a.sa, function() {
                    a.H = !1;
                    b ? a.Lb() : (a.B = 0, J5(a, !0));
                    a.j.setAttribute("data-anchor-status", "dismissed")
                }, boa))) : J5(a, !1)
            }
        },
        P5 = function(a) {
            return a.P.height >= Math.floor(a.ra.document.documentElement.clientHeight * .3) ? Infinity : a.l ? a.l.Wk ? a.l.Wk : Infinity : .1
        },
        roa = function(a, b) {
            if (a.g !== "bottom" && a.g !== "top") throw Error("unsupported reactive type");
            var c = function(f) {
                a.oa && (f.preventDefault(), a.H || (a.La = !0, D5(a), K5(a, "c", a.B !== 0, 0)))
            };
            _.bh(a.W, "click", c);
            _.dv(a, function() {
                _.ch(a.W, "click", c)
            });
            a.I && (_.bh(a.I, "click", c), _.dv(a, function() {
                a.I && _.ch(a.I, "click", c)
            }));
            _.dn(b, {
                opacity: 1
            });
            var d = a.ra.document;
            if (d) {
                a.j = b;
                var e = a.l ? a.l.maxHeight + 5 : a.P.height;
                a.Wb && (a.ga = new(a.g === "top" ? Q5 : R5)(a, d, e, b, a.W), _.uC(a, a.ga));
                d = {
                    position: "fixed",
                    left: _.F_(0)
                };
                F5(a) && (d.left = "50%", d.transform = "translateX(-50%)", d["box-shadow"] = G5(a), d["border-radius"] = "5px");
                d[a.g] = _.F_(-e - 30);
                _.dn(b, d);
                _.fk(b, {
                    overflow: "visible",
                    background: "#FAFAFA"
                });
                _.h_(a.Eb, function(f) {
                    var g = a.xb === null ? 2147483647 : a.xb;
                    _.dn(b, {
                        zIndex: f === null ? g : Math.min(f, g)
                    })
                });
                D5(a)
            }
        },
        M5 = function(a, b, c, d) {
            _.dn(a.L, {
                transition: c / 1E3 + "s",
                "transition-timing-function": d,
                "margin-top": b
            })
        },
        O5 = function(a) {
            a.wb();
            a.wb = function() {}
        },
        S5 = function(a, b, c, d, e) {
            x5.call(this, b, d, e);
            this.xb = a;
            this.L = c
        };
    _.V(S5, x5);
    S5.prototype.Ra = function() {
        var a = this.xb;
        if (!a.H) {
            var b = parseInt(a.j.style[a.g], 10),
                c = b + parseInt(a.j.style.height, 10),
                d = a.P.height / 2;
            c >= (a.l ? (a.l.maxHeight + 5) / 2 : _.v(Number, "MAX_SAFE_INTEGER")) ? (L5(a), K5(a, "d", !1, b)) : c >= d ? (a.show(), K5(a, "d", !1, b)) : (C5(a, a.va), K5(a, "d", !0, b))
        }
    };
    S5.prototype.ya = function() {
        if (this.l !== null && this.j !== null && this.g !== null) {
            var a = this.bb(this.l.y, A4(this.g, this.j).y);
            a > 0 && (a = 0);
            a < -this.L && (a = -this.L);
            var b = {};
            b[this.La()] = _.F_(a);
            _.dn(this.target, b)
        }
    };
    var Q5 = function(a, b, c, d, e) {
        S5.call(this, a, b, c, d, e)
    };
    _.V(Q5, S5);
    Q5.prototype.oa = function() {
        return new _.Yk(0, parseInt(this.target.style.top, 10))
    };
    Q5.prototype.bb = function(a, b) {
        return b - a
    };
    Q5.prototype.La = function() {
        return "top"
    };
    var R5 = function(a, b, c, d, e) {
        S5.call(this, a, b, c, d, e)
    };
    _.V(R5, S5);
    R5.prototype.oa = function() {
        return new _.Yk(0, parseInt(this.target.style.bottom, 10))
    };
    R5.prototype.bb = function(a, b) {
        return a - b
    };
    R5.prototype.La = function() {
        return "bottom"
    };
    var X5 = function(a, b, c, d, e, f, g, h, k, l) {
        h = h === void 0 ? null : h;
        k = k === void 0 ? B5 : k;
        l = l === void 0 ? null : l;
        _.h4.call(this, a, b, f);
        var n = this;
        this.sa = d;
        this.G = e;
        this.storage = g;
        this.H = h;
        this.Ra = k;
        this.D = l;
        this.W = this.Og = this.zd = 0;
        this.Kb = this.Xn = !1;
        this.B = null;
        this.va = this.filled = !1;
        this.ya = null;
        this.ga = 0;
        this.Df = this.ha = !1;
        this.wb = !0;
        this.bb = null;
        this.Eb = this.Wb = this.Lb = this.Im = this.Ik = this.Jk = !1;
        this.mj = 0;
        this.vm = this.oa = this.bj = !1;
        this.xb = D4(b.document.body, "padding");
        this.P = D4(b.document.body, "padding");
        this.I = c;
        this.L = soa(this);
        this.Zn = _.Vk(b || window).height / 2;
        this.ta = _.Vk(b || window).height;
        this.Am = Dna(b);
        T5(this);
        this.mn = this.sa.Qa(266, function() {
            U5(n, !0, 33);
            V5(n, !0)
        });
        this.Dn = this.sa.Qa(267, function() {
            U5(n, !0, 34);
            V5(n, !0)
        });
        this.Hn = this.sa.Qa(268, function() {
            if (n.ha && n.l && n.B) {
                var m = n.B;
                m.ha = _.ek(m.ra)
            }
            m = _.ek(n.g);
            var p = m - n.zd;
            W5(n, p);
            n.Eb && (p > 0 && (n.W += p), n.bj = n.Am - m <= n.ta, n.zd = m);
            V5(n)
        });
        this.Mn = this.sa.Qa(269, function() {
            toa(n)
        });
        this.Pn = this.sa.Qa(270, function(m) {
            uoa(n, m)
        });
        this.Tn = this.sa.Qa(271, function(m) {
            if (m && m.touches) {
                n.ya = "touchmove";
                n.ga = m.touches.length;
                n.va = !0;
                V5(n);
                if (!n.Xn && m.touches && m.touches.length !== 0 && m.touches[0]) {
                    m = m.touches[0].pageY;
                    var p = m - n.Og;
                    n.Og = m;
                    m = p
                } else m = 0;
                m > 0 && (n.W += m);
                W5(n, m)
            }
        });
        this.Wn = this.sa.Qa(272, function(m) {
            m && m.touches && m.touches[0] && (n.ya = "touchstart", n.ga = m.touches.length, n.va = !1, V5(n), n.Og = m.touches[0].pageY, m = (m = m.target) && n.I === "top" && n.filled && n.B && I5(n.B) && m.nodeType === 1 ? _.HH(I5(n.B), m) : !1, n.Xn = m)
        });
        this.kj = this.sa.Qa(273, function() {
            n.Lb || (n.Lb = !0, _.ch(n.j, "load", n.kj), n.Wb && !n.Df || V5(n, !0))
        });
        _.bh(a, "load", this.kj);
        _.dv(this, function() {
            _.ch(a, "load", n.kj)
        })
    };
    _.V(X5, _.h4);
    var voa = function(a) {
            var b = a.g;
            _.bh(b, "orientationchange", a.mn);
            _.bh(b, "resize", a.Dn);
            _.bh(b, "scroll", a.Hn);
            _.bh(b, "touchcancel", a.Mn);
            _.bh(b, "touchend", a.Pn);
            _.bh(b, "touchmove", a.Tn);
            _.bh(b, "touchstart", a.Wn);
            _.dv(a, function() {
                Y5(a)
            })
        },
        Y5 = function(a) {
            var b = a.g;
            _.ch(b, "orientationchange", a.mn);
            _.ch(b, "resize", a.Dn);
            _.ch(b, "scroll", a.Hn);
            _.ch(b, "touchcancel", a.Mn);
            _.ch(b, "touchend", a.Pn);
            _.ch(b, "touchmove", a.Tn);
            _.ch(b, "touchstart", a.Wn)
        };
    X5.prototype.ao = function(a) {
        var b = this.l;
        if (b && !this.B) {
            for (var c in Z5) !Z5.hasOwnProperty(c) || c in a || (a[c] = Z5[c]);
            this.Jk = a.use_manual_view === "true" || this.I === "top" || !!_.wn(this.g).wasReactiveAdConfigReceived[2];
            this.Ik = a.use_important === "true";
            if (c = a.af_l) this.Wb = c === "true";
            this.vm = (this.Eb = a.wait_for_scroll === "true" || this.I === "top") && (a.tsec === "true" || this.I === "top");
            this.mj = parseInt(a.lims, 10);
            $5(this, a);
            this.B = woa(this, a);
            this.bb = a6(this);
            this.bj = this.ta >= this.Am;
            a = this.l;
            c = this.B && I5(this.B);
            a && c && (this.I === "top" ? a.appendChild(c) : a.insertBefore(c, a.firstChild));
            voa(this);
            this.filled = !0;
            b.setAttribute("data-anchor-status", "ready-to-display")
        }
    };
    var a6 = function(a) {
            var b = a.L.height + 5;
            a.I === "bottom" && o4(a.g) && (b += 20);
            return new _.Uk(a.L.width, b)
        },
        $5 = function(a, b) {
            var c = parseInt(b.ht, 10),
                d = c > 0 ? c : null;
            b = parseInt(b.wd, 10);
            var e = b > 0 ? b : null;
            d !== null && (a.L.height = d);
            e !== null && (a.L.width = e);
            z4(a, function(f) {
                w4(f, e, d)
            }, !1, !0);
            w4(a.j, e, d)
        },
        woa = function(a, b) {
            b = new E5(b, a.g, a.j, a.L, a.I, function() {
                if (!a.Kb) {
                    a.Kb = !0;
                    Y5(a);
                    var c = a.l;
                    _.bz(c);
                    b6(a, a.xb, !0, !0);
                    c && (c.style.display = "none")
                }
            }, function() {
                return void xoa(a)
            }, a.sa, a.G, function() {
                return a.collapse()
            }, function() {
                a.oa && (a.oa = !1, W5(a, null));
                a.Om && _.az(a.R, a.slotId);
                a.Vb && (clearTimeout(a.Vb), a.Vb = null);
                return !0
            }, a.H, a.Ra);
            _.uC(a, b);
            return b
        },
        T5 = function(a) {
            if (a.wb) {
                var b = a.l;
                b && (b.style.display = "none");
                b6(a, a.xb, !0, !0);
                a.wb = !1
            }
        };
    X5.prototype.xd = function(a) {
        a = a === void 0 ? !1 : a;
        this.Df || U5(this, a, 9);
        this.Df = !0;
        if (this.ha || !c6(this, a) || !this.Lb && this.Wb) !this.Lb && this.Wb && U5(this, a, 12);
        else {
            var b = this.l;
            b ? (d6(this), z4(this, function(c) {
                k4(c)
            }, !0), roa(this.B, b), this.show(), U5(this, !0, 14), this.ha = !0, (a = this.j.contentWindow) && n4(a, "ig", {
                rr: "vis-aa"
            }, "*", 2), yoa(this), e6(this, this.Ra.Th), zoa(this), Aoa(this)) : U5(this, a, 13)
        }
    };
    X5.prototype.show = function() {
        var a = this.l;
        if (a) {
            var b = this.B,
                c = b.ra,
                d = _.ek(c);
            if (!(Math.abs(d - b.ha) < 10)) {
                var e = d < 10;
                c = d + 10 + _.Xj(c) > _.dk(c).offsetHeight;
                e = e || c;
                b.bb || b.La || b.H || (b.B === 0 || e ? b.B === 0 && e && D5(b) : D5(b, !1));
                b.ha = d
            }
            this.wb || (f6(this), b = D4(this.g.document.body, "padding"), this.I === "bottom" && (b.bottom += this.bb.height + 25), b6(this, b), a.style.display = "block", this.wb = !0)
        }
    };
    var d6 = function(a) {
            var b = a.l;
            if (b && a.j.parentElement) {
                C4(b, a.bb);
                var c = _.dk(a.g).scrollWidth,
                    d = a.g.innerWidth;
                b.style.width = g6(a) ? "auto" : c > d ? _.F_(d) : "100%";
                h6(a);
                a.H && _.fk(a.j.parentElement, {
                    height: a.H.maxHeight + "px",
                    display: "inline-block"
                })
            }
        },
        h6 = function(a) {
            z4(a, function(c) {
                g6(a) ? _.UH(c, a.L.height) : (C4(c, a.L), c.style.width = "100%")
            }, !1, !0);
            a.j.style.display = "block";
            a.j.style.margin = "0 auto";
            if (a.Ik) {
                var b = a.l;
                Ena(b, function(c) {
                    j4(c, function(d) {
                        return c === b && /display|bottom/i.test(d) ? !1 : !0
                    });
                    if (c.nodeName === "svg") return !1
                })
            }
        },
        f6 = function(a) {
            if (a.I !== "bottom" && a.I !== "top") throw Error("Unexpected position: " + a.I);
        },
        soa = function(a) {
            f6(a);
            var b = a.g.innerWidth;
            a = _.rq(_.VH, a.j).height || +a.j.height || 0;
            return new _.Uk(b, a)
        },
        toa = function(a) {
            a.ya = "touchcancel";
            _.ja.setTimeout(a.sa.Qa(274, function() {
                a.ya === "touchcancel" && (a.ga = 0, a.va = !1, V5(a))
            }), 1E3)
        },
        uoa = function(a, b) {
            if (b && b.touches) {
                a.ya = "touchend";
                var c = b.touches.length;
                c < 2 ? _.ja.setTimeout(a.sa.Qa(256, function() {
                    a.ya === "touchend" && (a.ga = c, a.va = !1, V5(a))
                }), 1E3) : (a.ga = c, V5(a))
            }
        },
        W5 = function(a, b) {
            var c = a.wb ? i6(a, a.oa) : a.xb.top;
            if (a.I === "top" && a.g.document.body && a.filled && a.B && a.ha && a.P.top !== c && b !== 0) {
                var d = a.P.clone();
                b === null ? (d.top = c, b6(a, d)) : (b > 0 && a.P.top > c && (d.top = Math.max(c, a.P.top - b), b6(a, d, !1)), b < 0 && a.P.top < c && (d.top = Math.min(c, a.P.top - b), b6(a, d, !1)))
            }
        },
        b6 = function(a, b, c, d) {
            var e = a.P.top - b.top,
                f = _.ek(a.g);
            f < e && (d === void 0 || !d) || (d = a.g.document.body, d.style.paddingTop = _.F_(b.top), d.style.paddingRight = _.F_(b.right), d.style.paddingBottom = _.F_(b.bottom), d.style.paddingLeft = _.F_(b.left), a.P = b, (c === void 0 || c) && a.g.scrollTo(0, f - e))
        },
        V5 = function(a, b) {
            b = b === void 0 ? !1 : b;
            U5(a, b, 15);
            a.filled ? a.Kb ? U5(a, b, 17) : a.ga >= 2 && a.va && U5(a, b, 18) : U5(a, b, 16);
            !a.filled || a.Kb || a.ga >= 2 && a.va || !c6(a, b) ? T5(a) : (U5(a, b, 19), a.xd(b), a.show())
        };
    X5.prototype.Af = function() {
        return _.Zj(this.g)
    };
    var c6 = function(a, b) {
            b = b === void 0 ? !1 : b;
            U5(a, b, 20);
            if (!a.Af()) return U5(a, b, 21), !1;
            if (!a.ha && a.Eb) {
                a.mj && setTimeout(function() {
                    if (!a.ha) {
                        a.Eb = !1;
                        U5(a, b, 24);
                        a.xd(!0);
                        var d = a.P.clone();
                        d.top = i6(a, a.oa);
                        b6(a, d, !0)
                    }
                }, a.mj);
                a.vm && (a.W += Math.max(_.ek(a.g) - a.zd, 0));
                var c = !1;
                switch (a.I) {
                    case "bottom":
                        return (c = a.W >= a.Zn || a.bj) || U5(a, b, 27), c;
                    case "top":
                        return (c = a.W > i6(a)) || U5(a, b, 29), c;
                    default:
                        return !0
                }
            }
            U5(a, b, 31);
            return !0
        },
        i6 = function(a, b) {
            return (b === void 0 ? 0 : b) ? a.xb.top + 30 : a.xb.top + 30 + a.bb.height - 5
        },
        xoa = function(a) {
            a.Jk && !a.Im && (a.Im = !0, a.sa.qd(257, function() {
                var b = {
                        msg_type: "manual-send-view"
                    },
                    c = a.j.contentWindow;
                c && c.postMessage(JSON.stringify(b), "*")
            }))
        };
    X5.prototype.collapse = function() {
        this.oa || (this.oa = !0, W5(this, null));
        return Boa(this)
    };
    var yoa = function(a) {
            var b = a.L.height >= Math.floor(a.g.document.documentElement.clientHeight * .5),
                c = a.Ra.Pl && a.L.height >= Math.floor(a.g.document.documentElement.clientHeight * .3);
            if (a.H || b || c)
                if (b = _.Rm(a.storage)) {
                    b.push(Date.now());
                    var d;
                    (d = a.storage) == null || d.setItem("__lsa__", JSON.stringify(b))
                }
        },
        e6 = function(a, b) {
            a.H && (a.j.onload = function() {
                if (a.H) {
                    var c = a.j,
                        d = c.parentElement,
                        e = d.style.display;
                    _.fk(d, {
                        height: a.H.maxHeight + 1 + "px",
                        display: "inline-block"
                    });
                    b && _.fk(c, {
                        height: a.H.maxHeight + 1 + "px"
                    });
                    setTimeout(function() {
                        a.H && (_.fk(d, {
                            height: a.H.maxHeight + "px",
                            display: e
                        }), b && _.fk(c, {
                            height: a.H.maxHeight + "px"
                        }))
                    }, 100)
                }
            })
        },
        zoa = function(a) {
            if (a.H) {
                var b = _.ei("div");
                b.id = "click-protector";
                b.style.position = "relative";
                b.style.width = "65px";
                b.style.height = "25px";
                b.style.left = "0";
                b.style.top = a.I === "bottom" ? "-100%" : "-25px";
                a.l.appendChild(b);
                b.addEventListener("click", function(c) {
                    c.stopPropagation();
                    c.preventDefault()
                })
            }
        },
        Aoa = function(a) {
            if (a.H) var b = 100,
                c = setInterval(function() {
                    if (a.g.document.getElementsByClassName("fc-message-root").length) {
                        var d;
                        if ((d = a.B) == null ? 0 : d.B === 4) {
                            var e;
                            (e = a.B) == null || e.show();
                            var f;
                            (f = a.storage) == null || f.removeItem("__lsa__")
                        }
                        var g;
                        (g = a.D) == null || _.Ty(g, {
                            J: 32
                        });
                        clearInterval(c)
                    } else --b <= 0 && clearInterval(c)
                }, 100)
        };
    X5.prototype.Yn = function(a, b, c) {
        this.j = a;
        var d, e = ((d = this.B) == null ? void 0 : d.B === 4) && !c;
        if (b && (this.L.height !== b.height || this.L.width !== b.width || e)) {
            d = b.height - this.L.height;
            e = {};
            $5(this, (e.ht = "" + b.height, e.wd = "" + b.width, e));
            this.bb = a6(this);
            d6(this);
            W5(this, d);
            var f;
            (f = this.B) == null || H5(f, b.height)
        }
        this.H = c;
        (b = this.B) != null && (b.l = c, b.L = a, b.B = 3, c && L5(b));
        e6(this, this.Ra.Th);
        h6(this)
    };
    var U5 = function(a, b, c) {
            b && !a.ha && a.D && _.Ty(a.D, {
                J: c
            })
        },
        g6 = function(a) {
            var b;
            return (b = a.Ra.om) != null ? b : !_.yh() && !_.sL()
        },
        Z5 = {
            ui: "gr",
            gvar: "ar",
            scroll_detached: "true",
            dismissable: "false"
        };
    var j6 = function() {
        _.YZ.call(this, "__lsv__")
    };
    _.V(j6, _.YZ);
    var l6 = function() {
            k6 || (k6 = new j6);
            return k6
        },
        k6 = null;
    var m6 = function(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        _.h4.call(this, a, b, c);
        this.L = b;
        this.P = d;
        this.W = e;
        this.B = null;
        this.H = b.document;
        this.I = _.f_(new _.e_(b), 2147483646)
    };
    _.V(m6, _.h4);
    var Eoa = function(a) {
            t5(a, !1);
            var b = a.l;
            if (b) {
                var c = Bna(a.L);
                z4(a, function(d) {
                    _.fk(d, c);
                    k4(d)
                }, !0);
                a.j.setAttribute("width", "");
                a.j.setAttribute("height", "");
                _.dn(a.j, c);
                _.dn(a.j, Coa);
                _.dn(b, Doa);
                _.dn(b, {
                    background: "transparent"
                });
                _.fk(b, {
                    display: "none",
                    position: "fixed"
                });
                k4(b);
                k4(a.j);
                _.Ah(a.L) <= 1 || (_.dn(b, {
                    overflow: "scroll",
                    "max-width": "100vw"
                }), j4(b))
            }
        },
        t5 = function(a, b) {
            var c = a.l;
            c && (b ? (_.j_(a.I), _.fk(c, {
                display: "block"
            }), a.H.body && !a.B && (a.B = _.en(a.H, a.g, a.P, a.W)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.H.body.setAttribute("aria-hidden", "true")) : (_.k_(a.I), _.fk(c, {
                display: "none"
            }), a.B && (a.B(), a.B = null), a.H.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
        },
        Doa = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        Coa = {
            left: "0",
            position: "absolute",
            top: "0"
        };
    var n6 = function(a, b, c, d, e, f, g, h, k, l, n) {
        X5.call(this, c, d, b === 2 ? "top" : "bottom", new _.RY(a), new _.g4, e, _.Pi(h, d), _.Sy(n), {
            Th: !0,
            Cm: _.I(_.JW),
            Pl: _.I(_.DW),
            wf: _.I(_.FW)
        }, a);
        this.g = d;
        this.R = f;
        this.slotId = g;
        this.Xm = k;
        this.nb = l;
        this.Vb = null;
        this.Wm = 0;
        this.jj = !1;
        this.uc = null;
        this.Om = !!_.Wy(this.R, this.slotId);
        b === 2 && _.E0(this.R, this.slotId);
        k && this.nb.nh([this.slotId], this.j)
    };
    _.V(n6, X5);
    var Boa = function(a) {
            if (Foa(a)) return !1;
            if (a.Xm) return a.Xm = !1, !Goa(a);
            a.Wm < _.K(_.IW) && (a.Vb = setTimeout(function() {
                Hoa(a)
            }, _.K(_.OW)));
            _.E0(a.R, a.slotId);
            return !0
        },
        Hoa = function(a) {
            if (!a.jj) {
                a.jj = !0;
                var b = a.g.googletag,
                    c = function(d) {
                        d.slot.getSlotElementId() === a.slotId.getDomId() && (b.pubads().removeEventListener("slotRenderEnded", c), a.Wm++, a.jj = !1, a.B && (d = a.B, d.B === 0 && d.show()))
                    };
                b.pubads().addEventListener("slotRenderEnded", c);
                _.az(a.R, a.slotId);
                b.pubads().refresh([a.slotId.Ca]);
                a.Om || _.E0(a.R, a.slotId)
            }
        },
        Foa = function(a) {
            if (!a.uc) return a.uc = Date.now(), !1;
            var b = Date.now() - a.uc;
            a.uc = Date.now();
            return b < 100
        },
        Goa = function(a) {
            var b = a.nb;
            var c = a.slotId;
            if (b.ne.get(c)) {
                var d;
                (d = b.ne.get(c)) == null || d();
                b.ne.delete(c);
                b = !0
            } else b = !1;
            if (!b) return !1;
            a.B && (a = a.B, a.B === 0 && a.show());
            return !0
        };
    n6.prototype.Af = function() {
        return (0, _.Bh)() === 0 || X5.prototype.Af.call(this)
    };
    var o6 = function(a, b, c) {
        m6.call(this, b, a, c, _.K(_.oW), _.I(_.WW));
        Eoa(this)
    };
    _.V(o6, m6);
    var p6 = function(a, b, c, d, e, f, g, h, k, l, n, m, p, q, r, t) {
        var w = [];
        _.I(_.$V) && (0, _.Bh)() === 0 && w.push(101);
        _.I(_.aW) && w.push(102);
        g = tna(g);
        _.I(_.dW) && g.add(5);
        _.I(_.cW) && g.add(6);
        _.I(_.gW) && g.add(7);
        _.I(_.bW) && g.add(9);
        _.I(_.iW) && g.add(2);
        _.I(_.fW) && g.add(3);
        _.I(_.eW) && g.add(10);
        var z = Cna(a, _.K(_.LW), m, b);
        z !== void 0 && g.add(8);
        p = _.I(_.TW) && !_.O(p, 3);
        n5.call(this, b, c, new _.RY(a), new o6(b, c, d), new _.g4, e, f, {
            Hl: w,
            Ih: {
                ft: 3,
                version: "m202511050101"
            },
            Gq: !0,
            Dq: l,
            dj: _.K(_.rW),
            Qp: (0, _.Bh)() !== 0 ? _.K(_.kW) : _.K(_.jW),
            Op: _.K(_.lW),
            Pp: _.I(_.mW),
            Np: _.K(_.nW),
            ge: p,
            Ip: _.I(_.CW),
            Ct: _.I(_.UW),
            Bt: _.I(_.SW),
            Ft: _.I(_.VW),
            Gt: !0,
            Yj: _.K(_.tW),
            Zm: _.K(_.uW),
            bn: _.K(_.vW),
            Hp: _.I(_.sW),
            Xr: z,
            po: _.I(_.ZV),
            Bh: _.I(_.RW),
            Gi: _.K(_.wW)
        }, g, a);
        this.ya = h;
        this.uc = k;
        this.La = n;
        this.Eb = q;
        this.slotId = r;
        this.R = t;
        this.localStorage = _.Pi(m, b);
        _.uC(this, this.I)
    };
    _.V(p6, n5);
    _.u = p6.prototype;
    _.u.Kn = function() {
        return this.ya || !this.localStorage || _.$Z(l6(), this.localStorage, this.La)
    };
    _.u.Jm = function() {
        this.R.j = this.slotId;
        var a, b = (a = this.localStorage) == null ? void 0 : a.getItem("_GPCK");
        if (b) try {
            if (JSON.parse(b).key === this.Eb) {
                var c;
                (c = this.localStorage) == null || c.removeItem("_GPCK")
            }
        } catch (d) {}
    };
    _.u.lm = function() {
        return !0
    };
    _.u.Fj = function() {
        n5.prototype.Fj.call(this);
        this.uc()
    };
    _.u.Jd = function() {
        n5.prototype.Jd.call(this);
        this.R.j = null
    };
    _.u.Ze = function(a) {
        return _.I(_.QW) && this.R.j !== null ? (this.D.O({
            J: 107
        }), !1) : n5.prototype.Ze.call(this, a)
    };
    _.u.zp = function() {
        return this.ya || !this.localStorage || _.ZZ(l6(), this.localStorage, this.La)
    };
    var Ioa = {
        fq: n6,
        Pq: p6
    };
    _.y3(_m, _.K2).resolve(Ioa);
})