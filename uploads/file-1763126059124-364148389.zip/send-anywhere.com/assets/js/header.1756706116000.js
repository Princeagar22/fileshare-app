// <!-- Google Tag Manager -->
const urlCheck = window.location.hostname
// var trackCode;
// urlCheck.startsWith('test.send-anywhere.com') || urlCheck.startsWith('localhost') ? trackCode = 'GTM-MWXJQ9V' : trackCode = 'GTM-NQWTW75';
// (function(w, d, s, l, i) {
//     w[l] = w[l] || [];
//     w[l].push({'gtm.start' : new Date().getTime(), event : 'gtm.js'});
//     var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer'?'&l=' + l : '';
//     j.async = true;
//     j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
//     f.parentNode.insertBefore(j, f);
// })(window, document, 'script', 'dataLayer', trackCode);
// <!-- End Google Tag Manager -->


// <!-- Google tag (gtag.js) -->
// <script async src="https://www.googletagmanager.com/gtag/js?id=G-PZ99DJV1CT"></script>
// <script>
//   window.dataLayer = window.dataLayer || [];
//   function gtag(){dataLayer.push(arguments);}
//   gtag('js', new Date());

//   gtag('config', 'G-PZ99DJV1CT');
// </script>

// <!-- Start Google tag (gtag.js) -->
// function fnBrowserDetect(){
//     let userAgent = navigator.userAgent;
//     let browser;

//     if(userAgent.indexOf("Whale") > -1) {												// IE
//         browser = "whale";
//     } else if(userAgent.indexOf("Chrome") > -1) {											// Edge
//         browser = "chrome";
//     }

//     return browser;
// }

const gtagHostName = window.location.hostname;
const isTestEnvironment = gtagHostName.startsWith('test.send-anywhere.com') || gtagHostName.startsWith('localhost');
const trackingCode = isTestEnvironment ? 'G-PZ99DJV1CT' : 'G-SHGDYFMJXL';
// const ext_trackingCode = fnBrowserDetect() === 'whale' ? (isTestEnvironment ? 'G-DYXW8B1X14' : 'G-XFLB8XYJ8M') : (isTestEnvironment ? 'G-MDFVG2QYYJ' : 'G-ZCJGSKCHZ4')

// legacy trackcode
const trackCode = gtagHostName.startsWith('test.send-anywhere.com') || gtagHostName.startsWith('localhost') ? 'GTM-MWXJQ9V' : 'GTM-NQWTW75';

const script = document.createElement("script");
script.async = true;
script.src = `https://www.googletagmanager.com/gtag/js?id=${trackingCode}`;
document.head.appendChild(script);

window.dataLayer = window.dataLayer || [];

function gtag() {
    window.dataLayer.push(arguments);
}
gtag('js', new Date());
if (isTestEnvironment) {
    gtag('config', trackingCode, {
        'debug_mode': true
    });
    gtag('config', trackCode, {
        'debug_mode': true
    });
    // gtag('config', ext_trackingCode, { 'debug_mode': true });
} else {
    gtag('config', trackingCode);
    gtag('config', trackCode);
    // gtag('config', ext_trackingCode);
}

// <!-- End Google tag (gtag.js) -->

// facebook login
window.fbAsyncInit = function() {
        let appId = '1333248186715658';
        if (urlCheck.startsWith('localhost')) {
            appId = '352846874868475';
        }
        window.FB.init({
            appId: appId,
            autoLogAppEvents: !0,
            xfbml: !0,
            version: 'v6.0'
        }), window.FB.AppEvents.logPageView()
    },
    function(e, n, t) {
        var o, i = e.getElementsByTagName(n)[0];
        e.getElementById(t) || ((o = e.createElement(n)).id = t, o.src = '//connect.facebook.net/en_US/sdk.js', i.parentNode.insertBefore(o, i))
    }(document, 'script', 'facebook-jssdk')

    // Facebook Pixel Code
    ! function(f, b, e, v, n, t, s) {
        if (f.fbq) return;
        n = f.fbq = function() {
            n.callMethod ?
                n.callMethod.apply(n, arguments) : n.queue.push(arguments)
        };
        if (!f._fbq) f._fbq = n;
        n.push = n;
        n.loaded = !0;
        n.version = '2.0';
        n.queue = [];
        t = b.createElement(e);
        t.async = !0;
        t.src = v;
        s = b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t, s)
    }(window, document, 'script', '//connect.facebook.net/en_US/fbevents.js');
fbq('init', '1341760472609957');
fbq('track', 'PageView');

// google login
var googleUser = {};