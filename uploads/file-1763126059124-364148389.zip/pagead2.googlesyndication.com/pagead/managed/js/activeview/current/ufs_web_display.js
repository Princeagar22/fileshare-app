(function() {
    var n, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        },
        ea = ca(this),
        fa = "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(" ");
    ea.BigInt64Array && (fa.push("BigInt64"), fa.push("BigUint64"));
    var ia = function(a, b) {
            if (b)
                for (var c = 0; c < fa.length; c++) ha(fa[c] + "Array.prototype." + a, b)
        },
        p = function(a, b) {
            b && ha(a, b)
        },
        ha = function(a, b) {
            var c = ea;
            a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) return;
                c = c[e]
            }
            a = a[a.length - 1];
            d = c[a];
            b = b(d);
            b != d && b != null && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        },
        ja;
    if (typeof Object.setPrototypeOf == "function") ja = Object.setPrototypeOf;
    else {
        var ka;
        a: {
            var ma = {
                    a: !0
                },
                na = {};
            try {
                na.__proto__ = ma;
                ka = na.a;
                break a
            } catch (a) {}
            ka = !1
        }
        ja = ka ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError("b`" + a);
            return a
        } : null
    }
    var oa = ja,
        q = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (oa) oa(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Mi = b.prototype
        },
        pa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        y = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: pa(a)
            };
            throw Error("c`" + String(a));
        },
        z = function(a) {
            if (!(a instanceof Array)) {
                a = y(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        ra = function(a) {
            return qa(a, a)
        },
        qa = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        sa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ta = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("d");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) sa(d,
                        e) && (a[e] = d[e])
            }
            return a
        };
    p("Object.assign", function(a) {
        return a || ta
    });
    var ua = function() {
        this.oc = !1;
        this.Wa = null;
        this.ba = void 0;
        this.u = 1;
        this.Fa = this.wa = 0;
        this.be = this.ga = null
    };
    ua.prototype.Ka = function() {
        if (this.oc) throw new TypeError("f");
        this.oc = !0
    };
    ua.prototype.xc = function(a) {
        this.ba = a
    };
    ua.prototype.Ic = function(a) {
        this.ga = {
            zf: a,
            Wf: !0
        };
        this.u = this.wa || this.Fa
    };
    ua.prototype.return = function(a) {
        this.ga = {
            return: a
        };
        this.u = this.Fa
    };
    var va = function(a, b, c) {
        a.u = c;
        return {
            value: b
        }
    };
    ua.prototype.Ia = function(a) {
        this.u = a
    };
    var wa = function(a, b, c) {
            a.wa = b;
            c != void 0 && (a.Fa = c)
        },
        xa = function(a) {
            a.wa = 0;
            var b = a.ga.zf;
            a.ga = null;
            return b
        },
        ya = function(a, b, c, d) {
            d ? a.be[d] = a.ga : a.be = [a.ga];
            a.wa = b || 0;
            a.Fa = c || 0
        },
        za = function(a, b, c) {
            c = a.be.splice(c || 0)[0];
            (c = a.ga = a.ga || c) ? c.Wf ? a.u = a.wa || a.Fa : c.Ia != void 0 && a.Fa < c.Ia ? (a.u = c.Ia, a.ga = null) : a.u = a.Fa: a.u = b
        };
    ua.prototype.forIn = function(a) {
        return new Aa(a)
    };
    var Aa = function(a) {
            this.lg = [];
            for (var b in a) this.lg.push(b);
            this.lg.reverse()
        },
        Ba = function(a) {
            this.A = new ua;
            this.oi = a
        };
    Ba.prototype.xc = function(a) {
        this.A.Ka();
        if (this.A.Wa) return Ca(this, this.A.Wa.next, a, this.A.xc);
        this.A.xc(a);
        return Da(this)
    };
    var Ea = function(a, b) {
        a.A.Ka();
        var c = a.A.Wa;
        if (c) return Ca(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.A.return);
        a.A.return(b);
        return Da(a)
    };
    Ba.prototype.Ic = function(a) {
        this.A.Ka();
        if (this.A.Wa) return Ca(this, this.A.Wa["throw"], a, this.A.xc);
        this.A.Ic(a);
        return Da(this)
    };
    var Ca = function(a, b, c, d) {
            try {
                var e = b.call(a.A.Wa, c);
                if (!(e instanceof Object)) throw new TypeError("e`" + e);
                if (!e.done) return a.A.oc = !1, e;
                var f = e.value
            } catch (g) {
                return a.A.Wa = null, a.A.Ic(g), Da(a)
            }
            a.A.Wa = null;
            d.call(a.A, f);
            return Da(a)
        },
        Da = function(a) {
            for (; a.A.u;) try {
                var b = a.oi(a.A);
                if (b) return a.A.oc = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.A.ba = void 0, a.A.Ic(c)
            }
            a.A.oc = !1;
            if (a.A.ga) {
                b = a.A.ga;
                a.A.ga = null;
                if (b.Wf) throw b.zf;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        Fa = function(a) {
            this.next =
                function(b) {
                    return a.xc(b)
                };
            this.throw = function(b) {
                return a.Ic(b)
            };
            this.return = function(b) {
                return Ea(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Ga = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        },
        Ha = function(a) {
            return Ga(new Fa(new Ba(a)))
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.Mg = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.Mg
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("g");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return Ia(pa(this))
            }
        });
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });
    var Ia = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        Ja = function(a) {
            this[Symbol.asyncIterator] = function() {
                return this
            };
            this[Symbol.iterator] = function() {
                return a
            };
            this.next = function(b) {
                return Promise.resolve(a.next(b))
            };
            this["throw"] = function(b) {
                return new Promise(function(c, d) {
                    var e = a["throw"];
                    e !== void 0 ? c(e.call(a, b)) : (c = a["return"], c !== void 0 && c.call(a), d(new TypeError("h")))
                })
            };
            a["return"] !== void 0 && (this["return"] = function(b) {
                return Promise.resolve(a["return"](b))
            })
        },
        B = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("globalThis", function(a) {
        return a || ea
    });
    p("Reflect.setPrototypeOf", function(a) {
        return a ? a : oa ? function(b, c) {
            try {
                return oa(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    });
    p("Promise", function(a) {
        function b() {
            this.La = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.jf = function(g) {
            if (this.La == null) {
                this.La = [];
                var h = this;
                this.kf(function() {
                    h.qh()
                })
            }
            this.La.push(g)
        };
        var d = ea.setTimeout;
        b.prototype.kf = function(g) {
            d(g, 0)
        };
        b.prototype.qh = function() {
            for (; this.La && this.La.length;) {
                var g = this.La;
                this.La = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.Ug(l)
                    }
                }
            }
            this.La = null
        };
        b.prototype.Ug = function(g) {
            this.kf(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.Tb = 0;
            this.Ec = void 0;
            this.Mb = [];
            this.bg = !1;
            var h = this.Ud();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.Ud = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.Bi),
                reject: g(this.Fe)
            }
        };
        e.prototype.Bi = function(g) {
            if (g === this) this.Fe(new TypeError("i"));
            else if (g instanceof e) this.Gi(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.Ai(g) : this.Cf(g)
            }
        };
        e.prototype.Ai = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.Fe(k);
                return
            }
            typeof h == "function" ? this.Hi(h, g) : this.Cf(g)
        };
        e.prototype.Fe = function(g) {
            this.tg(2, g)
        };
        e.prototype.Cf = function(g) {
            this.tg(1, g)
        };
        e.prototype.tg = function(g, h) {
            if (this.Tb != 0) throw Error("j`" + g + "`" + h + "`" + this.Tb);
            this.Tb = g;
            this.Ec = h;
            this.Tb === 2 && this.Di();
            this.rh()
        };
        e.prototype.Di = function() {
            var g = this;
            d(function() {
                if (g.fi()) {
                    var h = ea.console;
                    typeof h !== "undefined" && h.error(g.Ec)
                }
            }, 1)
        };
        e.prototype.fi = function() {
            if (this.bg) return !1;
            var g = ea.CustomEvent,
                h = ea.Event,
                k = ea.dispatchEvent;
            if (typeof k === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = ea.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.Ec;
            return k(g)
        };
        e.prototype.rh = function() {
            if (this.Mb != null) {
                for (var g = 0; g < this.Mb.length; ++g) f.jf(this.Mb[g]);
                this.Mb = null
            }
        };
        var f = new b;
        e.prototype.Gi = function(g) {
            var h =
                this.Ud();
            g.Tc(h.resolve, h.reject)
        };
        e.prototype.Hi = function(g, h) {
            var k = this.Ud();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(r, t) {
                return typeof r == "function" ? function(w) {
                    try {
                        l(r(w))
                    } catch (v) {
                        m(v)
                    }
                } : t
            }
            var l, m, u = new e(function(r, t) {
                l = r;
                m = t
            });
            this.Tc(k(g, l), k(h, m));
            return u
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Tc = function(g, h) {
            function k() {
                switch (l.Tb) {
                    case 1:
                        g(l.Ec);
                        break;
                    case 2:
                        h(l.Ec);
                        break;
                    default:
                        throw Error("k`" +
                            l.Tb);
                }
            }
            var l = this;
            this.Mb == null ? f.jf(k) : this.Mb.push(k);
            this.bg = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = y(g), m = l.next(); !m.done; m = l.next()) c(m.value).Tc(h, k)
            })
        };
        e.all = function(g) {
            var h = y(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function u(w) {
                    return function(v) {
                        r[w] = v;
                        t--;
                        t == 0 && l(r)
                    }
                }
                var r = [],
                    t = 0;
                do r.push(void 0), t++, c(k.value).Tc(u(r.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    });
    p("Object.setPrototypeOf", function(a) {
        return a || oa
    });
    p("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push(b[d]);
            return c
        }
    });
    var Ka = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Ka(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function d(k) {
            if (!sa(k, f)) {
                var l = new b;
                ba(k, f, {
                    value: l
                })
            }
        }

        function e(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (m.get(k) != 2 || m.get(l) != 3) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && m.get(l) == 4
                } catch (u) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            h = function(k) {
                this.kc = (g += Math.random() + 1).toString();
                if (k) {
                    k = y(k);
                    for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        h.prototype.set = function(k, l) {
            if (!c(k)) throw Error("l");
            d(k);
            if (!sa(k, f)) throw Error("m`" + k);
            k[f][this.kc] = l;
            return this
        };
        h.prototype.get = function(k) {
            return c(k) && sa(k, f) ? k[f][this.kc] : void 0
        };
        h.prototype.has = function(k) {
            return c(k) && sa(k, f) && sa(k[f], this.kc)
        };
        h.prototype.delete = function(k) {
            return c(k) &&
                sa(k, f) && sa(k[f], this.kc) ? delete k[f][this.kc] : !1
        };
        return h
    });
    p("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(y([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (u) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (h) {
                    h = y(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                Ja: this[1].Ja,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].Ja.next = l.entry, this[1].Ja = l.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.Ja.next =
                h.entry.next, h.entry.next.Ja = h.entry.Ja, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Ja = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach =
            function(h, k) {
                for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && sa(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var u = m[h];
                        if (k !== k && u.key !== u.key || k === u.key) return {
                            id: l,
                            list: m,
                            index: h,
                            entry: u
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return Ia(function() {
                    if (l) {
                        for (; l.head !=
                            h[1];) l = l.Ja;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Ja = h.next = h.head = h
            },
            g = 0;
        return c
    });
    p("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(y([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.ya = new Map;
            if (c) {
                c =
                    y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.ya.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.ya.set(c, c);
            this.size = this.ya.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.ya.delete(c);
            this.size = this.ya.size;
            return c
        };
        b.prototype.clear = function() {
            this.ya.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.ya.has(c)
        };
        b.prototype.entries = function() {
            return this.ya.entries()
        };
        b.prototype.values = function() {
            return this.ya.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.ya.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Ka(this, function(b, c) {
                return [b, c]
            })
        }
    });
    var La = function(a, b, c) {
        if (a == null) throw new TypeError("n`" + c);
        if (b instanceof RegExp) throw new TypeError("o`" + c);
        return a + ""
    };
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = La(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    p("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = La(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return La(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    });
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Ka(this, function(b, c) {
                return c
            })
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            c < 0 && (c = Math.max(0, e + c));
            if (d == null || d > e) d = e;
            d = Number(d);
            d < 0 && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    ia("fill", function(a) {
        return a ? a : Array.prototype.fill
    });
    p("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = La(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = b === void 0 ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && b > 0 ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Oa = this || self,
        Pa = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = Oa, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        },
        Qa = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Ra = function(a) {
            var b = Qa(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        Sa = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        Ta = function(a) {
            return a
        },
        Ua = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Mi = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.Dj = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Va = function() {
        this.Ag = 0
    };
    Va.prototype.Ub = function(a, b) {
        var c = this;
        return function() {
            var d = B.apply(0, arguments);
            c.Ag = a;
            return b.apply(null, z(d))
        }
    };
    var Wa = function() {
            var a = {};
            this.za = (a[3] = [], a[2] = [], a[1] = [], a);
            this.se = !1
        },
        Ya = function(a, b, c) {
            var d = Xa(a, c);
            a.za[c].push(b);
            d && a.za[c].length === 1 && a.flush()
        },
        Xa = function(a, b) {
            return Object.keys(a.za).map(function(c) {
                return Number(c)
            }).filter(function(c) {
                return !isNaN(c) && c > b
            }).every(function(c) {
                return a.za[c].length === 0
            })
        };
    Wa.prototype.flush = function() {
        if (!this.se) {
            this.se = !0;
            try {
                for (; Object.values(this.za).some(function(a) {
                        return a.length > 0
                    });) Za(this, 3), Za(this, 2), Za(this, 1)
            } catch (a) {
                throw Object.values(this.za).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.se = !1
            }
        }
    };
    var Za = function(a, b) {
        for (; Xa(a, b) && a.za[b].length > 0;) a.za[b][0](), a.za[b].shift()
    };
    ea.Object.defineProperties(Wa.prototype, {
        ng: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.za).some(function(a) {
                    return a.length > 0
                })
            }
        }
    });

    function ab(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var bb = {};
    var cb = globalThis.trustedTypes,
        db;

    function eb() {
        var a = null;
        if (!cb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = cb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {
            throw c;
        }
        return a
    };
    var fb = function(a) {
        if (bb !== bb) throw Error("p");
        this.kg = a
    };
    fb.prototype.toString = function() {
        return this.kg + ""
    };

    function gb(a) {
        var b;
        db === void 0 && (db = eb());
        a = (b = db) ? b.createScriptURL(a) : a;
        return new fb(a)
    };
    var hb = ra([""]),
        ib = qa(["\x00"], ["\\0"]),
        jb = qa(["\n"], ["\\n"]),
        mb = qa(["\x00"], ["\\u0000"]),
        nb = ra([""]),
        ob = qa(["\x00"], ["\\0"]),
        pb = qa(["\n"], ["\\n"]),
        qb = qa(["\x00"], ["\\u0000"]);

    function rb(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function sb(a) {
        return a.toString().indexOf("`") === -1
    }
    var tb = sb(function(a) {
            return a(hb)
        }) || sb(function(a) {
            return a(ib)
        }) || sb(function(a) {
            return a(jb)
        }) || sb(function(a) {
            return a(mb)
        }),
        ub = rb(nb) && rb(ob) && rb(pb) && rb(qb);
    var vb = function(a) {
        if (bb !== bb) throw Error("p");
        this.ni = a
    };
    vb.prototype.toString = function() {
        return this.ni
    };
    new vb("about:blank");
    new vb("about:invalid#zClosurez");
    var wb = [],
        xb = function(a) {
            console.warn("r`" + a)
        };
    wb.indexOf(xb) === -1 && wb.push(xb);

    function yb(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, yb);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    Ua(yb, Error);
    yb.prototype.name = "CustomError";
    var zb;

    function Bb(a, b) {
        var c = yb.call;
        a = a.split("%s");
        for (var d = "", e = a.length - 1, f = 0; f < e; f++) d += a[f] + (f < b.length ? b[f] : "%s");
        c.call(yb, this, d + a[e])
    }
    Ua(Bb, yb);
    Bb.prototype.name = "AssertionError";

    function Cb(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Bb("" + e, f || []);
    }
    var D = function(a, b, c) {
            a || Cb("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        F = function(a, b, c) {
            a == null && Cb("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Db = function(a, b) {
            throw new Bb("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        Eb = function(a, b, c) {
            typeof a !== "number" && Cb("Expected number but got %s: %s.", [Qa(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Fb = function(a, b, c) {
            typeof a !== "string" && Cb("Expected string but got %s: %s.", [Qa(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Gb = function(a, b, c) {
            typeof a !== "function" && Cb("Expected function but got %s: %s.", [Qa(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Hb = function(a, b, c) {
            Sa(a) || Cb("Expected object but got %s: %s.", [Qa(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        G = function(a, b, c) {
            Array.isArray(a) || Cb("Expected array but got %s: %s.", [Qa(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Jb = function(a, b, c, d) {
            a instanceof b || Cb("Expected instanceof %s but got %s.", [Ib(b), Ib(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function Ib(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : a === null ? "null" : typeof a
    };
    var Kb = Array.prototype.forEach ? function(a, b) {
            D(a.length != null);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        Lb = Array.prototype.map ? function(a, b) {
            D(a.length != null);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        Mb = Array.prototype.some ? function(a, b) {
            D(a.length !=
                null);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function Nb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Ob(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Pb(a, b, c) {
        if (!Ra(a) || !Ra(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || Qb;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function Qb(a, b) {
        return a === b
    }

    function Rb(a, b) {
        return Nb.apply([], Lb(a, b))
    };

    function Sb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Tb = function(a, b) {
        this.name = a;
        this.value = b
    };
    Tb.prototype.toString = function() {
        return this.name
    };
    var Ub = new Tb("OFF", Infinity),
        Vb = new Tb("WARNING", 900),
        Wb = new Tb("INFO", 800),
        Xb = new Tb("CONFIG", 700),
        Yb = function() {
            this.Uc = 0;
            this.clear()
        },
        Zb;
    Yb.prototype.clear = function() {
        this.G = Array(this.Uc);
        this.sf = -1;
        this.Xf = !1
    };
    var $b = function(a, b, c) {
        this.reset(a || Ub, b, c, void 0, void 0)
    };
    $b.prototype.reset = function(a, b, c, d) {
        d || Date.now();
        this.di = b
    };
    $b.prototype.getMessage = function() {
        return this.di
    };
    var ac = function(a, b) {
            this.level = null;
            this.Ah = [];
            this.parent = (b === void 0 ? null : b) || null;
            this.children = [];
            this.Vh = {
                getName: function() {
                    return a
                }
            }
        },
        bc = function(a) {
            if (a.level) return a.level;
            if (a.parent) return bc(a.parent);
            Db("Root logger has no level set.");
            return Ub
        },
        cc = function(a, b) {
            for (; a;) a.Ah.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        dc = function() {
            this.entries = {};
            var a = new ac("");
            a.level = Xb;
            this.entries[""] = a
        },
        ec, hc = function(a, b, c) {
            var d = a.entries[b];
            if (d) return c !== void 0 && (d.level = c), d;
            d = b.lastIndexOf(".");
            d = b.slice(0, Math.max(d, 0));
            d = hc(a, d);
            var e = new ac(b, d);
            a.entries[b] = e;
            d.children.push(e);
            c !== void 0 && (e.level = c);
            return e
        },
        ic = function() {
            ec || (ec = new dc);
            return ec
        },
        lc = function(a) {
            var b = kc;
            if (b) {
                var c = a,
                    d = Vb;
                if (a = b)
                    if (a = b && d) {
                        a = d.value;
                        var e = b ? bc(hc(ic(), b.getName())) : Ub;
                        a = a >= e.value
                    }
                if (a) {
                    d = d || Ub;
                    a = hc(ic(), b.getName());
                    typeof c === "function" && (c = c());
                    Zb || (Zb = new Yb);
                    e = Zb;
                    b = b.getName();
                    if (e.Uc > 0) {
                        var f = (e.sf + 1) % e.Uc;
                        e.sf = f;
                        e.Xf ? (e = e.G[f], e.reset(d, c, b), b = e) : (e.Xf = f == e.Uc - 1, b = e.G[f] = new $b(d, c, b))
                    } else b =
                        new $b(d, c, b);
                    cc(a, b)
                }
            }
        };
    var mc = function() {
        this.names = new Map
    };
    mc.prototype.getName = function(a) {
        var b = this.names.get(a);
        if (b) return b;
        var c;
        b = (c = a.description) != null ? c : Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36);
        this.names.set(a, b);
        return b
    };
    /*


     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors
     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at
         http://www.apache.org/licenses/LICENSE-2.0
     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var nc = function(a) {
        var b = Error.call(this, a ? a.length + " errors occurred during unsubscription:\n" + a.map(function(c, d) {
            return d + 1 + ") " + c.toString()
        }).join("\n  ") : "");
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.errors = a;
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "UnsubscriptionError"
    };
    q(nc, Error);

    function oc(a, b) {
        a && (b = a.indexOf(b), 0 <= b && a.splice(b, 1))
    };

    function I(a) {
        return typeof a === "function"
    };
    var pc = function(a) {
        this.Gh = a;
        this.closed = !1;
        this.Wb = this.zb = null
    };
    n = pc.prototype;
    n.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.zb;
            if (Array.isArray(a))
                for (var b = y(a), c = b.next(); !c.done; c = b.next()) c.value.remove(this);
            else a == null || a.remove(this);
            b = this.Gh;
            if (I(b)) try {
                b()
            } catch (f) {
                var d = f instanceof nc ? f.errors : [f]
            }
            var e = this.Wb;
            if (e)
                for (this.Wb = null, b = y(e), c = b.next(); !c.done; c = b.next()) {
                    c = c.value;
                    try {
                        I(c) ? c() : c.unsubscribe()
                    } catch (f) {
                        c = void 0, d = (c = d) != null ? c : [], f instanceof nc ? d = [].concat(z(d), z(f.errors)) : d.push(f)
                    }
                }
            if (d) throw new nc(d);
        }
    };
    n.add = function(a) {
        if (a && a !== this)
            if (this.closed) I(a) ? a() : a.unsubscribe();
            else {
                if (a instanceof pc) {
                    if (a.closed || a.Og(this)) return;
                    a.Ng(this)
                }
                var b;
                (this.Wb = (b = this.Wb) != null ? b : []).push(a)
            }
    };
    n.Og = function(a) {
        var b = this.zb;
        return b === a || Array.isArray(b) && b.includes(a)
    };
    n.Ng = function(a) {
        var b = this.zb;
        this.zb = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a
    };
    n.Pg = function(a) {
        var b = this.zb;
        b === a ? this.zb = null : Array.isArray(b) && oc(b, a)
    };
    n.remove = function(a) {
        var b = this.Wb;
        b && oc(b, a);
        a instanceof pc && a.Pg(this)
    };
    var qc = new pc;
    qc.closed = !0;
    pc.EMPTY = qc;

    function rc(a) {
        return a instanceof pc || a && "closed" in a && I(a.remove) && I(a.add) && I(a.unsubscribe)
    };
    var sc = function() {
        setTimeout.apply(null, z(B.apply(0, arguments)))
    };

    function tc() {};

    function uc(a) {
        sc(function() {
            throw a;
        })
    };
    var vc = function(a) {
        pc.call(this);
        this.S = !1;
        this.destination = a instanceof vc ? a : new wc(!a || I(a) ? {
            next: a != null ? a : void 0
        } : a);
        rc(a) && a.add(this)
    };
    q(vc, pc);
    vc.EMPTY = pc.EMPTY;
    vc.create = function(a, b, c) {
        return new xc(a, b, c)
    };
    n = vc.prototype;
    n.next = function(a) {
        this.S || this.Gd(a)
    };
    n.error = function(a) {
        this.S || (this.S = !0, this.cf(a))
    };
    n.complete = function() {
        this.S || (this.S = !0, this.Nc())
    };
    n.unsubscribe = function() {
        this.closed || (this.S = !0, pc.prototype.unsubscribe.call(this))
    };
    n.Gd = function(a) {
        this.destination.next(a)
    };
    n.cf = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.Nc = function() {
        this.destination.complete();
        this.unsubscribe()
    };
    var wc = function(a) {
        this.Ae = a
    };
    wc.prototype.next = function(a) {
        var b = this.Ae;
        if (b.next) try {
            b.next(a)
        } catch (c) {
            uc(c)
        }
    };
    wc.prototype.error = function(a) {
        var b = this.Ae;
        if (b.error) try {
            b.error(a)
        } catch (c) {
            uc(c)
        } else uc(a)
    };
    wc.prototype.complete = function() {
        var a = this.Ae;
        if (a.complete) try {
            a.complete()
        } catch (b) {
            uc(b)
        }
    };
    var xc = function(a, b, c) {
        vc.call(this);
        this.destination = new wc(I(a) || !a ? {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0
        } : a)
    };
    q(xc, vc);
    xc.EMPTY = vc.EMPTY;
    xc.create = vc.create;
    var yc = typeof Symbol === "function" && Symbol.observable || "@@observable";

    function zc(a) {
        return a
    };

    function J() {
        return Ac(B.apply(0, arguments))
    }

    function Ac(a) {
        return a.length === 0 ? zc : a.length === 1 ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };
    var K = function(a) {
        a && (this.Ba = a)
    };
    n = K.prototype;
    n.nb = function(a) {
        var b = new K;
        b.source = this;
        b.operator = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        a = a && a instanceof vc || a && I(a.next) && I(a.error) && I(a.complete) && rc(a) ? a : new xc(a, b, c);
        b = this.operator;
        c = this.source;
        a.add(b ? b.call(a, c) : c ? this.Ba(a) : this.Id(a));
        return a
    };
    n.Id = function(a) {
        try {
            return this.Ba(a)
        } catch (b) {
            a.error(b)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = Bc(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (h) {
                    e(h), f == null || f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.Ba = function(a) {
        var b;
        return (b = this.source) == null ? void 0 : b.subscribe(a)
    };
    K.prototype[yc] = function() {
        return this
    };
    K.prototype.g = function() {
        var a = B.apply(0, arguments);
        return a.length ? Ac(a)(this) : this
    };
    K.create = function(a) {
        return new K(a)
    };

    function Bc(a) {
        var b;
        return (b = a != null ? a : void 0) != null ? b : Promise
    };
    var Dc = function() {
        var a = Error.call(this, "object unsubscribed");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "ObjectUnsubscribedError"
    };
    q(Dc, Error);
    var L = function() {
        this.Lb = [];
        this.fd = this.S = this.closed = !1;
        this.Ne = null
    };
    q(L, K);
    n = L.prototype;
    n.nb = function(a) {
        var b = new Fc(this, this);
        b.operator = a;
        return b
    };
    n.Xa = function() {
        if (this.closed) throw new Dc;
    };
    n.next = function(a) {
        this.Xa();
        if (!this.S) {
            var b = this.Lb.slice();
            b = y(b);
            for (var c = b.next(); !c.done; c = b.next()) c.value.next(a)
        }
    };
    n.error = function(a) {
        this.Xa();
        if (!this.S) {
            this.fd = this.S = !0;
            this.Ne = a;
            for (var b = this.Lb; b.length;) b.shift().error(a)
        }
    };
    n.complete = function() {
        this.Xa();
        if (!this.S) {
            this.S = !0;
            for (var a = this.Lb; a.length;) a.shift().complete()
        }
    };
    n.unsubscribe = function() {
        this.S = this.closed = !0;
        this.Lb = null
    };
    n.Id = function(a) {
        this.Xa();
        return K.prototype.Id.call(this, a)
    };
    n.Ba = function(a) {
        this.Xa();
        this.bf(a);
        return this.ef(a)
    };
    n.ef = function(a) {
        var b = this,
            c = this.S,
            d = this.Lb;
        return this.fd || c ? pc.EMPTY : (d.push(a), new pc(function() {
            return oc(b.Lb, a)
        }))
    };
    n.bf = function(a) {
        var b = this.Ne,
            c = this.S;
        this.fd ? a.error(b) : c && a.complete()
    };
    n.T = function() {
        var a = new K;
        a.source = this;
        return a
    };
    L.create = function(a, b) {
        return new Fc(a, b)
    };
    var Fc = function(a, b) {
        L.call(this);
        this.destination = a;
        this.source = b
    };
    q(Fc, L);
    Fc.create = L.create;
    Fc.prototype.next = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.next) == null || c.call(b, a)
    };
    Fc.prototype.error = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.error) == null || c.call(b, a)
    };
    Fc.prototype.complete = function() {
        var a, b;
        (a = this.destination) == null || (b = a.complete) == null || b.call(a)
    };
    Fc.prototype.Ba = function(a) {
        var b, c;
        return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null ? c : pc.EMPTY
    };
    var Gc = function(a) {
        L.call(this);
        this.Jd = a
    };
    q(Gc, L);
    Gc.create = L.create;
    Gc.prototype.Ba = function(a) {
        var b = L.prototype.Ba.call(this, a);
        !b.closed && a.next(this.Jd);
        return b
    };
    Gc.prototype.getValue = function() {
        var a = this.Ne,
            b = this.Jd;
        if (this.fd) throw a;
        this.Xa();
        return b
    };
    Gc.prototype.next = function(a) {
        L.prototype.next.call(this, this.Jd = a)
    };
    ea.Object.defineProperties(Gc.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.getValue()
            }
        }
    });
    var Hc = new K(function(a) {
        return a.complete()
    });

    function Ic(a, b) {
        return new K(function(c) {
            var d = 0;
            return b.H(function() {
                d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.H())
            })
        })
    };

    function Jc(a, b) {
        if (!a) throw Error("s");
        return new K(function(c) {
            var d = new pc;
            d.add(b.H(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.H(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.H())
                    })
                }))
            }));
            return d
        })
    };
    var Kc = typeof Symbol === "function" && Symbol.iterator ? Symbol.iterator : "@@iterator";

    function Lc(a, b, c) {
        b = b.H(function() {
            try {
                c.call(this)
            } catch (d) {
                a.error(d)
            }
        }, 0);
        a.add(b)
    };

    function Mc(a, b) {
        return new K(function(c) {
            var d;
            c.add(b.H(function() {
                d = a[Kc]();
                Lc(c, b, function() {
                    var e = d.next(),
                        f = e.value;
                    e.done ? c.complete() : (c.next(f), this.H())
                })
            }));
            return function() {
                var e;
                return I((e = d) == null ? void 0 : e.return) && d.return()
            }
        })
    };

    function Nc(a, b) {
        return new K(function(c) {
            var d = new pc;
            d.add(b.H(function() {
                var e = a[yc]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.H(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.H(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.H(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function Oc(a, b) {
        return new K(function(c) {
            return b.H(function() {
                return a.then(function(d) {
                    c.add(b.H(function() {
                        c.next(d);
                        c.add(b.H(function() {
                            return c.complete()
                        }))
                    }))
                }, function(d) {
                    c.add(b.H(function() {
                        return c.error(d)
                    }))
                })
            })
        })
    };
    var Pc = function(a) {
        return a && typeof a.length === "number" && typeof a !== "function"
    };

    function Qc(a) {
        return new TypeError("t`" + (a !== null && typeof a === "object" ? "an invalid object" : "'" + a + "'"))
    };

    function Rc(a, b) {
        if (a != null) {
            if (I(a[yc])) return Nc(a, b);
            if (Pc(a)) return Ic(a, b);
            if (I(a == null ? void 0 : a.then)) return Oc(a, b);
            if (Symbol.asyncIterator && I(a == null ? void 0 : a[Symbol.asyncIterator])) return Jc(a, b);
            if (I(a == null ? void 0 : a[Kc])) return Mc(a, b)
        }
        throw Qc(a);
    };

    function Sc(a, b) {
        return b ? Rc(a, b) : Tc(a)
    }

    function Tc(a) {
        if (a instanceof K) return a;
        if (a != null) {
            if (I(a[yc])) return Uc(a);
            if (Pc(a)) return Vc(a);
            if (I(a == null ? void 0 : a.then)) return Wc(a);
            if (Symbol.asyncIterator && I(a == null ? void 0 : a[Symbol.asyncIterator])) return Xc(a);
            if (I(a == null ? void 0 : a[Kc])) return Yc(a)
        }
        throw Qc(a);
    }

    function Uc(a) {
        return new K(function(b) {
            var c = a[yc]();
            if (I(c.subscribe)) return c.subscribe(b);
            throw new TypeError("u");
        })
    }

    function Vc(a) {
        return new K(function(b) {
            for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
            b.complete()
        })
    }

    function Wc(a) {
        return new K(function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, uc)
        })
    }

    function Yc(a) {
        return new K(function(b) {
            for (var c = a[Kc](); !b.closed;) {
                var d = c.next(),
                    e = d.value;
                d.done ? b.complete() : b.next(e)
            }
            return function() {
                return I(c == null ? void 0 : c.return) && c.return()
            }
        })
    }

    function Xc(a) {
        return new K(function(b) {
            Zc(a, b).catch(function(c) {
                return b.error(c)
            })
        })
    }

    function Zc(a, b) {
        var c, d, e, f, g, h;
        return Ha(function(k) {
            switch (k.u) {
                case 1:
                    wa(k, 2, 3);
                    var l = a[Symbol.asyncIterator];
                    f = l !== void 0 ? l.call(a) : new Ja(y(a));
                case 5:
                    return va(k, f.next(), 8);
                case 8:
                    d = k.ba;
                    if (d.done) {
                        k.Ia(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    k.Ia(5);
                    break;
                case 3:
                    ya(k);
                    k.wa = 0;
                    k.Fa = 9;
                    if (!d || d.done || !(e = f.return)) {
                        k.Ia(9);
                        break
                    }
                    return va(k, e.call(f), 9);
                case 9:
                    ya(k, 0, 0, 1);
                    if (c) throw c.error;
                    za(k, 10, 1);
                    break;
                case 10:
                    za(k, 4);
                    break;
                case 2:
                    h = xa(k);
                    c = {
                        error: h
                    };
                    k.Ia(3);
                    break;
                case 4:
                    b.complete(), k.u = 0
            }
        })
    };

    function $c(a, b) {
        return b ? Ic(a, b) : Vc(a)
    };

    function ad(a) {
        return I(a[a.length - 1]) ? a.pop() : void 0
    }

    function bd(a) {
        var b = a[a.length - 1];
        return b && I(b.H) ? a.pop() : void 0
    };

    function M() {
        var a = B.apply(0, arguments),
            b = bd(a);
        return b ? Ic(a, b) : $c(a)
    };

    function cd(a) {
        var b = I(a) ? a : function() {
            return a
        };
        return new K(function(c) {
            return c.error(b())
        })
    };
    var dd = {
        now: function() {
            return (dd.jh || Date).now()
        },
        jh: void 0
    };
    var ed = function(a, b, c) {
        a = a === void 0 ? Infinity : a;
        b = b === void 0 ? Infinity : b;
        c = c === void 0 ? dd : c;
        L.call(this);
        this.bufferSize = a;
        this.Hg = b;
        this.Bg = c;
        this.buffer = [];
        this.le = b === Infinity;
        this.bufferSize = Math.max(1, a);
        this.Hg = Math.max(1, b)
    };
    q(ed, L);
    ed.create = L.create;
    ed.prototype.next = function(a) {
        var b = this.buffer,
            c = this.le,
            d = this.Bg,
            e = this.Hg;
        this.S || (b.push(a), !c && b.push(d.now() + e));
        fd(this);
        L.prototype.next.call(this, a)
    };
    ed.prototype.Ba = function(a) {
        this.Xa();
        fd(this);
        for (var b = this.ef(a), c = this.le, d = this.buffer.slice(), e = 0; e < d.length && !a.closed; e += c ? 1 : 2) a.next(d[e]);
        this.bf(a);
        return b
    };
    var fd = function(a) {
        var b = a.bufferSize,
            c = a.Bg,
            d = a.buffer;
        a = a.le;
        var e = (a ? 1 : 2) * b;
        b < Infinity && e < d.length && d.splice(0, d.length - e);
        if (!a) {
            b = c.now();
            c = 0;
            for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
            c && d.splice(0, c + 1)
        }
    };
    var hd = function(a, b) {
        b = b === void 0 ? gd : b;
        this.Ei = a;
        this.now = b
    };
    hd.prototype.H = function(a, b, c) {
        b = b === void 0 ? 0 : b;
        return (new this.Ei(this, a)).H(c, b)
    };
    var gd = dd.now;
    var id = function() {
        var a = Error.call(this, "no elements in sequence");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "EmptyError"
    };
    q(id, Error);

    function jd(a) {
        return new Promise(function(b, c) {
            var d = new xc({
                next: function(e) {
                    b(e);
                    d.unsubscribe()
                },
                error: c,
                complete: function() {
                    c(new id)
                }
            });
            a.subscribe(d)
        })
    };
    var kd = function(a, b, c, d, e) {
        vc.call(this, a);
        this.ki = e;
        b && (this.Gd = function(f) {
            try {
                b(f)
            } catch (g) {
                this.destination.error(g)
            }
        });
        c && (this.cf = function(f) {
            try {
                c(f)
            } catch (g) {
                this.destination.error(g)
            }
            this.unsubscribe()
        });
        d && (this.Nc = function() {
            try {
                d()
            } catch (f) {
                this.destination.error(f)
            }
            this.unsubscribe()
        })
    };
    q(kd, vc);
    kd.EMPTY = vc.EMPTY;
    kd.create = vc.create;
    kd.prototype.unsubscribe = function() {
        var a;
        this.closed || (a = this.ki) != null && a.call(this);
        vc.prototype.unsubscribe.call(this)
    };

    function ld(a) {
        return function(b) {
            if (I(b == null ? void 0 : b.nb)) return b.nb(function(c) {
                try {
                    return a(c, this)
                } catch (d) {
                    this.error(d)
                }
            });
            throw new TypeError("v");
        }
    };

    function md() {
        return ld(function(a, b) {
            var c = null;
            a.Oc++;
            var d = new kd(b, void 0, void 0, void 0, function() {
                if (!a || a.Oc <= 0 || 0 < --a.Oc) c = null;
                else {
                    var e = a.yb,
                        f = c;
                    c = null;
                    !e || f && e !== f || e.unsubscribe();
                    b.unsubscribe()
                }
            });
            a.subscribe(d);
            d.closed || (c = a.connect())
        })
    };
    var nd = function(a, b) {
        this.source = a;
        this.vg = b;
        this.Pc = null;
        this.Oc = 0;
        this.yb = null
    };
    q(nd, K);
    nd.create = K.create;
    nd.prototype.Ba = function(a) {
        return od(this).subscribe(a)
    };
    var od = function(a) {
        var b = a.Pc;
        if (!b || b.S) a.Pc = a.vg();
        return a.Pc
    };
    nd.prototype.Hd = function() {
        this.Oc = 0;
        var a = this.yb;
        this.Pc = this.yb = null;
        a == null || a.unsubscribe()
    };
    nd.prototype.connect = function() {
        var a = this,
            b = this.yb;
        if (!b) {
            b = this.yb = new pc;
            var c = od(this);
            b.add(this.source.subscribe(new kd(c, void 0, function(d) {
                a.Hd();
                c.error(d)
            }, function() {
                a.Hd();
                c.complete()
            }, function() {
                return a.Hd()
            })));
            b.closed && (this.yb = null, b = pc.EMPTY)
        }
        return b
    };

    function qd() {
        var a = rd;
        var b = b === void 0 ? 0 : b;
        return ld(function(c, d) {
            d.add(a.H(function() {
                return c.subscribe(d)
            }, b))
        })
    };

    function N(a) {
        return ld(function(b, c) {
            var d = 0;
            b.subscribe(new kd(c, function(e) {
                c.next(a.call(void 0, e, d++))
            }))
        })
    };
    var sd = Array.isArray;

    function td(a) {
        return N(function(b) {
            return sd(b) ? a.apply(null, z(b)) : a(b)
        })
    };
    var ud = Array.isArray,
        vd = Object,
        wd = vd.getPrototypeOf,
        xd = vd.prototype,
        yd = vd.keys;

    function zd(a) {
        if (a.length === 1) {
            var b = a[0];
            if (ud(b)) return {
                args: b,
                keys: null
            };
            if (b && typeof b === "object" && wd(b) === xd) return a = yd(b), {
                args: a.map(function(c) {
                    return b[c]
                }),
                keys: a
            }
        }
        return {
            args: a,
            keys: null
        }
    };

    function Ad() {
        var a = B.apply(0, arguments),
            b = bd(a),
            c = ad(a);
        a = zd(a);
        var d = a.args,
            e = a.keys;
        if (d.length === 0) return Sc([], b);
        b = new K(Bd(d, b, e ? function(f) {
            for (var g = {}, h = 0; h < f.length; h++) g[e[h]] = f[h];
            return g
        } : zc));
        return c ? b.g(td(c)) : b
    }
    var Cd = function(a, b, c) {
        vc.call(this, a);
        this.Gd = b;
        this.Ji = c
    };
    q(Cd, vc);
    Cd.EMPTY = vc.EMPTY;
    Cd.create = vc.create;
    Cd.prototype.Nc = function() {
        this.Ji() ? vc.prototype.Nc.call(this) : this.unsubscribe()
    };

    function Bd(a, b, c) {
        c = c === void 0 ? zc : c;
        return function(d) {
            Dd(b, function() {
                for (var e = a.length, f = Array(e), g = e, h = a.map(function() {
                        return !1
                    }), k = !0, l = {
                        ib: 0
                    }; l.ib < e; l = {
                        ib: l.ib
                    }, l.ib++) Dd(b, function(m) {
                    return function() {
                        Sc(a[m.ib], b).subscribe(new Cd(d, function(u) {
                            f[m.ib] = u;
                            k && (h[m.ib] = !0, k = !h.every(zc));
                            k || d.next(c(f.slice()))
                        }, function() {
                            return --g === 0
                        }))
                    }
                }(l), d)
            }, d)
        }
    }

    function Dd(a, b, c) {
        a ? c.add(a.H(b)) : b()
    };

    function Ed(a, b, c, d) {
        var e = [],
            f = 0,
            g = 0,
            h = !1,
            k = function(l) {
                f++;
                Tc(c(l, g++)).subscribe(new kd(b, function(m) {
                    b.next(m)
                }, void 0, function() {
                    f--;
                    for (var m = {}; e.length && f < d; m = {
                            mf: void 0
                        }) m.mf = e.shift(), k(m.mf);
                    !h || e.length || f || b.complete()
                }))
            };
        a.subscribe(new kd(b, function(l) {
            return f < d ? k(l) : e.push(l)
        }, void 0, function() {
            h = !0;
            !h || e.length || f || b.complete()
        }));
        return function() {
            e = null
        }
    };

    function Fd(a, b) {
        var c = c === void 0 ? Infinity : c;
        if (I(b)) return Fd(function(d, e) {
            return N(function(f, g) {
                return b(d, f, e, g)
            })(Tc(a(d, e)))
        }, c);
        typeof b === "number" && (c = b);
        return ld(function(d, e) {
            return Ed(d, e, a, c)
        })
    };

    function Gd(a) {
        a = a === void 0 ? Infinity : a;
        return Fd(zc, a)
    };

    function Hd() {
        var a = B.apply(0, arguments);
        return Gd(1)($c(a, bd(a)))
    };

    function Id(a) {
        return new K(function(b) {
            Tc(a()).subscribe(b)
        })
    };
    var Jd = ["addListener", "removeListener"],
        Kd = ["addEventListener", "removeEventListener"],
        Ld = ["on", "off"];

    function Md(a, b, c) {
        if (I(c)) {
            var d = c;
            c = void 0
        }
        if (d) return Md(a, b, c).g(td(d));
        d = y(I(a.addEventListener) && I(a.removeEventListener) ? Kd.map(function(g) {
            return function(h) {
                return a[g](b, h, c)
            }
        }) : I(a.addListener) && I(a.removeListener) ? Jd.map(Nd(a, b)) : I(a.Zj) && I(a.Mj) ? Ld.map(Nd(a, b)) : []);
        var e = d.next().value,
            f = d.next().value;
        return !e && Pc(a) ? Fd(function(g) {
            return Md(g, b, c)
        })($c(a)) : new K(function(g) {
            if (!e) throw new TypeError("w");
            var h = function() {
                var k = B.apply(0, arguments);
                return g.next(1 < k.length ? k : k[0])
            };
            e(h);
            return function() {
                return f(h)
            }
        })
    }

    function Nd(a, b) {
        return function(c) {
            return function(d) {
                return a[c](b, d)
            }
        }
    };
    var Od = function() {
        pc.call(this)
    };
    q(Od, pc);
    Od.EMPTY = pc.EMPTY;
    Od.prototype.H = function() {
        return this
    };
    var Pd = function(a, b) {
        return setInterval.apply(null, [a, b].concat(z(B.apply(2, arguments))))
    };
    var Qd = function(a, b) {
        pc.call(this);
        this.scheduler = a;
        this.Ve = b;
        this.pending = !1
    };
    q(Qd, Od);
    Qd.EMPTY = Od.EMPTY;
    Qd.prototype.H = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.scheduler;
        a != null && (this.id = Rd(this, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.He(c, this.id, b);
        return this
    };
    Qd.prototype.He = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return Pd(a.flush.bind(a, this), c)
    };
    var Rd = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        if (c != null && a.delay === c && a.pending === !1) return b;
        clearInterval(b)
    };
    Qd.prototype.execute = function(a, b) {
        if (this.closed) return Error("x");
        this.pending = !1;
        if (a = this.df(a, b)) return a;
        this.pending === !1 && this.id != null && (this.id = Rd(this, this.id, null))
    };
    Qd.prototype.df = function(a) {
        var b = !1;
        try {
            this.Ve(a)
        } catch (d) {
            b = !0;
            var c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    Qd.prototype.unsubscribe = function() {
        if (!this.closed) {
            var a = this.id,
                b = this.scheduler.actions;
            this.Ve = this.state = this.scheduler = null;
            this.pending = !1;
            oc(b, this);
            a != null && (this.id = Rd(this, a, null));
            this.delay = null;
            Od.prototype.unsubscribe.call(this)
        }
    };
    var Sd = function(a, b) {
        b = b === void 0 ? gd : b;
        hd.call(this, a, b);
        this.actions = [];
        this.active = !1
    };
    q(Sd, hd);
    Sd.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function Td() {
        var a = B.apply(0, arguments),
            b = bd(a);
        var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
        return a.length ? a.length === 1 ? Tc(a[0]) : Gd(c)($c(a, b)) : Hc
    };
    var Ud = new K(tc);
    var Vd = Array.isArray;

    function Wd(a) {
        return a.length === 1 && Vd(a[0]) ? a[0] : a
    };

    function Xd() {
        var a = Wd(B.apply(0, arguments));
        return ld(function(b, c) {
            var d = [b].concat(z(a)),
                e = function() {
                    if (!c.closed)
                        if (d.length > 0) {
                            try {
                                var f = Tc(d.shift())
                            } catch (h) {
                                e();
                                return
                            }
                            var g = new kd(c, void 0, tc, tc);
                            c.add(f.subscribe(g));
                            g.add(e)
                        } else c.complete()
                };
            e()
        })
    };

    function O(a) {
        return ld(function(b, c) {
            var d = 0;
            b.subscribe(new kd(c, function(e) {
                return a.call(void 0, e, d++) && c.next(e)
            }))
        })
    };

    function Yd() {
        var a = B.apply(0, arguments);
        a = Wd(a);
        return a.length === 1 ? Tc(a[0]) : new K(Zd(a))
    }

    function Zd(a) {
        return function(b) {
            for (var c = [], d = {
                    Db: 0
                }; c && !b.closed && d.Db < a.length; d = {
                    Db: d.Db
                }, d.Db++) c.push(Tc(a[d.Db]).subscribe(new kd(b, function(e) {
                return function(f) {
                    if (c) {
                        for (var g = 0; g < c.length; g++) g !== e.Db && c[g].unsubscribe();
                        c = null
                    }
                    b.next(f)
                }
            }(d))))
        }
    };

    function $d() {
        var a = B.apply(0, arguments),
            b = ad(a),
            c = Wd(a);
        return c.length ? new K(function(d) {
            var e = c.map(function() {
                    return []
                }),
                f = c.map(function() {
                    return !1
                });
            d.add(function() {
                e = f = null
            });
            for (var g = {
                    Ua: 0
                }; !d.closed && g.Ua < c.length; g = {
                    Ua: g.Ua
                }, g.Ua++) Tc(c[g.Ua]).subscribe(new kd(d, function(h) {
                    return function(k) {
                        e[h.Ua].push(k);
                        e.every(function(l) {
                            return l.length
                        }) && (k = e.map(function(l) {
                            return l.shift()
                        }), d.next(b ? b.apply(null, z(k)) : k), e.some(function(l, m) {
                            return !l.length && f[m]
                        }) && d.complete())
                    }
                }(g), void 0,
                function(h) {
                    return function() {
                        f[h.Ua] = !0;
                        !e[h.Ua].length && d.complete()
                    }
                }(g)));
            return function() {
                e = f = null
            }
        }) : Hc
    };
    var ae = function(a, b) {
        Qd.call(this, a, b);
        this.scheduler = a;
        this.Ve = b
    };
    q(ae, Qd);
    ae.EMPTY = Qd.EMPTY;
    ae.prototype.H = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (b > 0) return Qd.prototype.H.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.scheduler.flush(this);
        return this
    };
    ae.prototype.execute = function(a, b) {
        return b > 0 || this.closed ? Qd.prototype.execute.call(this, a, b) : this.df(a, b)
    };
    ae.prototype.He = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return c != null && c > 0 || c == null && this.delay > 0 ? Qd.prototype.He.call(this, a, b, c) : a.flush(this)
    };
    var be = function() {
        Sd.apply(this, arguments)
    };
    q(be, Sd);
    var rd = new be(ae);
    var ce = function() {
        this.I = new Va;
        this.i = new Wa;
        this.Lh = Symbol();
        this.fc = new mc
    };
    ce.prototype.ee = function() {
        return Ud
    };
    var de = function(a, b) {
            a.Da !== null && a.Da.next(b)
        },
        ee = function(a) {
            if ((typeof a === "bigint" || typeof a === "number" || typeof a === "string") && typeof BigInt === "function") return BigInt(a)
        };
    ea.Object.defineProperties(ce.prototype, {
        tb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Lh
            }
        }
    });
    var fe = function(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = fe.prototype;
        this.name = String(a)
    };
    q(fe, Error);
    var ge = function(a) {
        fe.call(this, 1E3, 'sfr:"' + a + '"');
        this.Zh = a;
        this.__proto__ = ge.prototype
    };
    q(ge, fe);
    var he = function() {
        fe.call(this, 1003);
        this.__proto__ = he.prototype
    };
    q(he, fe);
    var ie = function() {
        fe.call(this, 1009);
        this.__proto__ = ie.prototype
    };
    q(ie, fe);
    var je = function() {
        fe.call(this, 1011);
        this.__proto__ = je.prototype
    };
    q(je, fe);
    var ke = function() {
        fe.call(this, 1007);
        this.__proto__ = he.prototype
    };
    q(ke, fe);
    var le = function() {
        fe.call(this, 1008);
        this.__proto__ = he.prototype
    };
    q(le, fe);
    var me = function() {
        fe.call(this, 1001);
        this.__proto__ = me.prototype
    };
    q(me, fe);
    var ne = function(a) {
        fe.call(this, 1004, String(a));
        this.Hh = a;
        this.__proto__ = ne.prototype
    };
    q(ne, fe);
    var pe = function(a) {
        fe.call(this, 1010, a);
        this.__proto__ = oe.prototype
    };
    q(pe, fe);
    var oe = function(a) {
        fe.call(this, 1005, a);
        this.__proto__ = oe.prototype
    };
    q(oe, fe);
    var qe = function(a) {
        var b = B.apply(1, arguments),
            c = this;
        this.Nb = [];
        this.Nb.push(a);
        b.forEach(function(d) {
            c.Nb.push(d)
        })
    };
    qe.prototype.M = function(a) {
        return this.Nb.some(function(b) {
            return b.M(a)
        })
    };
    qe.prototype.K = function(a, b) {
        for (var c = 0; c < this.Nb.length; c++)
            if (this.Nb[c].M(b)) return this.Nb[c].K(a, b);
        throw new ie;
    };

    function re(a) {
        var b, c, d;
        return !!a && typeof a.active === "boolean" && typeof((b = a.clock) == null ? void 0 : b.now) === "function" && ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 && !((d = a.F) == null || !d.timestamp) && typeof a.Z === "function" && typeof a.ka === "function" && typeof a.ra === "function" && typeof a.map === "function" && typeof a.ta === "function"
    };
    var se = Symbol("time-origin"),
        te = Symbol("date"),
        ue = function(a, b) {
            this.value = a;
            this.timeline = b
        },
        ve = function(a, b) {
            if (b.timeline !== a.timeline) throw new ke;
        },
        we = function(a, b) {
            ve(a, b);
            return a.value - b.value
        };
    n = ue.prototype;
    n.equals = function(a) {
        return we(this, a) === 0
    };
    n.maximum = function(a) {
        ve(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new ue(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new ue(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function xe(a) {
        function b(c) {
            return typeof c === "boolean" || typeof c === "string" || typeof c === "number" || c === void 0 || c === null
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : typeof a === "object" ? Object.keys(a).every(function(c) {
            return typeof c === "string"
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function ye(a) {
        if (xe(a)) return a;
        if (re(a)) return {
            F: {
                value: ye(a.F.value),
                timestamp: we(a.F.timestamp, new ue(0, a.F.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };
    var ze = {
        aj: "app",
        zj: "web"
    };
    var Ae = ["sessionStart", "sessionError", "sessionFinish"],
        Be = function(a, b) {
            this.ea = a;
            this.Cd = b;
            this.ready = !1;
            this.ob = [];
            this.pg = function() {};
            this.Fg = function() {};
            this.Df = function() {};
            this.Of = function() {};
            this.td = function() {}
        },
        Ee = function(a, b) {
            a.pg = b
        },
        Fe = function(a, b) {
            a.Fg = b
        },
        Ge = function(a, b) {
            a.Df = b
        },
        He = function(a, b) {
            a.Of = b
        },
        Ie = function(a, b) {
            a.td = b;
            a.td(a.ob.length)
        },
        Ne = function(a) {
            for (var b = y("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")),
                    c = b.next(); !c.done; c = b.next()) a.ea.addEventListener(c.value, function(d) {
                Je(a, d)
            });
            Ke(a.ea, function(d) {
                d.type !== "sessionStart" && Je(a, d)
            }, a.Cd);
            Ke(a.ea, function(d) {
                d.type === "sessionStart" && (Je(a, d), Le(a), Me(a))
            }, a.Cd)
        },
        Je = function(a, b) {
            a.ob.push(b);
            a.td(a.ob.length);
            Me(a)
        },
        Me = function(a) {
            if (a.ready)
                for (; a.ob.length > 0;) {
                    var b = a.ob.pop();
                    b !== void 0 && (b.type === "geometryChange" ? a.Df(b) : b.type === "impression" ? a.Of(b) : Ae.includes(b.type) ? a.pg(b) : a.Fg(b));
                    a.td(a.ob.length)
                }
        },
        Le = function(a) {
            a.ready || (a.ready = !0, a.ob.sort(function(b, c) {
                return c.timestamp - b.timestamp
            }))
        };

    function Oe(a) {
        return ld(function(b, c) {
            var d = null,
                e = !1,
                f;
            d = b.subscribe(new kd(c, void 0, function(g) {
                f = Tc(a(g, Oe(a)(b)));
                d ? (d.unsubscribe(), d = null, f.subscribe(c)) : e = !0
            }));
            e && (d.unsubscribe(), d = null, f.subscribe(c))
        })
    };

    function Pe(a, b, c) {
        return function(d, e) {
            var f = c,
                g = b,
                h = 0;
            d.subscribe(new kd(e, function(k) {
                var l = h++;
                g = f ? a(g, k, l) : (f = !0, k);
                e.next(g)
            }, void 0, void 0))
        }
    };

    function Qe() {
        var a = B.apply(0, arguments),
            b = ad(a);
        return b ? J(Qe.apply(null, z(a)), td(b)) : ld(function(c, d) {
            Bd([c].concat(z(Wd(a))))(d)
        })
    }

    function Re() {
        return Qe.apply(null, z(B.apply(0, arguments)))
    };

    function Se(a) {
        a = a === void 0 ? null : a;
        return ld(function(b, c) {
            var d = !1;
            b.subscribe(new kd(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                d || c.next(a);
                c.complete()
            }))
        })
    };

    function Te() {
        return ld(function(a, b) {
            a.subscribe(new kd(b, tc))
        })
    };

    function Ue(a) {
        return ld(function(b, c) {
            b.subscribe(new kd(c, function() {
                return c.next(a)
            }))
        })
    };

    function Ve(a) {
        return a <= 0 ? function() {
            return Hc
        } : ld(function(b, c) {
            var d = 0;
            b.subscribe(new kd(c, function(e) {
                ++d <= a && (c.next(e), a <= d && c.complete())
            }))
        })
    };

    function We(a) {
        return Fd(function(b, c) {
            return a(b, c).g(Ve(1), Ue(b))
        })
    };

    function Xe(a) {
        return ld(function(b, c) {
            var d = new Set;
            b.subscribe(new kd(c, function(e) {
                var f = a ? a(e) : e;
                d.has(f) || (d.add(f), c.next(e))
            }))
        })
    };

    function Q(a) {
        var b = b === void 0 ? zc : b;
        var c;
        a = (c = a) != null ? c : Ye;
        return ld(function(d, e) {
            var f, g = !0;
            d.subscribe(new kd(e, function(h) {
                var k = b(h);
                if (g || !a(f, k)) g = !1, f = k, e.next(h)
            }))
        })
    }

    function Ye(a, b) {
        return a === b
    };

    function Ze(a) {
        a = a === void 0 ? $e : a;
        return ld(function(b, c) {
            var d = !1;
            b.subscribe(new kd(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                return d ? c.complete() : c.error(a())
            }))
        })
    }

    function $e() {
        return new id
    };

    function af() {
        var a = B.apply(0, arguments);
        return function(b) {
            return Hd(b, M.apply(null, z(a)))
        }
    };

    function bf(a) {
        return ld(function(b, c) {
            var d = 0;
            b.subscribe(new kd(c, function(e) {
                a.call(void 0, e, d++, b) || (c.next(!1), c.complete())
            }, void 0, function() {
                c.next(!0);
                c.complete()
            }))
        })
    };

    function cf() {
        return ld(function(a, b) {
            var c = [];
            a.subscribe(new kd(b, function(d) {
                c.push(d);
                1 < c.length && c.shift()
            }, void 0, function() {
                for (var d = y(c), e = d.next(); !e.done; e = d.next()) b.next(e.value);
                b.complete()
            }, function() {
                c = null
            }))
        })
    };

    function df(a, b) {
        var c = arguments.length >= 2;
        return function(d) {
            return d.g(a ? O(function(e, f) {
                return a(e, f, d)
            }) : zc, cf(), c ? Se(b) : Ze(function() {
                return new id
            }))
        }
    };

    function ef(a) {
        var b = I(a) ? a : function() {
            return a
        };
        return I() ? ld(function(c, d) {
            var e = b();
            (void 0)(e).subscribe(d).add(c.subscribe(e))
        }) : function(c) {
            var d = new nd(c, b);
            I(c == null ? void 0 : c.nb) && (d.nb = c.nb);
            d.source = c;
            d.vg = b;
            return d
        }
    };

    function ff(a) {
        var b = new ed(a, void 0, void 0);
        return function(c) {
            return ef(function() {
                return b
            })(c)
        }
    };

    function gf() {
        var a = a === void 0 ? Infinity : a;
        return a <= 0 ? function() {
            return Hc
        } : ld(function(b, c) {
            var d = 0,
                e, f = function() {
                    var g = !1;
                    e = b.subscribe(new kd(c, void 0, void 0, function() {
                        ++d < a ? e ? (e.unsubscribe(), e = null, f()) : g = !0 : c.complete()
                    }));
                    g && (e.unsubscribe(), e = null, f())
                };
            f()
        })
    };

    function hf(a, b) {
        return ld(Pe(a, b, arguments.length >= 2))
    };

    function jf() {
        var a = a || {};
        var b = a.bh === void 0 ? function() {
                return new L
            } : a.bh,
            c = a.xi === void 0 ? !0 : a.xi,
            d = a.yi === void 0 ? !0 : a.yi,
            e = a.zi === void 0 ? !0 : a.zi;
        return function(f) {
            var g = null,
                h = null,
                k = 0,
                l = !1,
                m = !1,
                u = function() {
                    g = h = null;
                    l = m = !1
                };
            return ld(function(r, t) {
                k++;
                var w;
                h = (w = h) != null ? w : b();
                t.add(function() {
                    k--;
                    if (e && !k && !m && !l) {
                        var v = g;
                        u();
                        v == null || v.unsubscribe()
                    }
                });
                h.subscribe(t);
                !g && k > 0 && (g = new xc({
                    next: function(v) {
                        return h.next(v)
                    },
                    error: function(v) {
                        m = !0;
                        var x = h;
                        d && u();
                        x.error(v)
                    },
                    complete: function() {
                        l = !0;
                        var v = h;
                        c && u();
                        v.complete()
                    }
                }), Sc(r).subscribe(g))
            })(f)
        }
    };

    function R() {
        var a = B.apply(0, arguments),
            b = bd(a);
        return ld(function(c, d) {
            (b ? Hd(a, c, b) : Hd(a, c)).subscribe(d)
        })
    };

    function T(a) {
        return ld(function(b, c) {
            var d = null,
                e = 0,
                f = !1;
            b.subscribe(new kd(c, function(g) {
                var h;
                (h = d) == null || h.unsubscribe();
                h = e++;
                Tc(a(g, h)).subscribe(d = new kd(c, function(k) {
                    return c.next(k)
                }, void 0, function() {
                    d = null;
                    f && !d && c.complete()
                }))
            }, void 0, function() {
                (f = !0, !d) && c.complete()
            }))
        })
    };

    function kf(a, b) {
        b = b === void 0 ? !1 : b;
        return ld(function(c, d) {
            var e = 0;
            c.subscribe(new kd(d, function(f) {
                var g = a(f, e++);
                (g || b) && d.next(f);
                !g && d.complete()
            }))
        })
    };

    function lf(a, b, c) {
        var d = I(a) || b || c ? {
            next: a,
            error: b,
            complete: c
        } : a;
        return d ? ld(function(e, f) {
            e.subscribe(new kd(f, function(g) {
                var h;
                (h = d.next) == null || h.call(d, g);
                f.next(g)
            }, function(g) {
                var h;
                (h = d.error) == null || h.call(d, g);
                f.error(g)
            }, function() {
                var g;
                (g = d.complete) == null || g.call(d);
                f.complete()
            }))
        }) : zc
    };

    function mf() {
        var a = B.apply(0, arguments),
            b = ad(a);
        return ld(function(c, d) {
            for (var e = a.length, f = Array(e), g = a.map(function() {
                    return !1
                }), h = !1, k = {
                    Pa: 0
                }; k.Pa < e; k = {
                    Pa: k.Pa
                }, k.Pa++) Tc(a[k.Pa]).subscribe(new kd(d, function(l) {
                return function(m) {
                    f[l.Pa] = m;
                    h || g[l.Pa] || (g[l.Pa] = !0, (h = g.every(zc)) && (g = null))
                }
            }(k), void 0, tc));
            c.subscribe(new kd(d, function(l) {
                h && (l = [l].concat(z(f)), d.next(b ? b.apply(null, z(l)) : l))
            }))
        })
    };
    var nf = function(a) {
        this.ea = a
    };
    nf.prototype.M = function(a) {
        return (a == null ? 0 : a.Xb) ? !0 : (a == null ? void 0 : a.ia) === "POST" || (a == null ? 0 : a.eb) || (a == null ? 0 : a.Zc) ? !1 : this.ea.M()
    };
    nf.prototype.ping = function() {
        var a = this,
            b = M.apply(null, z(B.apply(0, arguments))).g(Fd(function(c) {
                return of(a, c)
            }), bf(function(c) {
                return c
            }), ff(1));
        b.connect();
        return b
    };
    var of = function(a, b) {
        var c = new ed(1);
        pf(a.ea, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    };
    nf.prototype.sd = function(a, b, c) {
        this.ping.apply(this, z(B.apply(3, arguments)))
    };

    function qf(a, b) {
        var c = !1;
        return new K(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };
    var rf = function(a) {
        this.ea = a;
        this.timeline = te
    };
    n = rf.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.ea.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.ea.clearTimeout(a)
    };
    n.now = function() {
        return new ue(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Ha(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ha = function(a) {
        return qf(this, a).g(gf(), hf(function(b) {
            return b + 1
        }, -1))
    };
    n.ha = function() {
        return !0
    };
    var sf = function(a, b) {
        this.context = a;
        this.Ob = b
    };
    sf.prototype.M = function(a) {
        return this.Ob.M(a)
    };
    sf.prototype.K = function(a, b) {
        if (!this.M(b)) throw new ie;
        return new tf(this.context, this.Ob, b != null ? b : void 0, a)
    };
    var tf = function(a, b, c, d) {
        var e = this;
        this.Ob = b;
        this.properties = c;
        this.url = d;
        this.kd = !0;
        this.eb = new Map;
        this.body = void 0;
        var f;
        this.method = (f = c == null ? void 0 : c.ia) != null ? f : "GET";
        this.Vg = a.ee().subscribe(function() {
            e.sendNow()
        })
    };
    tf.prototype.deactivate = function() {
        this.kd = !1
    };
    tf.prototype.sendNow = function() {
        if (this.kd)
            if (this.Vg.unsubscribe(), this.Ob.M(this.properties)) try {
                if (this.eb.size > 0 || this.body !== void 0) {
                    var a, b;
                    this.Ob.sd((a = this.properties) != null ? a : {}, this.eb, (b = this.body) != null ? b : "", this.url)
                } else this.Ob.ping(this.url);
                this.kd = !1
            } catch (c) {} else this.kd = !1
    };
    var vf = function(a, b, c, d, e, f) {
            this.mode = a;
            this.m = b;
            this.setTime = c;
            this.Dc = d;
            this.Pi = e;
            this.ah = f;
            this.completed = !1;
            this.id = this.mode === 0 ? uf(this) : 0
        },
        uf = function(a) {
            return a.m.setTimeout(function() {
                wf(a)
            }, a.Dc)
        },
        xf = function(a, b) {
            var c = we(b, a.setTime);
            c >= a.Dc ? wf(a) : (a.setTime = b, a.Dc -= c)
        },
        wf = function(a) {
            try {
                a.Pi(a.setTime.add(a.Dc))
            } finally {
                a.completed = !0, a.ah()
            }
        };
    vf.prototype.Re = function(a, b) {
        this.completed || (this.mode === 1 && a === 1 ? xf(this, b) : this.mode === 1 && a === 0 ? (this.mode = a, xf(this, this.m.now()), this.completed || (this.id = uf(this))) : this.mode === 0 && a === 1 && (this.mode = a, this.clear(), xf(this, b)))
    };
    vf.prototype.clear = function() {
        this.completed || this.m.clearTimeout(this.id)
    };
    var yf = function(a) {
        this.ad = a;
        this.Jh = this.mode = 0;
        this.Hb = {};
        this.timeline = a.timeline;
        this.mb = a.now()
    };
    n = yf.prototype;
    n.Re = function(a, b) {
        this.mode = a;
        ve(this.mb, b);
        this.mb = b;
        Object.values(this.Hb).forEach(function(c) {
            return void c.Re(a, b)
        })
    };
    n.now = function() {
        return this.mode === 1 ? this.mb : this.ad.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.Jh,
            e = this.mode === 1 ? this.mb : this.ad.now();
        this.Hb[d] = new vf(this.mode, this.ad, e, b, function(f) {
            var g = c.mb;
            c.mode === 1 && (c.mb = f);
            a();
            c.mb = g
        }, function() {
            delete c.Hb[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.Hb[a] && (this.Hb[a].clear(), delete this.Hb[a])
    };
    n.interval = function() {
        throw Error("y");
    };
    n.Ha = function() {
        throw Error("z");
    };
    n.ha = function() {
        return this.ad.ha()
    };

    function zf(a, b) {
        var c = new yf(a);
        a = b.subscribe(function(d) {
            c.Re(d.value ? 1 : 0, d.timestamp)
        });
        return {
            m: c,
            Lj: a
        }
    };

    function Af(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new ue(a.timestamp, te),
            value: b
        }
    };

    function Bf(a) {
        return a !== void 0 && typeof a.x === "number" && typeof a.y === "number" && typeof a.width === "number" && typeof a.height === "number"
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function Cf(a) {
        var b = B.apply(1, arguments),
            c = b.length;
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !tb && a === a.raw || !(tb && !ub || rb(a)) || c + 1 !== a.length) throw new TypeError("q");
        if (b.length === 0) return gb(a[0]);
        c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("G");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("A");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("B");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("C");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("D");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if (c === "/" || c.length > 1 && c[1] !== "/" && c[1] !== "\\") d = !0;
                else throw Error("F");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if (c !== "about:blank" && !/^about:blank#/.test(c)) throw Error("E");
                d = !0
            } else d = !1;
        if (!d) throw Error("H");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return gb(c)
    };
    var Df = ra(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Ef = ra(["./reach_worklet.js"]),
        Ff = ra(["./reach_worklet.js"]),
        Gf = ra(["./reach_worklet.html"]),
        Hf = ra(["./reach_worklet.js"]),
        If = ra(["./reach_worklet.js"]);

    function Jf(a) {
        var b = {};
        return b[0] = Cf(Df, a), b[1] = Cf(Ef), b[2] = Cf(Ff), b
    }
    Cf(Gf);
    Cf(Hf);
    Cf(If);
    var Lf = function(a, b, c, d) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? Jf("current") : d;
        ce.call(this);
        this.ea = a;
        this.Cd = b;
        this.Da = c;
        this.Le = d;
        this.Ra = null;
        this.Je = new ed(3);
        this.Je.g(O(function(e) {
            return e.value.type === "sessionStart"
        }));
        this.Fi = this.Je.g(O(function(e) {
            return e.value.type === "sessionFinish"
        }));
        this.Pf = new ed(1);
        this.Ti = new ed;
        this.Ef = new ed(10);
        this.J = new sf(this, new nf(a));
        this.Qh = this.ea.M();
        this.m = Kf(this, new rf(this.ea))
    };
    q(Lf, ce);
    var Mf = function(a) {
        a.Ra !== null && Ne(a.Ra)
    };
    Lf.prototype.validate = function() {
        return this.Qh
    };
    var Kf = function(a, b) {
        a.Ra = new Be(a.ea, a.Cd);
        var c = new ed;
        Ee(a.Ra, function(f) {
            f = Af(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Je.next(f)
        });
        Ge(a.Ra, function(f) {
            if (f === void 0) var g = !1;
            else {
                g = f.data;
                var h;
                (h = g === void 0) || (h = g.viewport, h = h === void 0 || h !== void 0 && typeof h.width === "number" && typeof h.height === "number");
                h ? (g = g.adView, g = g !== void 0 && typeof g.percentageInView === "number" && (g.geometry === void 0 || Bf(g.geometry)) && (g.onScreenGeometry === void 0 || Bf(g.onScreenGeometry))) : g = !1
            }
            g ? (f = Af(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.Ef.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.J.K(f).sendNow())
        });
        Fe(a.Ra, function(f) {
            f = Af(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Ti.next(f)
        });
        He(a.Ra, function(f) {
            f = Af(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Pf.next(f)
        });
        var d = 0;
        Ie(a.Ra, function(f) {
            d += f;
            d > 0 && f === 0 && c.next({
                timestamp: a.m.now(),
                value: !1
            })
        });
        var e = c.g(kf(function(f) {
            return f.value
        }, !0));
        return zf(b,
            e).m
    };
    ea.Object.defineProperties(Lf.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Nf
            }
        }
    });
    var Nf = {};

    function Of(a, b) {
        if (!b) throw Error("I`" + a);
        if (typeof b !== "string" && !(b instanceof String)) throw Error("J`" + a);
        if (b.trim() === "") throw Error("K`" + a);
    }

    function Pf(a) {
        if (!a) throw Error("N`functionToExecute");
    }

    function Qf(a, b) {
        if (b == null) throw Error("L`" + a);
        if (typeof b !== "number" || isNaN(b)) throw Error("M`" + a);
        if (b < 0) throw Error("O`" + a);
    };

    function Rf() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.5.2-google_20241009")
    }

    function Sf() {
        for (var a = ["1", "5", "2"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var Tf = function(a, b, c, d) {
            this.Nf = a;
            this.method = b;
            this.version = c;
            this.args = d
        },
        Uf = function(a) {
            return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
        },
        Vf = function(a) {
            return new Tf(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
        };
    Tf.prototype.Ta = function() {
        var a = {};
        a = (a.omid_message_guid = this.Nf, a.omid_message_method = this.method, a.omid_message_version = this.version, a);
        this.args !== void 0 && (a.omid_message_args = this.args);
        return a
    };
    var Wf = function(a) {
        this.to = a
    };
    Wf.prototype.Ta = function() {
        return JSON.stringify(void 0)
    };

    function Xf(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }
    var Yf = function(a) {
            return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
                return Xf(a, b)
            })
        },
        Zf = function(a) {
            for (var b = y(Object.values(ze)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = {};
                d = (d.app = "omid_v1_present_app", d.web = "omid_v1_present_web", d)[c];
                if (Xf(a, d)) return c
            }
            return null
        };

    function $f(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function ag() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function bg() {
        var a = B.apply(0, arguments);
        cg(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(z(a))));
        }, function() {
            return console.error.apply(console, z(a))
        })
    }

    function cg(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var dg = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("P");
    }();
    var eg = function(a) {
        this.to = a;
        this.handleExportedMessage = eg.prototype.yh.bind(this)
    };
    q(eg, Wf);
    eg.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("Q");
        b.handleExportedMessage(a.Ta(), this)
    };
    eg.prototype.yh = function(a, b) {
        if (Uf(a) && this.onMessage) this.onMessage(Vf(a), b)
    };

    function fg(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function gg(a) {
        if (a === dg) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function hg() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return fg(a) ? a : dg
    };
    var ig = function(a, b) {
        this.to = b = b === void 0 ? dg : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if (typeof d.data === "object") {
                var e = d.data;
                if (Uf(e) && d.source && c.onMessage) c.onMessage(Vf(e), d.source)
            }
        })
    };
    q(ig, Wf);
    ig.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("Q");
        b.postMessage(a.Ta(), "*")
    };
    var jg = ["omid", "v1_VerificationServiceCommunication"],
        kg = ["omidVerificationProperties", "serviceWindow"];

    function lg(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };
    var mg = function(a) {
        if (!a) {
            a = hg();
            var b = b === void 0 ? Yf : b;
            var c = [],
                d = lg(a, kg);
            d && c.push(d);
            c.push(fg(a) ? a.top : dg);
            a: {
                c = y(c);
                for (var e = c.next(); !e.done; e = c.next()) {
                    b: {
                        d = a;e = e.value;
                        var f = b;
                        if (!gg(e)) try {
                            var g = lg(e, jg);
                            if (g) {
                                var h = new eg(g);
                                break b
                            }
                        } catch (k) {}
                        h = f(e) ? new ig(d, e) : null
                    }
                    if (d = h) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.bc = a) this.bc.onMessage = this.zh.bind(this);
        else if (b = (b = dg.omid3p) && typeof b.registerSessionObserver === "function" && typeof b.addEventListener === "function" ? b : null) this.yc = b;
        this.ti = this.ui =
            0;
        this.Od = {};
        this.ie = [];
        this.nc = (b = dg.omidVerificationProperties) ? b.injectionId : void 0
    };
    mg.prototype.M = function() {
        var a = hg();
        var b = (b = dg.omidVerificationProperties) && b.injectionSource ? b.injectionSource : void 0;
        return (b || Zf(a) || Zf(fg(a) ? a.top : dg)) !== "web" || this.nc ? !(!this.bc && !this.yc) : !1
    };
    var Ke = function(a, b, c) {
        Pf(b);
        a.yc ? a.yc.registerSessionObserver(b, c, a.nc) : a.Rb("addSessionListener", b, c, a.nc)
    };
    mg.prototype.addEventListener = function(a, b) {
        Of("eventType", a);
        Pf(b);
        this.yc ? this.yc.addEventListener(a, b, this.nc) : this.Rb("addEventListener", b, a, this.nc)
    };
    var pf = function(a, b, c, d) {
            Of("url", b);
            dg.document && dg.document.createElement ? ng(a, b, c, d) : a.Rb("sendUrl", function(e) {
                e && c ? c() : !e && d && d()
            }, b)
        },
        ng = function(a, b, c, d) {
            var e = dg.document.createElement("img");
            a.ie.push(e);
            var f = function(g) {
                var h = a.ie.indexOf(e);
                h >= 0 && a.ie.splice(h, 1);
                g && g()
            };
            e.addEventListener("load", f.bind(a, c));
            e.addEventListener("error", f.bind(a, d));
            e.src = b
        };
    mg.prototype.setTimeout = function(a, b) {
        Pf(a);
        Qf("timeInMillis", b);
        if (og()) return dg.setTimeout(a, b);
        var c = this.ui++;
        this.Rb("setTimeout", a, c, b);
        return c
    };
    mg.prototype.clearTimeout = function(a) {
        Qf("timeoutId", a);
        og() ? dg.clearTimeout(a) : this.og("clearTimeout", a)
    };
    mg.prototype.setInterval = function(a, b) {
        Pf(a);
        Qf("timeInMillis", b);
        if (pg()) return dg.setInterval(a, b);
        var c = this.ti++;
        this.Rb("setInterval", a, c, b);
        return c
    };
    mg.prototype.clearInterval = function(a) {
        Qf("intervalId", a);
        pg() ? dg.clearInterval(a) : this.og("clearInterval", a)
    };
    var og = function() {
            return typeof dg.setTimeout === "function" && typeof dg.clearTimeout === "function"
        },
        pg = function() {
            return typeof dg.setInterval === "function" && typeof dg.clearInterval === "function"
        };
    mg.prototype.zh = function(a) {
        var b = a.method,
            c = a.Nf;
        a = a.args;
        if (b === "response" && this.Od[c]) {
            var d = Rf() && Sf() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
            this.Od[c].apply(this, d)
        }
        b === "error" && window.console && bg(a)
    };
    mg.prototype.og = function(a) {
        this.Rb.apply(this, [a, null].concat(z(B.apply(1, arguments))))
    };
    mg.prototype.Rb = function(a, b) {
        var c = B.apply(2, arguments);
        if (this.bc) {
            var d = ag();
            b && (this.Od[d] = b);
            var e = "VerificationService." + a;
            c = Rf() && Sf() ? c : JSON.stringify(c);
            this.bc.sendMessage(new Tf(d, e, "1.5.2-google_20241009", c))
        }
    };
    var qg = void 0;
    if (qg = qg === void 0 ? typeof omidExports === "undefined" ? null : omidExports : qg) {
        var rg = ["OmidVerificationClient"];
        rg.slice(0, rg.length - 1).reduce($f, qg)[rg[rg.length - 1]] = mg
    };

    function sg(a, b) {
        return function(c) {
            return new K(function(d) {
                return c.subscribe(function(e) {
                    a.Ub(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.Ub(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.Ub(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };
    var ug = function() {
        for (var a = y(B.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.ha()) {
                this.m = b;
                return
            }
        this.m = new tg
    };
    n = ug.prototype;
    n.ha = function() {
        return this.m.ha()
    };
    n.now = function() {
        return this.m.now()
    };
    n.setTimeout = function(a, b) {
        return this.m.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.m.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ha(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ha = function(a) {
        return this.m.Ha(a)
    };
    ea.Object.defineProperties(ug.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.m.timeline
            }
        }
    });
    var tg = function() {
        this.timeline = Symbol()
    };
    n = tg.prototype;
    n.ha = function() {
        return !1
    };
    n.now = function() {
        return new ue(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Ha = function() {
        return Ud
    };
    var xg = function(a, b) {
        this.N = a;
        this.I = b
    };
    n = xg.prototype;
    n.setTimeout = function(a, b) {
        return this.N.setTimeout(this.I.Ub(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.N.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ha(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ha = function(a) {
        var b = this;
        return new K(function(c) {
            var d = 0,
                e = b.N.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.N.clearInterval(e)
            }
        })
    };
    n.ha = function() {
        return !!this.N.clearTimeout && "setTimeout" in this.N && "setInterval" in this.N && !!this.N.clearInterval
    };
    var yg = function(a, b) {
        xg.call(this, a, b);
        this.timeline = te
    };
    q(yg, xg);
    yg.prototype.now = function() {
        return new ue(this.N.Date.now(), this.timeline)
    };
    yg.prototype.ha = function() {
        return !!this.N.Date && !!this.N.Date.now && xg.prototype.ha.call(this)
    };
    var zg = function(a, b) {
        xg.call(this, a, b);
        this.timeline = se
    };
    q(zg, xg);
    zg.prototype.now = function() {
        return new ue(this.N.performance.now(), this.timeline)
    };
    zg.prototype.ha = function() {
        return !!this.N.performance && !!this.N.performance.now && xg.prototype.ha.call(this)
    };

    function Ag(a) {
        a = a.global;
        if (a.fetchLater) return a.fetchLater.bind(a)
    }

    function Bg(a) {
        var b, c, d = (b = a.global) == null ? void 0 : (c = b.document) == null ? void 0 : c.createElement("meta");
        if (d) try {
            return d.httpEquiv = "origin-trial", d.content = "AxjhRadLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9", a.global.document.head.append(d), d
        } catch (e) {}
    }
    var Dg = function(a) {
            this.context = a;
            Cg === void 0 && (Cg = Bg(a))
        },
        Cg;
    Dg.prototype.M = function(a) {
        return Ag(this.context) !== void 0 && !(a == null || !a.vf) && !Eg(this.context) && !(a == null ? 0 : a.Xb) && !(a == null ? 0 : a.eb) && !(a == null ? 0 : a.Zc)
    };
    Dg.prototype.K = function(a, b) {
        if (!this.M(b)) throw new ie;
        return new Fg(this.context, a, b)
    };
    var Fg = function(a, b, c) {
            this.context = a;
            this.properties = c;
            this.xb = b;
            var d;
            this.ia = (d = c == null ? void 0 : c.ia) != null ? d : "GET";
            a = Ag(this.context);
            if (a === void 0) throw Error();
            this.fetchLater = a;
            Gg(this, this.sc())
        },
        Gg = function(a, b) {
            a.Ma && a.Ma.activated || (a.Yb = new AbortController, a.Ma = a.fetchLater(b, {
                method: a.ia,
                cache: "no-cache",
                mode: "no-cors",
                signal: a.Yb.signal,
                activateAfter: 96E4
            }))
        };
    Fg.prototype.sc = function() {
        var a = this.xb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "flapi=1"
    };
    Fg.prototype.deactivate = function() {
        this.Ma && !this.Ma.activated && this.Yb && (this.Yb.abort(), this.Ma = void 0)
    };
    Fg.prototype.sendNow = function() {};
    ea.Object.defineProperties(Fg.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.xb
            },
            set: function(a) {
                this.xb = a;
                a = this.sc();
                this.Ma && this.Ma.activated || !this.Yb || (this.Yb.abort(), this.Ma = void 0);
                Gg(this, a)
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.ia
            }
        }
    });
    var Hg = function(a) {
        this.context = a
    };
    Hg.prototype.M = function() {
        return !Eg(this.context) && !!this.context.global.fetch
    };
    Hg.prototype.ping = function() {
        var a = this;
        return Td.apply(null, z(B.apply(0, arguments).map(function(b) {
            return Sc(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).g(N(function(c) {
                return c.status === 200
            }))
        }))).g(bf(function(b) {
            return b
        }), df())
    };
    Hg.prototype.sd = function(a, b, c) {
        for (var d = B.apply(3, arguments), e = this, f = new Headers, g = y(b.entries()), h = g.next(); !h.done; h = g.next()) {
            var k = y(h.value);
            h = k.next().value;
            k = k.next().value;
            f.set(h, k)
        }
        var l, m = (l = a.keepAlive) != null ? l : !1;
        Td.apply(null, z(d.map(function(u) {
            return Sc(e.context.global.fetch(u, Object.assign({}, {
                method: String(a.ia),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).g(N(function(r) {
                return r.status === 200
            }))
        }))).g(bf(function(u) {
            return u
        }), df())
    };
    var Ig = function(a) {
        Ig[" "](a);
        return a
    };
    Ig[" "] = function() {};
    var Jg = function(a, b) {
        try {
            return Ig(a[b]), !0
        } catch (c) {}
        return !1
    };

    function Kg(a) {
        try {
            return !!a && a.location.href != null && Jg(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var Lg = Pa(1, !0),
        Mg = Pa(610401301, !1);
    Pa(899588437, !1);
    Pa(772657768, !0);
    Pa(513659523, !0);
    Pa(568333945, !0);
    Pa(1331761403, !1);
    Pa(651175828, !0);
    Pa(722764542, !0);
    Pa(748402145, !0);
    Pa(748402146, !0);
    var Ng = Pa(748402147, !0),
        Og = Pa(824648567, !0);
    Pa(824656860, !0);
    Pa(333098724, !1);
    Pa(2147483644, !1);
    Pa(2147483645, !0);
    Pa(2147483646, Lg);
    Pa(2147483647, !0);

    function Pg() {
        var a = Oa.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Qg, Rg = Oa.navigator;
    Qg = Rg ? Rg.userAgentData || null : null;

    function Sg(a) {
        if (!Mg || !Qg) return !1;
        for (var b = 0; b < Qg.brands.length; b++) {
            var c = Qg.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function U(a) {
        return Pg().indexOf(a) != -1
    };

    function Tg() {
        return Mg ? !!Qg && Qg.brands.length > 0 : !1
    }

    function Ug() {
        return Tg() ? !1 : U("Opera")
    }

    function Vg() {
        return U("Firefox") || U("FxiOS")
    }

    function Wg() {
        return U("Safari") && !(Xg() || (Tg() ? 0 : U("Coast")) || Ug() || (Tg() ? 0 : U("Edge")) || (Tg() ? Sg("Microsoft Edge") : U("Edg/")) || (Tg() ? Sg("Opera") : U("OPR")) || Vg() || U("Silk") || U("Android"))
    }

    function Xg() {
        return Tg() ? Sg("Chromium") : (U("Chrome") || U("CriOS")) && !(Tg() ? 0 : U("Edge")) || U("Silk")
    }

    function Yg() {
        return U("Android") && !(Xg() || Vg() || Ug() || U("Silk"))
    };
    var $g = function() {
            return Mg && Qg ? Qg.mobile : !Zg() && (U("iPod") || U("iPhone") || U("Android") || U("IEMobile"))
        },
        Zg = function() {
            return Mg && Qg ? !Qg.mobile && (U("iPad") || U("Android") || U("Silk")) : U("iPad") || U("Android") && !U("Mobile") || U("Silk")
        };

    function ah() {
        return Mg ? !!Qg && !!Qg.platform : !1
    }

    function bh() {
        return U("iPhone") && !U("iPod") && !U("iPad")
    }

    function ch() {
        bh() || U("iPad") || U("iPod")
    };
    Ug();
    var dh = Tg() ? !1 : U("Trident") || U("MSIE");
    U("Edge");
    var eh = U("Gecko") && !(ab(Pg(), "WebKit") && !U("Edge")) && !(U("Trident") || U("MSIE")) && !U("Edge"),
        fh = ab(Pg(), "WebKit") && !U("Edge");
    fh && U("Mobile");
    ah() || U("Macintosh");
    ah() || U("Windows");
    (ah() ? Qg.platform === "Linux" : U("Linux")) || ah() || U("CrOS");
    ah() || U("Android");
    bh();
    U("iPad");
    U("iPod");
    ch();
    ab(Pg(), "KaiOS");

    function gh(a, b) {
        b = b === void 0 ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return gh(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = hh(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = y(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + gh(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = hh(c.constructor)), typeof a.toString === "function" && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + hh(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function hh(a) {
        var b = a.displayName;
        return b && typeof b === "string" || (b = a.name) && typeof b === "string" ? b : (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)"
    };

    function ih(a, b) {
        var c = jh,
            d = [];
        kh(b, a, d) || lh.apply(null, [void 0, c, "Guard " + b.ge().trim() + " failed:"].concat(z(d.reverse())))
    }

    function mh(a, b) {
        a.Gj = !0;
        a.ge = typeof b === "function" ? b : function() {
            return b
        };
        return a
    }

    function kh(a, b, c) {
        var d = a(b, c);
        d || nh(c, function() {
            var e = "";
            e.length > 0 && (e += ": ");
            return e + "Expected " + a.ge().trim() + ", got " + gh(b)
        });
        return d
    }

    function nh(a, b) {
        a == null || a.push((typeof b === "function" ? b() : b).trim())
    }
    var jh = void 0;

    function oh(a) {
        return typeof a === "function" ? a() : a
    }

    function lh() {
        throw Error(B.apply(0, arguments).map(oh).filter(Boolean).join("\n").trim().replace(/:$/, ""));
    };
    var ph = mh(function(a) {
            return typeof a === "number"
        }, "number"),
        qh = mh(function(a) {
            return typeof a === "string"
        }, "string"),
        rh = mh(function(a) {
            return typeof a === "boolean"
        }, "boolean"),
        sh = mh(function(a) {
            return typeof a === "bigint"
        }, "bigint");

    function th() {
        var a = Error;
        return mh(function(b) {
            return b instanceof a
        }, function() {
            return hh(a)
        })
    }

    function uh() {
        var a = B.apply(0, arguments);
        return mh(function(b) {
            return a.some(function(c) {
                return c(b)
            })
        }, function() {
            return "" + a.map(function(b) {
                return b.ge().trim()
            }).join(" | ")
        })
    };
    var vh = function(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    };
    n = vh.prototype;
    n.clone = function() {
        return new vh(this.x, this.y)
    };
    n.toString = function() {
        return "(" + this.x + ", " + this.y + ")"
    };
    n.equals = function(a) {
        return a instanceof vh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    n.translate = function(a, b) {
        a instanceof vh ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), typeof b === "number" && (this.y += b));
        return this
    };
    n.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };
    var wh = function(a, b) {
        this.width = a;
        this.height = b
    };
    n = wh.prototype;
    n.clone = function() {
        return new wh(this.width, this.height)
    };
    n.toString = function() {
        return "(" + this.width + " x " + this.height + ")"
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.isEmpty = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    n.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };
    var zh = function(a) {
            return a ? new xh(yh(a)) : zb || (zb = new xh)
        },
        Ah = function(a) {
            var b = a.scrollingElement ? a.scrollingElement : fh || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
            a = a.defaultView;
            return new vh((a == null ? void 0 : a.pageXOffset) || b.scrollLeft, (a == null ? void 0 : a.pageYOffset) || b.scrollTop)
        },
        Bh = function(a, b, c) {
            function d(h) {
                h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!Ra(f) || Sa(f) && f.nodeType > 0) d(f);
                else {
                    a: {
                        if (f && typeof f.length ==
                            "number") {
                            if (Sa(f)) {
                                var g = typeof f.item == "function" || typeof f.item == "string";
                                break a
                            }
                            if (typeof f === "function") {
                                g = typeof f.item == "function";
                                break a
                            }
                        }
                        g = !1
                    }
                    Kb(g ? Ob(f) : f, d)
                }
            }
        },
        yh = function(a) {
            D(a, "Node cannot be null or undefined.");
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        Ch = function(a, b) {
            a && (a = a.parentNode);
            for (var c = 0; a;) {
                D(a.name != "parentNode");
                if (b(a)) return a;
                a = a.parentNode;
                c++
            }
            return null
        },
        xh = function(a) {
            this.hc = a || Oa.document || document
        };
    n = xh.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.hc).getElementsByTagName(String(a))
    };
    n.createElement = function(a) {
        var b = this.hc;
        a = String(a);
        b.contentType === "application/xhtml+xml" && (a = a.toLowerCase());
        return b.createElement(a)
    };
    n.createTextNode = function(a) {
        return this.hc.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        D(a != null && b != null, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        Bh(yh(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.isElement = function(a) {
        return Sa(a) && a.nodeType == 1
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Dh(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    n = Dh.prototype;
    n.Mf = function() {
        return this.right - this.left
    };
    n.Jf = function() {
        return this.bottom - this.top
    };
    n.clone = function() {
        return new Dh(this.top, this.right, this.bottom, this.left)
    };
    n.toString = function() {
        return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
    };
    n.contains = function(a) {
        return this && a ? a instanceof Dh ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    n.expand = function(a, b, c, d) {
        Sa(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    n.translate = function(a, b) {
        a instanceof vh ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (Eb(a), this.left += a, this.right += a, typeof b === "number" && (this.top += b, this.bottom += b));
        return this
    };
    n.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };
    var Eh = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };

    function Fh(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    };
    var Gh = function(a) {
        this.context = a
    };
    Gh.prototype.M = function(a) {
        return (a == null ? 0 : a.Xb) || (a == null ? void 0 : a.ia) === "POST" || (a == null ? 0 : a.eb) || (a == null ? 0 : a.Zc) || (a == null ? 0 : a.keepAlive) ? !1 : !Eg(this.context)
    };
    Gh.prototype.ping = function() {
        var a = this;
        return M(B.apply(0, arguments).map(function(b) {
            try {
                var c = a.context.global;
                c.google_image_requests || (c.google_image_requests = []);
                var d = c.document;
                d = d === void 0 ? document : d;
                var e = d.createElement("img");
                e.src = b;
                c.google_image_requests.push(e);
                return !0
            } catch (f) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    Gh.prototype.sd = function(a, b, c) {
        this.ping.apply(this, z(B.apply(3, arguments)))
    };

    function Hh(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }
    var Ih = function(a) {
        this.context = a
    };
    Ih.prototype.M = function(a) {
        return Jh && !Eg(this.context) && Hh(this.context) !== void 0 && !(a == null ? 0 : a.Xb) && (a == null ? void 0 : a.ia) !== "POST" && !(a == null ? 0 : a.eb) && !(a == null ? 0 : a.Zc)
    };
    Ih.prototype.K = function(a, b) {
        if (!this.M(b)) throw new ie;
        return new Kh(this.context, a)
    };
    var Jh = !1,
        Kh = function(a, b) {
            this.context = a;
            this.xb = b;
            a = Hh(this.context);
            if (a === void 0) throw Error();
            this.We = new a(this.sc(), {})
        };
    Kh.prototype.sc = function() {
        var a = this.xb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "pbapi=1"
    };
    Kh.prototype.deactivate = function() {
        this.We.deactivate()
    };
    Kh.prototype.sendNow = function() {
        this.We.sendNow()
    };
    ea.Object.defineProperties(Kh.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.xb
            },
            set: function(a) {
                this.xb = a;
                this.We.setURL(this.sc())
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if (a !== "GET") throw new ie;
            }
        }
    });
    var Lh = function(a) {
        this.context = a
    };
    Lh.prototype.M = function(a) {
        if ((a == null ? 0 : a.Xb) || (a == null ? void 0 : a.ia) === "GET" || (a == null ? 0 : a.eb) || (a == null ? 0 : a.Zc) || (a == null ? 0 : a.keepAlive)) return !1;
        var b;
        return !Eg(this.context) && ((b = this.context.global.navigator) == null ? void 0 : b.sendBeacon) !== void 0
    };
    Lh.prototype.ping = function() {
        var a = this;
        return M(B.apply(0, arguments).map(function(b) {
            var c;
            return (c = a.context.global.navigator) == null ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    Lh.prototype.sd = function(a, b, c) {
        this.ping.apply(this, z(B.apply(3, arguments)))
    };

    function Mh(a) {
        return function(b) {
            return b.g(Nh(a, ef(new L)))
        }
    }

    function V(a, b) {
        return function(c) {
            return c.g(Nh(a, ff(b)))
        }
    }

    function Nh(a, b) {
        function c(d) {
            return new K(function(e) {
                return d.subscribe(function(f) {
                    Ya(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    Ya(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    Ya(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return J(c, qd(), b, md(), c)
    };
    var W = function(a) {
        this.value = a
    };
    W.prototype.T = function(a) {
        return M(this.value).g(V(a, 1))
    };
    var Oh = new W(!1);

    function Ph(a) {
        Oa.setTimeout(function() {
            throw a;
        }, 0)
    };
    Vg();
    bh() || U("iPod");
    U("iPad");
    Yg();
    Xg();
    Wg() && ch();
    var Qh = {},
        Rh = null,
        Sh = eh || fh || typeof Oa.btoa == "function",
        Uh = function(a) {
            var b;
            D(Ra(a), "encodeByteArray takes an array as a parameter");
            b === void 0 && (b = 0);
            Th();
            b = Qh[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = "" + l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        Wh = function(a) {
            var b =
                a.length,
                c = b * 3 / 4;
            c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Vh(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Vh = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Rh[l];
                    if (m != null) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("S`" + l);
                }
                return k
            }
            Th();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (h === 64 && e === -1) break;
                b(e << 2 | f >> 4);
                g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
            }
        },
        Th = function() {
            if (!Rh) {
                Rh = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                    var d = a.concat(b[c].split(""));
                    Qh[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e],
                            g = Rh[f];
                        g === void 0 ? Rh[f] = e : D(g === e)
                    }
                }
            }
        };

    function Xh(a) {
        var b = Yh(a);
        return b === null ? new W(null) : b.g(N(function(c) {
            c = c.Ta();
            if (Sh) c = Oa.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    if (g > 255) throw Error("R");
                    d[e++] = g
                }
                c = Uh(d)
            }
            return c
        }), Ve(1), V(a.i, 1))
    };

    function Zh(a) {
        var b = b === void 0 ? {} : b;
        if (typeof Event === "function") return new Event(a, b);
        if (typeof document !== "undefined") {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };
    var $h = function(a) {
        this.value = a;
        this.Ge = new L
    };
    $h.prototype.release = function() {
        this.Ge.next();
        this.Ge.complete();
        this.value = void 0
    };
    ea.Object.defineProperties($h.prototype, {
        l: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        released: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ge
            }
        }
    });
    var ai = ["FRAME", "IMG", "IFRAME"],
        bi = /^[01](px)?$/,
        ci = function() {
            this.Sh = this.gf = this.jg = this.rf = !1
        },
        di = function() {
            var a = new ci;
            a.rf = !0;
            a.jg = !0;
            return a
        };

    function ei(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }

    function fi(a, b) {
        b = b === void 0 ? !1 : b;
        if (a.tagName === "IMG") {
            if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
            var c;
            if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
        }
        var d, e;
        return bi.test((d = a.getAttribute("width")) != null ? d : "") && bi.test((e = a.getAttribute("height")) != null ? e : "")
    }

    function gi(a, b) {
        if (a.tagName === "IMG") return a.naturalWidth && a.naturalHeight ? !0 : !1;
        try {
            if (a.readyState) var c = a.readyState;
            else {
                var d, e;
                c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
            }
            return c === "complete"
        } catch (f) {
            return b === void 0 ? !1 : b
        }
    }

    function hi(a) {
        a || (a = function(b, c, d) {
            b.addEventListener(c, d)
        });
        return a
    }

    function ii(a, b) {
        var c = di();
        c = c === void 0 ? new ci : c;
        if (a = ei(a)) {
            var d = hi(d);
            for (var e = !1, f = function(x) {
                    e || (e = !0, b(x))
                }, g, h = 2, k = 0; k < ai.length; ++k)
                if (ai[k] === a.tagName) {
                    h = 3;
                    g = [a];
                    break
                }
            g || (g = a.querySelectorAll(ai.join(",")));
            var l = 0,
                m = 0,
                u = !c.gf,
                r = a = !1;
            k = {};
            for (var t = 0; t < g.length; k = {
                    ld: void 0
                }, t++) {
                var w = g[t];
                if (!fi(w, c.gf))
                    if (k.ld = w.tagName === "IMG", gi(w, c.rf)) a = !0, k.ld && (u = !0);
                    else {
                        l++;
                        var v = function(x) {
                            return function(A) {
                                l--;
                                !l && u && f(h);
                                x.ld && (A = A && A.type === "error", m--, A || (u = !0), !m && r && u && f(h))
                            }
                        }(k);
                        d(w, "load", v);
                        k.ld && (m++, d(w, "error", v))
                    }
            }
            m === 0 && (u = !0);
            g = null;
            g = Oa.document.readyState === "complete";
            if (c.Sh && g) {
                if (m > 0) {
                    r = !0;
                    return
                }
                h = 5
            } else if (l === 0 && !a && g) h = 5;
            else if (l || !a) {
                d(Oa, "load", function() {
                    !c.jg || !m && u ? f(4) : r = !0
                });
                return
            }
            f(h)
        }
    };

    function ji(a, b, c) {
        if (a)
            for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
    }

    function ki(a, b) {
        ji(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function li(a, b) {
        if (a.tagName == "IFRAME") b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function mi(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function ni(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if (typeof d === "object" && d && d.type === "creativeLoad") {
            var e = mi(a);
            if (c.source && e) {
                var f;
                ki(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (h) {}
                });
                f && li(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function oi(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }
    var pi = function(a, b) {
        var c = oi(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (h) {}
                        d = {
                            push: function(h) {
                                h(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Oa.addEventListener("message", function(f) {
                    ni(c, e, f)
                })
            }
    };
    var qi = function(a, b) {
            var c = this;
            this.global = a;
            this.rd = b;
            this.li = this.document ? Td(M(!0), Md(this.document, "visibilitychange")).g(sg(this.rd.I, 748), N(function() {
                return c.document ? c.document.visibilityState : "visible"
            }), Q()) : M("visible");
            this.ii = this.document ? Md(this.document, "DOMContentLoaded").g(sg(this.rd.I, 739), Ve(1)) : M(Zh("DOMContentLoaded"))
        },
        ri = function(a) {
            return a.document ? a.document.readyState : "complete"
        },
        si = function(a) {
            return a.document !== null && a.document.visibilityState !== void 0
        };
    qi.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    qi.prototype.querySelectorAll = function(a) {
        return this.document ? Ob(this.document.querySelectorAll(a)) : []
    };
    qi.prototype.elementFromPoint = function(a, b) {
        if (!this.document || this.document === null || typeof this.document.elementFromPoint !== "function") return null;
        a = this.document.elementFromPoint(a, b);
        return a === null ? null : new $h(a)
    };
    var ti = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            if (b.l === void 0 || !a.document) return M(b).g(sg(a.rd.I, 749));
            var d = new ed(1),
                e = function() {
                    d.next(b)
                };
            c || pi(b.l, e);
            ii(b.l, e);
            return d.g(sg(a.rd.I, 749), Ve(1))
        },
        ui = function(a, b) {
            a = a.document;
            if (!a) return M(!1);
            var c = Td(M(null), Md(a, "DOMContentLoaded", {
                    once: !0
                }), Md(a, "load", {
                    once: !0
                })),
                d = new $h({
                    document: a,
                    element: b
                });
            return c.g(N(function() {
                if (!d.l) return !1;
                var e = d.l,
                    f = e.document;
                e = e.element;
                var g, h, k = (h = (g = f.body) != null ? g : f.children[0]) != null ? h : f;
                try {
                    k.appendChild(e),
                        d.release()
                } catch (l) {}
                return !d.l
            }), O(function(e) {
                return e
            }), Ve(1), Se(!1), lf({
                complete: function() {
                    return void d.release()
                }
            }))
        },
        vi = function(a, b, c) {
            var d, e, f;
            return Ha(function(g) {
                if (g.u == 1) {
                    d = a.global.document.createElement("iframe");
                    e = new Promise(function(k) {
                        d.onload = k;
                        d.onerror = k
                    });
                    if (b instanceof fb) var h = b.kg;
                    else throw Error("Unexpected type when unwrapping TrustedResourceUrl");
                    d.src = h.toString();
                    return va(g, jd(ui(a, d)), 2)
                }
                if (g.u != 3) {
                    if (!g.ba) return g.return();
                    d.style.display = "none";
                    return va(g,
                        e, 3)
                }
                f = d.contentWindow;
                if (!f) return g.return();
                f.postMessage(c, "*");
                return g.return(d)
            })
        };
    ea.Object.defineProperties(qi.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Jg(this.global, "document") ? this.global.document || null : null
            }
        }
    });
    var wi = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function xi(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function yi(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function zi(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };

    function Ai(a, b) {
        var c = Zg() || $g();
        try {
            if (a) {
                if (!b.top) return new Dh(-12245933, -12245933, -12245933, -12245933);
                b = b.top
            }
            a: {
                var d = b;
                if (a && d !== null && d != d.top) {
                    if (!d.top) {
                        var e = new wh(-12245933, -12245933);
                        break a
                    }
                    d = d.top
                }
                try {
                    if (c === void 0 ? 0 : c) var f = (new wh(d.innerWidth, d.innerHeight)).round();
                    else {
                        var g = (d || window).document,
                            h = g.compatMode == "CSS1Compat" ? g.documentElement : g.body;
                        f = (new wh(h.clientWidth, h.clientHeight)).round()
                    }
                    e = f
                } catch (w) {
                    e = new wh(-12245933, -12245933)
                }
            }
            a = e;
            var k = a.height,
                l = a.width;
            if (l ===
                -12245933) return new Dh(l, l, l, l);
            var m = zh(b.document);
            var u = Ah(m.hc);
            var r = u.x,
                t = u.y;
            return new Dh(t, r + l, t + k, r)
        } catch (w) {
            return new Dh(-12245933, -12245933, -12245933, -12245933)
        }
    };

    function Bi(a, b) {
        if (a) throw Error("T");
        b.push(65533)
    }

    function Ci(a, b) {
        b = String.fromCharCode.apply(null, b);
        return a == null ? b : a + b
    }
    var Di = void 0,
        Ei, Fi, Gi = typeof TextDecoder !== "undefined",
        Hi, Ii = typeof String.prototype.isWellFormed === "function",
        Ji = typeof TextEncoder !== "undefined";
    var Ki = typeof Uint8Array !== "undefined",
        Li = !dh && typeof btoa === "function",
        Mi = /[-_.]/g,
        Pi = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Qi(a) {
        return Pi[a] || ""
    }

    function Ri(a) {
        if (!Li) return Wh(a);
        var b = Mi.test(a) ? a.replace(Mi, Qi) : a;
        try {
            var c = atob(b)
        } catch (d) {
            throw Error("V`" + a + "`" + d);
        }
        a = new Uint8Array(c.length);
        for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
        return a
    }
    var Si = {};
    var Ui = function(a, b) {
        if (b !== Si) throw Error("X");
        this.Lc = a;
        if (a != null && a.length === 0) throw Error("W");
        this.dontPassByteStringToStructuredClone = Ti
    };
    Ui.prototype.isEmpty = function() {
        return this.Lc == null
    };
    var Vi;

    function Ti() {};

    function Wi(a) {
        Jb(a, Ui);
        if (Si !== Si) throw Error("X");
        var b = a.Lc;
        b == null || Ki && b != null && b instanceof Uint8Array || (typeof b === "string" ? b = Ri(b) : (Db("Cannot coerce to Uint8Array: " + Qa(b)), b = null));
        return (b == null ? b : a.Lc = b) || new Uint8Array(0)
    };
    var Xi = function(a, b, c) {
        this.buffer = a;
        if (c && !b) throw Error("fa");
        this.Yf = b
    };

    function Yi(a, b) {
        if (typeof a === "string") return new Xi(Ri(a), b);
        if (Array.isArray(a)) return new Xi(new Uint8Array(a), b);
        if (a.constructor === Uint8Array) return new Xi(a, !1);
        if (a.constructor === ArrayBuffer) return a = new Uint8Array(a), new Xi(a, !1);
        if (a.constructor === Ui) return b = Wi(a), new Xi(b, !0, a);
        if (a instanceof Uint8Array) return a = a.constructor === Uint8Array ? a : new Uint8Array(a.buffer, a.byteOffset, a.byteLength), new Xi(a, !1);
        throw Error("ga");
    };

    function Zi() {
        return typeof BigInt === "function"
    };
    var $i = typeof Oa.BigInt === "function" && typeof Oa.BigInt(0) === "bigint";

    function aj(a) {
        var b = a;
        if (qh(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error("ha`" + b);
        } else if (ph(b) && !Number.isSafeInteger(b)) throw Error("ia`" + b);
        if ($i) {
            sh(a) || (ih(a, uh(qh, rh, ph)), a = BigInt(a));
            b = a % BigInt(2);
            var c = BigInt,
                d = typeof Window === "function" && globalThis.top instanceof Window ? globalThis.top : globalThis;
            d.gbigintUseStrInDebugToggleVal == null && Object.defineProperties(d, {
                gbigintUseStrInDebugToggleVal: {
                    value: Math.round(Math.random())
                }
            });
            return b === c(d.gbigintUseStrInDebugToggleVal) ? a.toString() :
                a
        }
        return a = rh(a) ? a ? "1" : "0" : qh(a) ? a.trim() || "0" : String(a)
    }
    var gj = mh(function(a) {
            if ($i) return ih(bj, sh), ih(cj, sh), a = BigInt(a), a >= bj && a <= cj;
            ih(a, qh);
            return a[0] === "-" ? dj(a, ej) : dj(a, fj)
        }, "isSafeInt52"),
        ej = Number.MIN_SAFE_INTEGER.toString(),
        bj = $i ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        fj = Number.MAX_SAFE_INTEGER.toString(),
        cj = $i ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function dj(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
        c = jh;
        lh("Assertion fail:", "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." || c)
    };
    var hj = typeof Uint8Array.prototype.slice === "function",
        ij = 0,
        jj = 0,
        kj;

    function lj(a) {
        var b = a >>> 0;
        ij = b;
        jj = (a - b) / 4294967296 >>> 0
    }

    function mj(a) {
        if (a < 0) {
            lj(0 - a);
            var b = y(nj(ij, jj));
            a = b.next().value;
            b = b.next().value;
            ij = a >>> 0;
            jj = b >>> 0
        } else lj(a)
    }

    function oj(a) {
        D(a <= 8);
        return kj || (kj = new DataView(new ArrayBuffer(8)))
    }

    function pj(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : qj(a, b)
    }

    function rj(a, b) {
        return aj(Zi() ? BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0)) : qj(a, b))
    }

    function sj(a, b) {
        var c = b & 2147483648;
        c && (a = ~a + 1 >>> 0, b = ~b >>> 0, a == 0 && (b = b + 1 >>> 0));
        a = pj(a, b);
        return typeof a === "number" ? c ? -a : a : c ? "-" + a : a
    }

    function tj(a, b) {
        return Zi() ? aj(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) + BigInt.asUintN(32, BigInt(a)))) : aj(uj(a, b))
    }

    function qj(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else Zi() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), D(b), c = b + vj(c) + vj(a));
        return c
    }

    function vj(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function uj(a, b) {
        b & 2147483648 ? Zi() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = y(nj(a, b)), a = b.next().value, b = b.next().value, a = "-" + qj(a, b)) : a = qj(a, b);
        return a
    }

    function wj(a) {
        D(a.length > 0);
        if (a.length < 16) mj(Number(a));
        else if (Zi()) a = BigInt(a), ij = Number(a & BigInt(4294967295)) >>> 0, jj = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            D(a.length > 0);
            var b = +(a[0] === "-");
            jj = ij = 0;
            for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), jj *= 1E6, ij = ij * 1E6 + d, ij >= 4294967296 && (jj += Math.trunc(ij / 4294967296), jj >>>= 0, ij >>>= 0);
            b && (b = y(nj(ij, jj)), a = b.next().value, b = b.next().value, ij = a, jj = b)
        }
    }

    function nj(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    var xj = function(a, b, c, d) {
        this.G = this.va = null;
        this.Nd = !1;
        this.R = this.Ea = this.Ka = 0;
        this.init(a, b, c, d)
    };
    n = xj.prototype;
    n.init = function(a, b, c, d) {
        var e = d === void 0 ? {} : d;
        d = e.Sc === void 0 ? !1 : e.Sc;
        e = e.Ad === void 0 ? !1 : e.Ad;
        this.Sc = d;
        this.Ad = e;
        a && (this.G = a = Yi(a, this.Ad), this.va = a.buffer, this.Nd = a.Yf, this.Ka = b || 0, this.Ea = c !== void 0 ? this.Ka + c : this.va.length, this.R = this.Ka)
    };
    n.ce = function() {
        this.clear();
        yj.length < 100 && yj.push(this)
    };
    n.clear = function() {
        this.G = this.va = null;
        this.Nd = !1;
        this.R = this.Ea = this.Ka = 0;
        this.Sc = !1
    };
    n.setEnd = function(a) {
        this.Ea = a
    };
    n.reset = function() {
        this.R = this.Ka
    };
    n.aa = function() {
        return this.R
    };
    n.advance = function(a) {
        zj(this, this.R + a)
    };
    var Aj = function(a, b) {
            var c = 0,
                d = 0,
                e = 0,
                f = a.va,
                g = a.R;
            do {
                var h = f[g++];
                c |= (h & 127) << e;
                e += 7
            } while (e < 32 && h & 128);
            if (e > 32)
                for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7) h = f[g++], d |= (h & 127) << e;
            zj(a, g);
            if (!(h & 128)) return b(c >>> 0, d >>> 0);
            throw Error("ca");
        },
        zj = function(a, b) {
            a.R = b;
            if (b > a.Ea) throw Error("da`" + b + "`" + a.Ea);
        },
        Bj = function(a) {
            var b = a.va,
                c = a.R,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 && b[c++] & 128 &&
                    b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error("ca");
            zj(a, c);
            return e
        },
        Cj = function(a) {
            return Bj(a) >>> 0
        },
        Dj = function(a) {
            return Aj(a, pj)
        },
        Ej = function(a) {
            return Aj(a, rj)
        },
        Fj = function(a) {
            var b = a.va,
                c = a.R,
                d = b[c + 0],
                e = b[c + 1],
                f = b[c + 2];
            b = b[c + 3];
            a.advance(4);
            return (d << 0 | e << 8 | f << 16 | b << 24) >>> 0
        },
        Gj = function(a) {
            for (var b = 0, c = a.R, d = c + 10, e = a.va; c < d;) {
                var f = e[c++];
                b |= f;
                if ((f & 128) === 0) return zj(a, c), !!(b & 127)
            }
            throw Error("ca");
        },
        Hj = function(a) {
            return Bj(a)
        },
        Ij = function(a, b) {
            if (b < 0) throw Error("ea`" + b);
            var c = a.R,
                d = c + b;
            if (d > a.Ea) throw Error("da`" + (a.Ea - c) + "`" + b);
            a.R = d;
            return c
        };
    xj.prototype.mg = function(a, b) {
        var c = Ij(this, a),
            d = D(this.va);
        if (Gi) {
            var e;
            b ? (e = Ei) || (e = Ei = new TextDecoder("utf-8", {
                fatal: !0
            })) : (e = Fi) || (e = Fi = new TextDecoder("utf-8", {
                fatal: !1
            }));
            var f = c + a;
            d = c === 0 && f === d.length ? d : d.subarray(c, f);
            try {
                var g = e.decode(d)
            } catch (m) {
                if (b) {
                    if (Di === void 0) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (u) {}
                        try {
                            e.decode(new Uint8Array([97])), Di = !0
                        } catch (u) {
                            Di = !1
                        }
                    }
                    b = !Di
                }
                b && (Ei = void 0);
                throw m;
            }
        } else {
            a = c + a;
            g = [];
            for (var h = null, k, l; c < a;) k = d[c++], k < 128 ? g.push(k) : k < 224 ? c >= a ? Bi(b, g) : (l =
                d[c++], k < 194 || (l & 192) !== 128 ? (c--, Bi(b, g)) : (k = (k & 31) << 6 | l & 63, D(k >= 128 && k <= 2047), g.push(k))) : k < 240 ? c >= a - 1 ? Bi(b, g) : (l = d[c++], (l & 192) !== 128 || k === 224 && l < 160 || k === 237 && l >= 160 || ((e = d[c++]) & 192) !== 128 ? (c--, Bi(b, g)) : (k = (k & 15) << 12 | (l & 63) << 6 | e & 63, D(k >= 2048 && k <= 65535), D(k < 55296 || k > 57343), g.push(k))) : k <= 244 ? c >= a - 2 ? Bi(b, g) : (l = d[c++], (l & 192) !== 128 || (k << 28) + (l - 144) >> 30 !== 0 || ((e = d[c++]) & 192) !== 128 || ((f = d[c++]) & 192) !== 128 ? (c--, Bi(b, g)) : (k = (k & 7) << 18 | (l & 63) << 12 | (e & 63) << 6 | f & 63, D(k >= 65536 && k <= 1114111), k -= 65536, g.push((k >>
                10 & 1023) + 55296, (k & 1023) + 56320))) : Bi(b, g), g.length >= 8192 && (h = Ci(h, g), g.length = 0);
            D(c === a, "expected " + c + " === " + a);
            g = Ci(h, g)
        }
        return g
    };
    xj.prototype.Ee = function(a) {
        if (a == 0) return Vi || (Vi = new Ui(null, Si));
        var b = Ij(this, a);
        if (this.Sc && this.Nd) b = this.va.subarray(b, b + a);
        else {
            var c = D(this.va);
            a = b + a;
            b = b === a ? new Uint8Array(0) : hj ? c.slice(b, a) : new Uint8Array(c.subarray(b, a))
        }
        Jb(b, Uint8Array);
        return b.length == 0 ? Vi || (Vi = new Ui(null, Si)) : new Ui(b, Si)
    };
    var yj = [];
    D(!0);
    var Kj = function(a, b, c, d) {
            if (yj.length) {
                var e = yj.pop();
                e.init(a, b, c, d);
                a = e
            } else a = new xj(a, b, c, d);
            this.o = a;
            this.fb = this.o.aa();
            this.j = this.qd = this.Kb = -1;
            Jj(this, d)
        },
        Jj = function(a, b) {
            b = b === void 0 ? {} : b;
            a.Xd = b.Xd === void 0 ? !1 : b.Xd
        },
        Mj = function(a, b, c, d) {
            if (Lj.length) {
                var e = Lj.pop();
                Jj(e, d);
                e.o.init(a, b, c, d);
                return e
            }
            return new Kj(a, b, c, d)
        };
    Kj.prototype.ce = function() {
        this.o.clear();
        this.j = this.Kb = this.qd = -1;
        Lj.length < 100 && Lj.push(this)
    };
    Kj.prototype.aa = function() {
        return this.o.aa()
    };
    Kj.prototype.reset = function() {
        this.o.reset();
        this.fb = this.o.aa();
        this.j = this.Kb = this.qd = -1
    };
    Kj.prototype.advance = function(a) {
        this.o.advance(a)
    };
    var Nj = function(a) {
            var b = a.o;
            if (b.R == b.Ea) return !1;
            a.qd !== -1 && (b = a.o.aa(), a.o.R = a.fb, Cj(a.o), a.j === 4 || a.j === 3 ? D(b === a.o.aa(), "Expected to not advance the cursor.  Group tags do not have values.") : D(b > a.o.aa(), "Expected to read the field, did you forget to call a read or skip method?"), a.o.R = b);
            a.fb = a.o.aa();
            b = Cj(a.o);
            var c = b >>> 3,
                d = b & 7;
            if (!(d >= 0 && d <= 5)) throw Error("Z`" + d + "`" + a.fb);
            if (c < 1) throw Error("$`" + c + "`" + a.fb);
            a.qd = b;
            a.Kb = c;
            a.j = d;
            return !0
        },
        Oj = function(a) {
            switch (a.j) {
                case 0:
                    a.j != 0 ? (Db("Invalid wire type for skipVarintField"),
                        Oj(a)) : Gj(a.o);
                    break;
                case 1:
                    D(a.j === 1);
                    a.o.advance(8);
                    break;
                case 2:
                    if (a.j != 2) Db("Invalid wire type for skipDelimitedField"), Oj(a);
                    else {
                        var b = Cj(a.o);
                        a.o.advance(b)
                    }
                    break;
                case 5:
                    D(a.j === 5);
                    a.o.advance(4);
                    break;
                case 3:
                    b = a.Kb;
                    do {
                        if (!Nj(a)) throw Error("aa");
                        if (a.j == 4) {
                            if (a.Kb != b) throw Error("ba");
                            break
                        }
                        Oj(a)
                    } while (1);
                    break;
                default:
                    throw Error("Z`" + a.j + "`" + a.fb);
            }
        },
        Pj = function(a, b, c) {
            D(a.j == 2);
            var d = a.o.Ea,
                e = Cj(a.o),
                f = a.o.aa() + e,
                g = f - d;
            g <= 0 && (a.o.setEnd(f), c(b, a, void 0, void 0, void 0), g = f - a.o.aa());
            if (g) throw Error("Y`" +
                e + "`" + (e - g));
            a.o.R = f;
            a.o.setEnd(d)
        },
        Qj = function(a) {
            D(a.j == 0);
            return Bj(a.o)
        },
        Rj = function(a) {
            D(a.j == 0);
            return Cj(a.o)
        },
        Sj = function(a) {
            D(a.j == 0);
            return Dj(a.o)
        },
        Tj = function(a) {
            D(a.j == 0);
            return Ej(a.o)
        },
        Uj = function(a) {
            D(a.j == 0);
            return Bj(a.o)
        };
    Kj.prototype.mg = function() {
        return Vj(this)
    };
    var Vj = function(a) {
        D(a.j == 2);
        var b = Cj(a.o);
        return a.o.mg(b, !0)
    };
    Kj.prototype.Ee = function() {
        D(this.j == 2);
        var a = Cj(this.o);
        return this.o.Ee(a)
    };
    var Wj = function(a, b, c) {
            D(a.j == 2);
            var d = Cj(a.o);
            for (d = a.o.aa() + d; a.o.aa() < d;) c.push(b(a.o))
        },
        Lj = [];
    var Xj = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function Yj(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Zj = Yj("jas", void 0, !0),
        ak = Yj("defaultInstance", "0di"),
        bk = Yj("unknownBinaryFields", Symbol()),
        ck = Yj("unknownBinaryThrottleKey", "0ub"),
        dk = Yj("unknownBinaryThrottleKey", "0ubs"),
        ek = Yj("unknownBinarySerializeBinaryThrottleKey", "0ubsb"),
        fk = Yj("m_m", "Jj", !0),
        gk = Yj("validPivotSelector", "vps"),
        hk = Yj("lazilyParseLateLoadedExtensions");
    D(Math.round(Math.log2(Math.max.apply(Math, z(Object.values({
        pj: 1,
        oj: 2,
        nj: 4,
        uj: 8,
        xj: 16,
        sj: 32,
        bj: 64,
        lj: 128,
        fj: 256,
        wj: 512,
        gj: 1024,
        mj: 2048,
        tj: 4096,
        rj: 8192
    }))))) === 13);
    var ik = {
            Ih: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        jk = Object.defineProperties,
        X = Xj ? F(Zj) : "Ih",
        kk, lk = [];
    mk(lk, 7);
    kk = Object.freeze(lk);

    function nk(a) {
        return G(a, "state is only maintained on arrays.")[X] | 0
    }

    function ok(a, b) {
        D((b & 16777215) === b);
        G(a, "state is only maintained on arrays.");
        Xj || X in a || jk(a, ik);
        a[X] |= b
    }

    function mk(a, b) {
        D((b & 16777215) === b);
        G(a, "state is only maintained on arrays.");
        Xj || X in a || jk(a, ik);
        a[X] = b
    }

    function Y(a, b, c) {
        (c === void 0 || !c || b & 2048) && D(b & 64, "state for messages must be constructed");
        D((b & 5) === 0, "state for messages should not contain repeated field state");
        D((b & 8192) === 0, "state for messages should not contain map field state");
        if (b & 64) {
            D(b & 64);
            c = b >> 14 & 1023 || 536870912;
            var d = a.length;
            D(b & 64);
            D(c + (b & 128 ? 0 : -1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
            b & 128 && D(typeof a[0] === "string", "arrays with a message_id bit must have a string in the first position, got: %s",
                a[0])
        }
    }

    function pk(a) {
        var b = G(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        return b
    }

    function qk(a) {
        var b = G(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        return b
    }

    function rk(a) {
        return !!((G(a, "state is only maintained on arrays.")[X] | 0) & 2)
    }

    function sk(a, b) {
        Eb(b);
        D(b > 0 && b <= 1023 || 536870912 === b, "pivot must be in the range [1, 1024) or NO_PIVOT got %s", b);
        return a & -16760833 | (b & 1023) << 14
    }

    function tk(a) {
        D(a & 64);
        return a & 128 ? 0 : -1
    }
    var uk = Object.getOwnPropertyDescriptor(Array.prototype, "Rh");
    Object.defineProperties(Array.prototype, {
        Rh: {
            get: function() {
                var a = vk(this);
                return uk ? uk.get.call(this) + "|" + a : a
            },
            configurable: !0,
            enumerable: !1
        }
    });

    function vk(a) {
        function b(e, f) {
            e & c && d.push(f)
        }
        var c = G(a, "state is only maintained on arrays.")[X] | 0,
            d = [];
        b(1, "IS_REPEATED_FIELD");
        b(2, "IS_IMMUTABLE_ARRAY");
        b(4, "IS_API_FORMATTED");
        b(512, "STRING_FORMATTED");
        b(1024, "GBIGINT_FORMATTED");
        b(1024, "BINARY");
        b(8, "ONLY_MUTABLE_VALUES");
        b(16, "UNFROZEN_SHARED");
        b(32, "MUTABLE_REFERENCES_ARE_OWNED");
        b(64, "CONSTRUCTED");
        b(128, "HAS_MESSAGE_ID");
        b(256, "FROZEN_ARRAY");
        b(2048, "HAS_WRAPPER");
        b(4096, "MUTABLE_SUBSTRUCTURES");
        b(8192, "KNOWN_MAP_ARRAY");
        c & 64 && (D(c & 64), a =
            c >> 14 & 1023 || 536870912, a !== 536870912 && d.push("pivot: " + a));
        return d.join(",")
    };
    var wk = Xj && Math.random() < .5,
        xk = wk ? Symbol() : void 0;

    function yk(a) {
        D(Z(a));
        return wk ? a[F(xk)] : a.B
    }
    var zk, Ak = typeof fk === "symbol",
        Bk = {};

    function Z(a) {
        var b = a[fk],
            c = b === Bk;
        D(!zk || c === a instanceof zk);
        if (Ak && b && !c) throw Error("ja");
        return c
    }

    function Ck(a) {
        return a != null && Z(a)
    }

    function Dk(a, b) {
        Eb(a);
        D(a > 0);
        D(b === 0 || b === -1);
        return a + b
    }

    function Ek(a, b) {
        D(b === Fk || b === void 0);
        return a + (b ? 0 : -1)
    }

    function Gk(a, b) {
        Eb(a);
        D(a >= 0);
        D(b === 0 || b === -1);
        return a - b
    }

    function Hk(a, b) {
        if (b === void 0) {
            if (b = !Ik(a)) D(Z(a)), a = wk ? a[F(xk)] : a.B, b = G(a, "state is only maintained on arrays.")[X] | 0, Y(a, b), b = !!(2 & b);
            return b
        }
        D(Z(a));
        var c = wk ? a[F(xk)] : a.B;
        var d = G(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        D(b === d);
        return !!(2 & b) && !Ik(a)
    }
    var Jk = {};

    function Ik(a) {
        var b = a.eh,
            c;
        (c = !b) || (D(Z(a)), a = wk ? a[F(xk)] : a.B, c = G(a, "state is only maintained on arrays.")[X] | 0, Y(a, c), c = !!(2 & c));
        D(c);
        D(b === void 0 || b === Jk);
        return b === Jk
    }

    function Kk(a, b) {
        D(Z(a));
        var c = wk ? a[F(xk)] : a.B;
        var d = G(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        D(b === !!(2 & d));
        a.eh = b ? Jk : void 0
    }
    var Lk = Symbol("exempted jspb subclass"),
        Mk = typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";

    function Nk() {}

    function Ok(a, b) {
        var c = nk(G(a));
        b || D(!(c & 2 && c & 4 || c & 256) || Object.isFrozen(a));
        Pk(a)
    }

    function Pk(a) {
        a = G(a, "state is only maintained on arrays.")[X] | 0;
        var b = a & 4,
            c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
        D(b && c <= 1 || !b && c === 0, "Expected at most 1 type-specific formatting bit, but got " + c + " with state: " + a)
    }
    var Qk = Object.freeze({}),
        Rk = Symbol("debugExtensions");

    function Sk(a, b, c) {
        D(b & 64);
        D(b & 64);
        var d = b & 128 ? 0 : -1;
        var e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        var g = e + (f ? -1 : 0),
            h = a[e - 1];
        D(!!f === (h != null && typeof h === "object" && h.constructor === Object));
        for (b = b & 128 ? 1 : 0; b < g; b++) h = a[b], c(Gk(b, d), h);
        if (f) {
            a = a[e - 1];
            for (var k in a) !isNaN(k) && c(+k, a[k])
        }
    }
    var Fk = {};

    function Tk(a, b) {
        a = G(a, "state is only maintained on arrays.")[X] | 0;
        D(a & 64);
        a & 128 ? D(b === Fk) : D(b === void 0)
    }

    function Uk(a) {
        D(a & 64);
        return a & 128 ? Fk : void 0
    };
    var Vk = {};

    function Wk(a) {
        a = Error(a);
        Sb(a, "warning");
        return a
    }

    function Xk(a, b, c) {
        if (a != null) {
            var d;
            var e = (d = Vk) != null ? d : Vk = {};
            d = e[a] || 0;
            d >= b || (e[a] = d + 1, a = Error(c), Sb(a, "incident"), Ph(a))
        }
    };

    function Yk(a) {
        return Array.prototype.slice.call(a)
    };
    var Zk = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        $k = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        al = Number.isSafeInteger,
        bl = Number.isFinite,
        cl = Math.trunc,
        dl = Number.MAX_SAFE_INTEGER;

    function el(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function fl(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function gl(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    var hl = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function il(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return bl(a);
            case "string":
                return hl.test(a);
            default:
                return !1
        }
    }

    function jl(a) {
        if (!bl(a)) throw a = "Expected enum as finite number but got " + Qa(a) + ": " + a, Wk(a);
        return a | 0
    }

    function kl(a) {
        return a == null ? a : bl(a) ? a | 0 : void 0
    }

    function ll(a) {
        return "Expected int32 as finite number but got " + Qa(a) + ": " + a
    }

    function ml(a) {
        if (typeof a !== "number") throw Wk(ll(a));
        if (!bl(a)) throw Wk(ll(a));
        return a | 0
    }

    function nl(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return bl(a) ? a | 0 : void 0
    }

    function ol(a) {
        return "Expected uint32 as finite number but got " + Qa(a) + ": " + a
    }

    function pl(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return bl(a) ? a >>> 0 : void 0
    }

    function ql(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Zk(64, a));
        if (il(a)) {
            if (b === "string") return D(il(a)), D(!0), b = cl(Number(a)), al(b) ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), D(a.indexOf(".") === -1), b = a.length, (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") || (wj(a), a = uj(ij, jj))), a;
            if (b === "number") return D(il(a)), D(!0), a = cl(a), al(a) || (D(!al(a)), D(Number.isInteger(a)), mj(a), a = sj(ij, jj)), a
        }
    }

    function rl(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String($k(64, a));
        if (il(a)) {
            if (b === "string") return D(il(a)), D(!0), b = cl(Number(a)), al(b) && b >= 0 ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), D(a.indexOf(".") === -1), a[0] === "-" ? b = !1 : (b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615"), b || (wj(a), a = qj(ij, jj))), a;
            if (b === "number") return D(il(a)), D(!0), a = cl(a), a >= 0 && al(a) || (D(a < 0 || a > dl), D(Number.isInteger(a)), mj(a), a = pj(ij, jj)), a
        }
    }

    function sl(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function tl(a, b) {
        if (!(a instanceof b)) throw Error("oa`" + fl(b) + "`" + (a && fl(a.constructor)));
    }

    function ul(a, b, c) {
        if (Ck(a)) return a;
        if (Array.isArray(a)) {
            var d = nk(a);
            c = d | c & 32 | c & 2;
            c !== d && mk(a, c);
            return new b(a)
        }
    };
    var vl = function(a, b) {
            this.qc = a >>> 0;
            this.jc = b >>> 0
        },
        xl = function(a) {
            if (!a) return wl || (wl = new vl(0, 0));
            if (!/^\d+$/.test(a)) return null;
            wj(a);
            return new vl(ij, jj)
        },
        wl, yl = function(a, b) {
            this.qc = a >>> 0;
            this.jc = b >>> 0
        },
        Al = function(a) {
            if (!a) return zl || (zl = new yl(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            wj(a);
            return new yl(ij, jj)
        },
        zl;
    var Bl = function() {
        this.G = []
    };
    Bl.prototype.length = function() {
        return this.G.length
    };
    Bl.prototype.end = function() {
        var a = this.G;
        this.G = [];
        return a
    };
    Bl.prototype.Va = function(a, b) {
        D(a == Math.floor(a));
        D(b == Math.floor(b));
        D(a >= 0 && a < 4294967296);
        for (D(b >= 0 && b < 4294967296); b > 0 || a > 127;) this.G.push(a & 127 | 128), a = (a >>> 7 | b << 25) >>> 0, b >>>= 7;
        this.G.push(a)
    };
    Bl.prototype.af = function(a, b) {
        D(a == Math.floor(a));
        D(b == Math.floor(b));
        D(a >= 0 && a < 4294967296);
        D(b >= 0 && b < 4294967296);
        this.Aa(a);
        this.Aa(b)
    };
    var Cl = function(a, b) {
            D(b == Math.floor(b));
            for (D(b >= 0 && b < 4294967296); b > 127;) a.G.push(b & 127 | 128), b >>>= 7;
            a.G.push(b)
        },
        Dl = function(a, b) {
            D(b == Math.floor(b));
            D(b >= -2147483648 && b < 2147483648);
            if (b >= 0) Cl(a, b);
            else {
                for (var c = 0; c < 9; c++) a.G.push(b & 127 | 128), b >>= 7;
                a.G.push(1)
            }
        };
    n = Bl.prototype;
    n.Aa = function(a) {
        D(a == Math.floor(a));
        D(a >= 0 && a < 4294967296);
        this.G.push(a >>> 0 & 255);
        this.G.push(a >>> 8 & 255);
        this.G.push(a >>> 16 & 255);
        this.G.push(a >>> 24 & 255)
    };
    n.Kg = function(a) {
        D(a == Math.floor(a));
        D(a >= 0 && a < 1.8446744073709552E19);
        lj(a);
        this.Aa(ij);
        this.Aa(jj)
    };
    n.Ig = function(a) {
        D(a == Math.floor(a));
        D(a >= -2147483648 && a < 2147483648);
        this.G.push(a >>> 0 & 255);
        this.G.push(a >>> 8 & 255);
        this.G.push(a >>> 16 & 255);
        this.G.push(a >>> 24 & 255)
    };
    n.Jg = function(a) {
        D(a == Math.floor(a));
        D(a >= -0x7fffffffffffffff && a < 0x7fffffffffffffff);
        mj(a);
        this.af(ij, jj)
    };
    n.Ze = function(a) {
        D(a == Infinity || a == -Infinity || isNaN(a) || typeof a === "number" && a >= -3.4028234663852886E38 && a <= 3.4028234663852886E38);
        var b = oj(4);
        b.setFloat32(0, +a, !0);
        jj = 0;
        ij = b.getUint32(0, !0);
        this.Aa(ij)
    };
    n.Ye = function(a) {
        D(typeof a === "number" || a === "Infinity" || a === "-Infinity" || a === "NaN");
        var b = oj(8);
        b.setFloat64(0, +a, !0);
        ij = b.getUint32(0, !0);
        jj = b.getUint32(4, !0);
        this.Aa(ij);
        this.Aa(jj)
    };
    n.Xe = function(a) {
        D(typeof a === "boolean" || typeof a === "number");
        this.G.push(a ? 1 : 0)
    };
    n.Dd = function(a) {
        D(a == Math.floor(a));
        D(a >= -2147483648 && a < 2147483648);
        Dl(this, a)
    };
    var El = function() {
            this.Md = [];
            this.ub = 0;
            this.D = new Bl
        },
        Fl = function(a, b) {
            b.length !== 0 && (a.Md.push(b), a.ub += b.length)
        },
        Hl = function(a, b) {
            Gl(a, b, 2);
            b = a.D.end();
            Fl(a, b);
            b.push(a.ub);
            return b
        },
        Il = function(a, b) {
            var c = b.pop();
            c = a.ub + a.D.length() - c;
            for (D(c >= 0); c > 127;) b.push(c & 127 | 128), c >>>= 7, a.ub++;
            b.push(c);
            a.ub++
        },
        Gl = function(a, b, c) {
            D(b >= 1 && b == Math.floor(b));
            Cl(a.D, b * 8 + c)
        },
        Jl = function(a, b, c) {
            if (c != null) switch (Gl(a, b, 0), typeof c) {
                case "number":
                    a = a.D;
                    D(c == Math.floor(c));
                    D(c >= 0 && c < 1.8446744073709552E19);
                    mj(c);
                    a.Va(ij, jj);
                    break;
                case "bigint":
                    c = BigInt.asUintN(64, c);
                    c = new vl(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                    a.D.Va(c.qc, c.jc);
                    break;
                default:
                    c = xl(c), a.D.Va(c.qc, c.jc)
            }
        };
    n = El.prototype;
    n.Ig = function(a, b) {
        b != null && (Kl(a, b, b >= -2147483648 && b < 2147483648), b != null && (Ll(a, b), Gl(this, a, 0), Dl(this.D, b)))
    };
    n.Jg = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Kl(a, b, Al(b));
                    break;
                case "number":
                    Kl(a, b, b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    break;
                default:
                    Kl(a, b, b >= BigInt(-0x7fffffffffffffff) && b < BigInt(0x7fffffffffffffff))
            }
            if (b != null) switch (Gl(this, a, 0), typeof b) {
                case "number":
                    a = this.D;
                    D(b == Math.floor(b));
                    D(b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    mj(b);
                    a.Va(ij, jj);
                    break;
                case "bigint":
                    b = BigInt.asUintN(64, b);
                    b = new yl(Number(b & BigInt(4294967295)), Number(b >> BigInt(32)));
                    this.D.Va(b.qc,
                        b.jc);
                    break;
                default:
                    b = Al(b), this.D.Va(b.qc, b.jc)
            }
        }
    };
    n.Aa = function(a, b) {
        b != null && (Kl(a, b, b >= 0 && b < 4294967296), b != null && (Gl(this, a, 0), Cl(this.D, b)))
    };
    n.Kg = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Kl(a, b, xl(b));
                    break;
                case "number":
                    Kl(a, b, b >= 0 && b < 1.8446744073709552E19);
                    break;
                default:
                    Kl(a, b, b >= BigInt(0) && b < BigInt(1.8446744073709552E19))
            }
            Jl(this, a, b)
        }
    };
    n.Ze = function(a, b) {
        b != null && (Gl(this, a, 5), this.D.Ze(b))
    };
    n.Ye = function(a, b) {
        b != null && (Gl(this, a, 1), this.D.Ye(b))
    };
    n.Xe = function(a, b) {
        b != null && (Kl(a, b, typeof b === "boolean" || typeof b === "number"), Gl(this, a, 0), this.D.Xe(b))
    };
    n.Dd = function(a, b) {
        b != null && (b = parseInt(b, 10), Ll(a, b), Gl(this, a, 0), Dl(this.D, b))
    };
    n.af = function(a, b) {
        Gl(this, a, 1);
        this.D.af(b)
    };
    n.Va = function(a, b) {
        Gl(this, a, 0);
        this.D.Va(b)
    };

    function Ll(a, b) {
        Kl(a, b, b === Math.floor(b));
        Kl(a, b, b >= -2147483648 && b < 2147483648)
    }

    function Kl(a, b, c) {
        c || Db("for [" + b + "] at [" + a + "]")
    };

    function Ml() {
        var a = function() {
            throw Error("pa");
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var Nl = Ml(),
        Ol = Ml(),
        Pl = Ml(),
        Ql = Ml(),
        Rl = Ml(),
        Sl = Ml(),
        Tl = Ml(),
        Ul = Ml(),
        Vl = Ml(),
        Wl = Ml(),
        Xl = Ml(),
        Yl = Ml();

    function Zl(a) {
        return a
    }
    Zl[gk] = {};

    function $l(a) {
        return a
    };
    var am = function() {
        throw Error("qa");
    };
    if (Mk) {
        var bm = function() {
                throw Error("ra");
            },
            cm = {};
        Object.defineProperties(am, (cm[Symbol.hasInstance] = {
            value: bm,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, cm));
        D(am[Symbol.hasInstance] === bm, "defineProperties did not work: was it monkey-patched?")
    };

    function dm(a) {
        var b = Ta(bk);
        return b ? G(a)[b] : void 0
    }
    var em = function() {},
        fm = function(a, b) {
            for (var c in a) !isNaN(c) && b(a, +c, G(a[c]))
        },
        gm = function(a) {
            var b = new em;
            fm(a, function(c, d, e) {
                b[d] = Yk(e)
            });
            b.Ie = a.Ie;
            return b
        },
        hm = {
            Ci: !0
        };

    function im(a, b, c) {
        var d = d === void 0 ? !1 : d;
        if (Ta(hk) && Ta(bk) && c === hk) {
            D(Z(a));
            c = wk ? a[F(xk)] : a.B;
            var e = c[bk];
            if (!e) return;
            if (e = e.Ie) try {
                e(c, b, hm);
                return
            } catch (f) {
                throw Error("sa`" + b);
            }
        }
        d && (D(Z(a)), a = yk(a), G(a), (d = Ta(bk)) && d in a && (a = a[d]) && delete a[b])
    }

    function jm(a, b) {
        D(Z(a));
        D(Z(a));
        a = wk ? a[F(xk)] : a.B;
        G(a);
        var c = Ta(bk),
            d;
        Xj && c && ((d = a[c]) == null ? void 0 : d[b]) != null && Xk(ck, 3, "0ub:" + b)
    }

    function km(a, b) {
        b < 100 || Xk(dk, 1, "0ubs:" + b)
    };

    function lm(a, b, c, d, e) {
        var f = d !== void 0;
        d = !!d;
        var g = Ta(bk),
            h;
        !f && Xj && g && (h = a[g]) && fm(h, km);
        g = [];
        var k = a.length;
        h = 4294967295;
        var l = !1,
            m = !!(b & 64);
        if (m) {
            D(b & 64);
            var u = b & 128 ? 0 : -1
        } else u = void 0;
        if (!(b & 1)) {
            var r = k && a[k - 1];
            r != null && typeof r === "object" && r.constructor === Object ? (k--, h = k) : r = void 0;
            if (m && !(b & 128) && !f) {
                l = !0;
                var t;
                b = (t = mm) != null ? t : Zl;
                h = Dk(b(Gk(h, F(u)), F(u), a, r, e), F(u))
            }
        }
        e = void 0;
        for (t = 0; t < k; t++)
            if (b = a[t], b != null && (b = c(b, d)) != null)
                if (m && t >= h) {
                    nm();
                    var w = Gk(t, F(u)),
                        v = void 0;
                    ((v = e) != null ? v : e = {})[w] =
                    b
                } else g[t] = b;
        if (r)
            for (var x in r) k = r[x], k != null && (k = c(k, d)) != null && (t = +x, b = void 0, m && !Number.isNaN(t) && (b = Dk(t, F(u))) < h ? (nm(), g[F(b)] = k) : (t = void 0, ((t = e) != null ? t : e = {})[x] = k));
        e && (l ? g.push(e) : (D(h < 4294967295), g[h] = e));
        f && Ta(bk) && (G(g), G(a), D(g[bk] === void 0), (a = dm(a)) && a instanceof em && (g[bk] = gm(a)));
        return g
    }

    function om(a) {
        F(a);
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return gj(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    Ok(a);
                    var b = G(a, "state is only maintained on arrays.")[X] | 0;
                    return a.length === 0 && b & 1 ? void 0 : lm(a, b, om)
                }
                if (Ck(a)) return pm(a);
                if (a instanceof Ui) {
                    b = a.Lc;
                    if (b == null) a = "";
                    else if (typeof b === "string") a = b;
                    else {
                        if (Li) {
                            for (var c = "", d = 0, e = b.length - 10240; d < e;) c += String.fromCharCode.apply(null, b.subarray(d, d += 10240));
                            c +=
                                String.fromCharCode.apply(null, d ? b.subarray(d) : b);
                            b = btoa(c)
                        } else b = Uh(b);
                        a = a.Lc = b
                    }
                    return a
                }
                D(!(a instanceof Uint8Array));
                return
        }
        return a
    }
    var mm;

    function qm(a) {
        D(!mm);
        return pm(a)
    }

    function pm(a) {
        D(Z(a));
        var b = wk ? a[F(xk)] : a.B;
        var c = G(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, c);
        return lm(b, c, om, void 0, a.constructor)
    }

    function nm() {
        var a, b = (a = mm) != null ? a : Zl;
        D(b !== $l)
    };
    if (typeof Proxy !== "undefined") {
        var sm = rm;
        new Proxy({}, {
            getPrototypeOf: sm,
            setPrototypeOf: sm,
            isExtensible: sm,
            preventExtensions: sm,
            getOwnPropertyDescriptor: sm,
            defineProperty: sm,
            has: sm,
            get: sm,
            set: sm,
            deleteProperty: sm,
            apply: sm,
            construct: sm
        })
    }

    function rm() {
        throw Error("xa");
    };
    var tm, um;

    function vm(a) {
        switch (typeof a) {
            case "boolean":
                return tm || (tm = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? um || (um = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return G(a), D(a.length === 2 || a.length === 3 && a[2] === !0), D(a[0] == null || typeof a[0] === "number" && a[0] >= 0), D(a[1] == null || typeof a[1] === "string"), a
        }
    }

    function wm(a, b) {
        G(b);
        return xm(a, b[0], b[1])
    }

    function xm(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a != null)
            for (var e = 0; e < a.length; e++) {
                var f = a[e];
                Array.isArray(f) && Ok(f)
            }
        if (a == null) e = 32, c ? (a = [c], e |= 128) : a = [], b && (e = sk(e, b));
        else {
            if (!Array.isArray(a)) throw Error("ya`" + JSON.stringify(a) + "`" + Qa(a));
            e = G(a, "state is only maintained on arrays.")[X] | 0;
            if (Ng && 1 & e) throw Error("za");
            2048 & e && !(2 & e) && ym();
            if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a)) throw Error("Aa");
            if (e & 256) throw Error("Ba");
            if (e & 64) return (e | d) !== e && mk(a, e |= d), Y(a, e), a;
            if (c &&
                (e |= 128, c !== a[0])) throw Error("Ca`" + c + "`" + JSON.stringify(a[0]) + "`" + Qa(a[0]));
            a: {
                c = a;e |= 64;
                var g = c.length;
                if (g) {
                    var h = g - 1;
                    f = c[h];
                    if (f != null && typeof f === "object" && f.constructor === Object) {
                        b = tk(e);
                        g = Gk(h, b);
                        if (g >= 1024) throw Error("Ea`" + g);
                        for (var k in f) h = +k, h < g && (h = Dk(h, b), D(c[h] == null), c[h] = f[k], delete f[k]);
                        e = sk(e, g);
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, Gk(g, tk(e)));
                    if (k > 1024) throw Error("Fa`" + g);
                    e = sk(e, k)
                }
            }
        }
        mk(a, e | 64 | d);
        return a
    }

    function ym() {
        if (Ng) throw Error("Da");
    };

    function zm(a) {
        D(!(2 & a));
        D(!(2048 & a));
        return !(4096 & a) && !(16 & a)
    }

    function Am(a, b) {
        F(a);
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            Ok(a);
            var c = G(a, "state is only maintained on arrays.")[X] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (b && zm(c) ? (ok(a, 34), c & 4 && Object.freeze(a)) : a = Bm(a, c, !1, b && !(c & 16)));
            return a
        }
        if (Ck(a)) return D(Ck(a)), b = yk(a), c = qk(b), Hk(a, c) ? a : Cm(a, b, c) ? Dm(a, b) : Bm(b, c);
        if (a instanceof Ui) return a;
        D(!(a instanceof Uint8Array))
    }

    function Dm(a, b, c) {
        a = new a.constructor(b);
        c && Kk(a, !0);
        a.ei = Jk;
        return a
    }

    function Bm(a, b, c, d) {
        D(b === (G(a, "state is only maintained on arrays.")[X] | 0));
        d != null || (d = !!(34 & b));
        a = lm(a, b, Am, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        mk(a, b);
        return a
    }

    function Em(a) {
        if (!Ik(a)) return !1;
        var b;
        D(Z(a));
        var c = b = wk ? a[F(xk)] : a.B,
            d = G(c, "state is only maintained on arrays.")[X] | 0;
        Y(c, d);
        D(d & 2);
        b = Bm(b, d);
        ok(b, 2048);
        D(Z(a));
        G(b);
        wk ? a[F(xk)] = b : a.B = b;
        Kk(a, !1);
        a.ei = void 0;
        return !0
    }

    function Fm(a) {
        var b;
        if (b = !Em(a)) {
            D(Z(a));
            b = wk ? a[F(xk)] : a.B;
            var c = G(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, c);
            b = Hk(a, c)
        }
        if (b) throw Error("ka");
    }

    function Gm(a, b) {
        if (b === void 0) b = G(a, "state is only maintained on arrays.")[X] | 0, Y(a, b, !0);
        else {
            var c = G(a, "state is only maintained on arrays.")[X] | 0;
            Y(a, c, !0);
            D(b === c)
        }
        D(!(b & 2));
        b & 32 && !(b & 4096) && mk(a, b | 4096)
    }

    function Cm(a, b, c) {
        return Lk && a[Lk] ? !1 : c & 2 ? !0 : c & 32 && !(c & 4096) ? (mk(b, c | 2), Kk(a, !0), !0) : !1
    };
    var Im = function(a, b) {
            D(Object.isExtensible(a));
            D(Z(a));
            a = wk ? a[F(xk)] : a.B;
            b = Hm(a, b);
            (a = b !== null) || (a = void 0);
            if (a) return b
        },
        Hm = function(a, b, c, d) {
            Tk(a, c);
            if (b === -1) return null;
            var e = Ek(b, c);
            D(e === Dk(b, tk(G(a, "state is only maintained on arrays.")[X] | 0)));
            D(e >= 0);
            var f = a.length - 1;
            if (!(f < Ek(1, c))) {
                if (e >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        c = g[b];
                        var h = !0
                    } else if (e === f) c = g;
                    else return
                } else c = a[e];
                if (d && c != null) {
                    d = d(c);
                    if (d == null) return d;
                    if (!Object.is(d, c)) return h ? g[b] =
                        d : a[e] = d, d
                }
                return c
            }
        },
        Km = function(a, b, c) {
            Fm(a);
            D(Z(a));
            var d = wk ? a[F(xk)] : a.B;
            var e = G(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, e);
            Jm(d, e, b, c);
            return a
        };

    function Jm(a, b, c, d, e) {
        Tk(a, e);
        var f = Ek(c, e);
        D(f === Dk(c, tk(G(a, "state is only maintained on arrays.")[X] | 0)));
        D(f >= 0);
        var g = a.length - 1;
        if (g >= Ek(1, e) && f >= g) {
            var h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && ((g = b) == null && (b = G(a, "state is only maintained on arrays.")[X] | 0, Y(a, b), g = b), D(g & 64), g = g >> 14 & 1023 || 536870912, c >= g ? (D(g !== 536870912), d != null && (f = {}, a[Ek(g, e)] = (f[c] = d, f))) : a[f] = d);
        return b
    }
    var Mm = function(a, b, c, d) {
        D(Z(a));
        a = wk ? a[F(xk)] : a.B;
        var e = G(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, e);
        return Lm(a, e, b, c, d) !== void 0
    };

    function Nm(a, b) {
        if (!a) return a;
        D(rk(b) ? Hk(a) : !0);
        return a
    }

    function Om(a, b, c) {
        c = c === void 0 ? !1 : c;
        Ok(a, c);
        var d = G(a, "state is only maintained on arrays.")[X] | 0;
        D(d & 1);
        c || (D(Object.isFrozen(a) || d & 16), D(rk(b) ? Object.isFrozen(a) : !0))
    }

    function Pm(a, b, c, d, e) {
        D(Z(a));
        var f = wk ? a[F(xk)] : a.B;
        var g = G(f, "state is only maintained on arrays.")[X] | 0;
        Y(f, g);
        d = Hk(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && Em(a) && (D(Z(a)), f = wk ? a[F(xk)] : a.B, g = G(f, "state is only maintained on arrays.")[X] | 0, Y(f, g));
        a = Qm(f, b);
        var h = a === kk ? 7 : G(a, "state is only maintained on arrays.")[X] | 0,
            k = Rm(h, g);
        Pk(a);
        var l = 4 & k ? !1 : !0;
        if (l) {
            4 & k && (a = Yk(a), h = 0, k = Sm(k, g), g = F(Jm(f, g, b, a)));
            for (var m = 0, u = 0; m < a.length; m++) {
                var r = c(a[m]);
                r != null && (a[u++] = r)
            }
            u < m && (a.length = u);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (mk(a, k), 2 & k && Object.freeze(a));
        a = Tm(a, k, f, g, b, d, l, e);
        Pk(a);
        e || Om(a, f);
        return a
    }

    function Tm(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Um(b) || (e = !a.length || g && !(4096 & b) || !!(32 & d) && zm(b), b |= e ? 2 : 256, b !== k && mk(a, b), Object.freeze(a)) : (f === 2 && Um(b) && (a = Yk(a), k = 0, b = Sm(b, d), d = F(Jm(c, d, e, a))), Um(b) || (h || (b |= 16), b !== k && mk(a, b)));
        2 & b || zm(b) || Gm(c, d);
        return a
    }

    function Qm(a, b, c) {
        a = Hm(a, b, c);
        return Array.isArray(a) ? a : kk
    }

    function Rm(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Um(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Vm(a, b, c) {
        if (b & 2) throw Error("ka");
        var d = Uk(b),
            e = Qm(a, c, d),
            f = e === kk ? 7 : G(e, "state is only maintained on arrays.")[X] | 0,
            g = Rm(f, b);
        if (2 & g || Um(g) || 16 & g) g === f || Um(g) || mk(e, g), e = Yk(e), f = 0, g = Sm(g, b), F(Jm(a, b, c, e, d));
        g &= -13;
        g !== f && mk(e, g);
        return e
    }
    var Wm = function(a, b, c) {
        var d = G(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, d, !0);
        var e = Uk(d),
            f = Hm(a, c, e);
        if (Ck(f)) {
            if (!Hk(f)) return Em(f), D(Z(f)), wk ? f[F(xk)] : f.B;
            D(Z(f));
            var g = wk ? f[F(xk)] : f.B;
            D((G(g, "state is only maintained on arrays.")[X] | 0) & 2)
        } else Array.isArray(f) && (g = f);
        if (g) {
            var h = G(g, "state is only maintained on arrays.")[X] | 0;
            h & 2 && (g = Bm(g, h))
        }
        g = wm(g, b);
        g !== f && Jm(a, d, c, g, e);
        return g
    };

    function Lm(a, b, c, d, e) {
        var f = !1;
        d = Hm(a, d, e, function(g) {
            var h = ul(g, c, b);
            f = h !== g && h != null;
            return h
        });
        if (d != null) return f && !Hk(d) && Gm(a, b), Nm(d, a)
    }
    var Ym = function(a) {
            var b = Xm;
            D(Z(a));
            a = wk ? a[F(xk)] : a.B;
            var c = G(a, "state is only maintained on arrays.")[X] | 0;
            Y(a, c);
            (a = Lm(a, c, b, 2)) || (a = b[ak]) || (a = new b, D(Z(a)), c = wk ? a[F(xk)] : a.B, ok(c, 34), a = b[ak] = a);
            return a
        },
        Zm = function(a, b, c, d) {
            D(Z(a));
            var e = wk ? a[F(xk)] : a.B;
            var f = G(e, "state is only maintained on arrays.")[X] | 0;
            Y(e, f);
            b = Lm(e, f, b, c, d);
            if (b == null) return b;
            f = G(e, "state is only maintained on arrays.")[X] | 0;
            Y(e, f);
            if (!Hk(a, f)) {
                var g = b;
                D(Z(g));
                var h = wk ? g[F(xk)] : g.B;
                var k = G(h, "state is only maintained on arrays.")[X] |
                    0;
                Y(h, k);
                g = Hk(g, k) ? Cm(g, h, k) ? Dm(g, h, !0) : new g.constructor(Bm(h, k, !1)) : g;
                g !== b && (Em(a) && (D(Z(a)), e = wk ? a[F(xk)] : a.B, a = G(e, "state is only maintained on arrays.")[X] | 0, Y(e, a), f = a), b = g, f = Jm(e, f, c, b, d), Gm(e, f))
            }
            return Nm(b, e)
        },
        an = function(a) {
            var b = $m;
            D(Z(a));
            var c = wk ? a[F(xk)] : a.B;
            var d = G(c, "state is only maintained on arrays.")[X] | 0;
            Y(c, d);
            Hk(a, d);
            var e = !!e || !1;
            a = Qm(c, 10);
            var f = a === kk ? 7 : G(a, "state is only maintained on arrays.")[X] | 0,
                g = Rm(f, d),
                h = !(4 & g);
            if (h) {
                var k = a,
                    l = d,
                    m = !!(2 & g);
                m && (l |= 2);
                for (var u = !m,
                        r = !0, t = 0, w = 0; t < k.length; t++) {
                    var v = ul(k[t], b, l);
                    if (v instanceof b) {
                        if (!m) {
                            var x = Hk(v);
                            u && (u = !x);
                            r && (r = x)
                        }
                        k[w++] = v
                    }
                }
                w < t && (k.length = w);
                g |= 4;
                g = r ? g & -4097 : g | 4096;
                g = u ? g | 8 : g & -9
            }
            g !== f && (mk(a, g), 2 & g && Object.freeze(a));
            a = Tm(a, g, c, d, 10, 1, h, e);
            if (!e) {
                b = a;
                d = !1;
                d = d === void 0 ? !1 : d;
                e = rk(c);
                f = rk(b);
                h = Object.isFrozen(b) && f;
                Om(b, c, d);
                if (e || f) d ? D(f) : D(h);
                D(!!((G(b, "state is only maintained on arrays.")[X] | 0) & 4));
                if (f && b.length)
                    for (d = 0; d < 1; d++) Nm(b[d], c)
            }
            return a
        },
        bn = function(a, b, c, d) {
            d != null ? tl(d, F(b)) : d = void 0;
            Km(a,
                c, d);
            d && !Hk(d) && (D(Z(a)), b = wk ? a[F(xk)] : a.B, Gm(b));
            return a
        };

    function Sm(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }
    var cn = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            var d;
            return (d = gl(Im(a, b))) != null ? d : c
        },
        dn = function(a, b) {
            var c = c === void 0 ? 0 : c;
            var d;
            return (d = nl(Im(a, b))) != null ? d : c
        },
        en = function(a, b) {
            var c = c === void 0 ? "" : c;
            a = sl(Im(a, b));
            return a != null ? a : c
        },
        fn = function(a, b, c) {
            if (c != null && typeof c !== "boolean") throw Error("ma`" + Qa(c) + "`" + c);
            return Km(a, b, c)
        },
        gn = function(a, b, c) {
            if (c != null) {
                if (typeof c !== "number") throw Wk(ol(c));
                if (!bl(c)) throw Wk(ol(c));
                c >>>= 0
            }
            return Km(a, b, c)
        },
        hn = function(a, b, c) {
            if (c != null && typeof c !== "string") throw Error("na`" +
                c + "`" + Qa(c));
            return Km(a, b, c)
        },
        jn = function(a, b, c) {
            return Km(a, b, c == null ? c : jl(c))
        },
        kn = function(a, b, c) {
            Fm(a);
            b = Pm(a, b, kl, 2, !0);
            b === kk || G(b, "state is only maintained on arrays.");
            if (Array.isArray(c))
                for (var d = c.length, e = 0; e < d; e++) b.push(jl(c[e]));
            else
                for (c = y(c), d = c.next(); !d.done; d = c.next()) b.push(jl(d.value));
            Pk(b);
            return a
        };
    var ln = function(a, b, c) {
        this.preventPassingToStructuredClone = Nk;
        Jb(this, ln, "The message constructor should only be used by subclasses");
        D(this.constructor !== ln, "Message is an abstract class and cannot be directly constructed");
        a = xm(a, b, c, 2048);
        D(Z(this));
        G(a);
        wk ? this[F(xk)] = a : this.B = a;
        D(Z(this));
        a = wk ? this[F(xk)] : this.B;
        b = G(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, b);
        D(b & 64);
        D(b & 2048)
    };
    n = ln.prototype;
    n.toJSON = function() {
        return qm(this)
    };
    n.Ta = function() {
        return JSON.stringify(qm(this))
    };
    n.getExtension = function(a) {
        Jb(this, a.Af);
        var b = Jb(this, ln);
        jm(b, a.ca);
        im(b, a.ca, a.we);
        return a.cb ? a.md ? a.Bb(b, a.cb, a.ca, void 0 === Qk ? 2 : 4, a.hb) : a.Bb(b, a.cb, a.ca, a.hb) : a.md ? a.Bb(b, a.ca, void 0 === Qk ? 2 : 4, a.hb) : a.Bb(b, a.ca, a.defaultValue, a.hb)
    };
    n.hasExtension = function(a) {
        D(!a.md, "repeated extensions don't support hasExtension");
        var b = Jb(this, ln);
        jm(b, a.ca);
        im(b, a.ca, a.we);
        a.cb ? a = Mm(b, a.cb, a.ca, a.hb) : (D(!a.md, "repeated extensions don't support getExtensionOrUndefined"), Jb(b, a.Af), b = Jb(b, ln), jm(b, a.ca), im(b, a.ca, a.we), a = a.cb ? a.Bb(b, a.cb, a.ca, a.hb) : a.Bb(b, a.ca, null, a.hb), a = (a === null ? void 0 : a) !== void 0);
        return a
    };
    n.clone = function() {
        var a = Jb(this, ln);
        D(Ck(a));
        var b = yk(a),
            c = qk(b);
        return Cm(a, b, c) ? Dm(a, b, !0) : new a.constructor(Bm(b, c, !1))
    };
    n.Yf = function() {
        return Hk(this)
    };
    zk = ln;
    ln.prototype[fk] = Bk;
    ln.prototype.toString = function() {
        D(Z(this));
        return (wk ? this[F(xk)] : this.B).toString()
    };
    var mn = function(a, b, c, d) {
        this.Ed = a;
        this.Fd = b;
        a = Ta(Ol);
        this.Lg = !!a && d === a || !1
    };

    function nn(a) {
        var b = rn;
        var c = c === void 0 ? Ol : c;
        return new mn(a, b, !1, c)
    }

    function rn(a, b, c, d, e) {
        b = sn(b, d);
        b != null && (c = Hl(a, c), e(b, a), Il(a, c))
    }
    var tn = nn(function(a, b, c, d, e) {
            if (a.j !== 2) return !1;
            Pj(a, Wm(b, d, c), e);
            return !0
        }),
        un = nn(function(a, b, c, d, e) {
            if (a.j !== 2) return !1;
            Pj(a, Wm(b, d, c), e);
            return !0
        }),
        vn = Symbol(),
        wn = Symbol(),
        xn = Symbol(),
        yn = Symbol(),
        zn = Symbol(),
        An, Bn;

    function Cn(a, b, c, d) {
        var e = d[a];
        if (e) return e;
        e = {};
        e.Wg = d;
        e.wc = D(vm(d[0]));
        var f = d[1],
            g = 1;
        f && f.constructor === Object && (e.ae = f, f = d[++g], typeof f === "function" && (An != null && (D(An === f), D(Bn === d[1 + g])), e.ag = !0, An != null || (An = f), Bn != null || (Bn = Gb(d[g + 1])), f = d[g += 2]));
        for (var h = {}; f && Dn(f);) {
            for (var k = 0; k < f.length; k++) h[f[k]] = f;
            f = d[++g]
        }
        for (k = 1; f !== void 0;) {
            typeof f === "number" && (D(f > 0), k += f, f = d[++g]);
            var l = void 0;
            if (f instanceof mn) var m = f;
            else m = tn, g--;
            f = void 0;
            if ((f = m) == null ? 0 : f.Lg) {
                f = d[++g];
                l = d;
                var u = g;
                typeof f ===
                    "function" && (D(f.length === 0), f = f(), l[u] = f);
                En(f);
                l = f
            }
            f = d[++g];
            u = k + 1;
            typeof f === "number" && f < 0 && (u -= f, f = d[++g]);
            for (; k < u; k++) {
                var r = h[k];
                l ? c(e, k, D(m), l, r) : b(e, k, D(m), r)
            }
        }
        return d[a] = e
    }

    function Dn(a) {
        return Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    }

    function En(a) {
        if (Array.isArray(a) && a.length) {
            var b = a[0];
            var c = vm(b);
            c != null && c !== b && (a[0] = c);
            b = c != null
        } else b = !1;
        D(b);
        return a
    }

    function Fn(a) {
        return Array.isArray(a) ? a[0] instanceof mn ? (D(a.length === 2), En(a[1]), a) : [un, En(a)] : [Jb(a, mn), void 0]
    }

    function sn(a, b) {
        if (a instanceof ln) return D(Z(a)), wk ? a[F(xk)] : a.B;
        if (Array.isArray(a)) return wm(a, b)
    };

    function Gn(a) {
        return Cn(wn, Hn, In, a)
    }

    function Hn(a, b, c, d) {
        var e = c.Ed;
        a[b] = d ? function(f, g, h) {
            return e(f, g, h, d)
        } : e
    }

    function In(a, b, c, d, e) {
        var f = c.Ed,
            g, h;
        a[b] = function(k, l, m) {
            return f(k, l, m, h || (h = Gn(d).wc), g || (g = Jn(d)), e)
        }
    }

    function Jn(a) {
        var b = a[xn];
        if (b != null) return b;
        var c = Gn(a);
        b = c.ag ? function(d, e) {
            return D(An)(d, e, c)
        } : function(d, e) {
            var f = G(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, f, !0);
            for (D(!(f & 2)); Nj(e) && e.j != 4;) {
                f = e.Kb;
                var g = c[f];
                if (g == null) {
                    var h = c.ae;
                    h && (h = h[f]) && (h = Kn(h), h != null && (g = c[f] = h))
                }
                if (g == null || !g(e, d, f)) {
                    h = e;
                    g = h.fb;
                    Oj(h);
                    if (h.Xd) var k = void 0;
                    else {
                        var l = h.o.aa(),
                            m = l - g;
                        h.o.R = g;
                        g = h.o.Ee(m);
                        D(l == h.o.aa());
                        k = g
                    }
                    l = h = g = void 0;
                    m = d;
                    G(m);
                    k && ((g = (h = (l = m[bk]) != null ? l : m[bk] = new em)[f]) != null ? g : h[f] = []).push(k)
                }
            }
            if (d =
                dm(d)) d.Ie = F(c.Wg[zn]);
            return !0
        };
        a[xn] = b;
        a[zn] = Ln.bind(a);
        return b
    }

    function Ln(a, b, c, d) {
        var e = this[wn],
            f = this[xn],
            g = wm(void 0, e.wc),
            h = dm(a);
        if (h) {
            var k = !1,
                l = e.ae;
            if (l) {
                e = function(w, v, x) {
                    if (x.length !== 0)
                        if (l[v])
                            for (w = y(x), v = w.next(); !v.done; v = w.next()) {
                                v = Mj(v.value);
                                try {
                                    k = !0, f(g, v)
                                } finally {
                                    v.ce()
                                }
                            } else d == null || d(a, v, x)
                };
                if (b == null) fm(h, e);
                else if (h != null) {
                    var m = h[b];
                    m && e(h, b, m)
                }
                if (k) {
                    var u = pk(a);
                    if (u & 2 && u & 2048 && (c == null || !c.Ci)) throw Error("Ha");
                    var r = Uk(u),
                        t = function(w, v) {
                            if (Hm(a, w, r) != null) switch (c == null ? void 0 : c.ek) {
                                case 1:
                                    return;
                                default:
                                    throw Error("Ia`" + w);
                            }
                            v != null && (u = F(Jm(a, u, w, v, r)));
                            delete h[w]
                        };
                    b == null ? Sk(g, pk(g), function(w, v) {
                        t(w, v)
                    }) : t(b, Hm(g, b, r))
                }
            }
        }
    }

    function Kn(a) {
        a = Fn(a);
        var b = Jb(a[0], mn).Ed;
        if (a = a[1]) {
            var c = Jn(En(a)),
                d = Gn(En(a)).wc;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    };

    function Mn(a, b, c) {
        a[b] = c.Fd
    }

    function Nn(a, b, c, d) {
        var e, f, g = c.Fd;
        a[b] = function(h, k, l) {
            return g(h, k, l, f || (f = Cn(vn, Mn, Nn, d).wc), e || (e = On(d)))
        }
    }

    function On(a) {
        var b = a[yn];
        if (!b) {
            var c = Cn(vn, Mn, Nn, a);
            b = function(d, e) {
                return Pn(d, e, c)
            };
            a[yn] = b
        }
        return b
    }

    function Pn(a, b, c) {
        Sk(a, G(a, "state is only maintained on arrays.")[X] | 0, function(e, f) {
            if (f != null) {
                var g = Qn(c, e);
                g ? g(b, f, e) : (G(a), e < 500 || Xk(ek, 3, "0ubsb:" + e))
            }
        });
        var d = dm(a);
        d && fm(d, function(e, f, g) {
            Fl(b, b.D.end());
            for (e = 0; e < g.length; e++) Fl(b, Wi(g[e]))
        })
    }

    function Qn(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.ae)
            if (c = c[b]) {
                c = Fn(c);
                var d = Jb(c[0], mn).Fd;
                if (c = c[1]) {
                    c = En(c);
                    var e = On(c),
                        f = Cn(vn, Mn, Nn, c).wc;
                    c = a.ag ? D(Bn)(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };

    function Rn(a, b, c) {
        if (Array.isArray(b)) {
            var d = G(b, "state is only maintained on arrays.")[X] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                g != null && (D(typeof g !== "object" || g instanceof Ui), b[f++] = g)
            }
            f < e && (b.length = f);
            a = d | 1;
            c && (a = (a | 4) & -1537);
            a !== d && mk(b, a);
            c && a & 2 && Object.freeze(b);
            return b
        }
    }

    function Sn(a, b, c) {
        return new mn(a, b, !1, c)
    }

    function Tn(a, b, c) {
        return new mn(a, b, Nl, c)
    }

    function Un(a, b, c) {
        var d = G(a, "state is only maintained on arrays.")[X] | 0;
        Y(a, d, !0);
        Jm(a, d, b, c, Uk(G(a, "state is only maintained on arrays.")[X] | 0))
    }

    function Vn(a, b, c) {
        if (a.j !== 0 && a.j !== 2) return !1;
        var d = G(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, d, !0);
        b = Vm(b, d, c);
        a.j == 2 ? Wj(a, Hj, b) : b.push(Uj(a));
        return !0
    }
    var Wn = Sn(function(a, b, c) {
            if (a.j !== 1) return !1;
            D(a.j == 1);
            var d = a.o;
            a = Fj(d);
            var e = Fj(d);
            d = (e >> 31) * 2 + 1;
            var f = e >>> 20 & 2047;
            a = 4294967296 * (e & 1048575) + a;
            Un(b, c, f == 2047 ? a ? NaN : d * Infinity : f == 0 ? d * 4.9E-324 * a : d * Math.pow(2, f - 1075) * (a + 4503599627370496));
            return !0
        }, function(a, b, c) {
            a.Ye(c, el(b))
        }, Xl),
        Xn = Sn(function(a, b, c) {
            if (a.j !== 5) return !1;
            D(a.j == 5);
            var d = Fj(a.o);
            a = (d >> 31) * 2 + 1;
            var e = d >>> 23 & 255;
            d &= 8388607;
            Un(b, c, e == 255 ? d ? NaN : a * Infinity : e == 0 ? a * 1.401298464324817E-45 * d : a * Math.pow(2, e - 150) * (d + 8388608));
            return !0
        }, function(a,
            b, c) {
            a.Ze(c, el(b))
        }, Wl),
        Yn = Sn(function(a, b, c) {
            if (Og) return a.j !== 0 ? b = !1 : (D(a.j == 0), a = Aj(a.o, tj), Un(b, c, a), b = !0), b;
            if (a.j !== 0) return !1;
            D(a.j == 0);
            a = Aj(a.o, sj);
            Un(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Jg(c, ql(b))
        }, Ul),
        Zn = Sn(function(a, b, c) {
            if (Og) return a.j !== 0 ? a = !1 : (Un(b, c, Tj(a)), a = !0), a;
            if (a.j !== 0) return !1;
            Un(b, c, Sj(a));
            return !0
        }, function(a, b, c) {
            a.Kg(c, rl(b))
        }, Vl),
        $n = Tn(function(a, b, c) {
            if (Og) {
                if (a.j !== 0 && a.j !== 2) a = !1;
                else {
                    var d = G(b, "state is only maintained on arrays.")[X] | 0;
                    Y(b, d, !0);
                    b = Vm(b, d, c);
                    a.j ==
                        2 ? Wj(a, Ej, b) : b.push(Tj(a));
                    a = !0
                }
                return a
            }
            if (a.j !== 0 && a.j !== 2) return !1;
            d = G(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Vm(b, d, c);
            a.j == 2 ? Wj(a, Dj, b) : b.push(Sj(a));
            return !0
        }, function(a, b, c) {
            b = Rn(rl, b, !1);
            if (b != null)
                for (var d = 0; d < b.length; d++) Jl(a, c, b[d])
        }, Vl),
        ao = Sn(function(a, b, c) {
            if (a.j !== 0) return !1;
            Un(b, c, Qj(a));
            return !0
        }, function(a, b, c) {
            a.Ig(c, nl(b))
        }, Rl),
        bo = Tn(function(a, b, c) {
            if (a.j !== 0 && a.j !== 2) return !1;
            var d = G(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Vm(b, d, c);
            a.j ==
                2 ? Wj(a, Bj, b) : b.push(Qj(a));
            return !0
        }, function(a, b, c) {
            b = Rn(nl, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) {
                    var e = a,
                        f = c,
                        g = b[d];
                    g != null && (Ll(f, g), Gl(e, f, 0), Dl(e.D, g))
                }
        }, Rl),
        co = Sn(function(a, b, c) {
            if (a.j !== 5) return !1;
            D(a.j == 5);
            a = Fj(a.o);
            Un(b, c, a);
            return !0
        }, function(a, b, c) {
            b = pl(b);
            b != null && (Kl(c, b, b >= 0 && b < 4294967296), Gl(a, c, 5), a.D.Aa(b))
        }, Tl),
        eo = Sn(function(a, b, c) {
            if (a.j !== 0) return !1;
            D(a.j == 0);
            a = Gj(a.o);
            Un(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Xe(c, gl(b))
        }, Pl),
        fo = Sn(function(a, b, c) {
            if (a.j !== 2) return !1;
            Un(b,
                c, Vj(a));
            return !0
        }, function(a, b, c) {
            b = sl(b);
            if (b != null) {
                var d = !0;
                d = d === void 0 ? !1 : d;
                Fb(b);
                if (Ji) {
                    if (d && (Ii ? !b.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(b))) throw Error("U");
                    b = (Hi || (Hi = new TextEncoder)).encode(b)
                } else {
                    for (var e = 0, f = new Uint8Array(3 * b.length), g = 0; g < b.length; g++) {
                        var h = b.charCodeAt(g);
                        if (h < 128) f[e++] = h;
                        else {
                            if (h < 2048) f[e++] = h >> 6 | 192;
                            else {
                                D(h < 65536);
                                if (h >= 55296 && h <= 57343) {
                                    if (h <= 56319 && g < b.length) {
                                        var k = b.charCodeAt(++g);
                                        if (k >= 56320 &&
                                            k <= 57343) {
                                            h = (h - 55296) * 1024 + k - 56320 + 65536;
                                            f[e++] = h >> 18 | 240;
                                            f[e++] = h >> 12 & 63 | 128;
                                            f[e++] = h >> 6 & 63 | 128;
                                            f[e++] = h & 63 | 128;
                                            continue
                                        } else g--
                                    }
                                    if (d) throw Error("U");
                                    h = 65533
                                }
                                f[e++] = h >> 12 | 224;
                                f[e++] = h >> 6 & 63 | 128
                            }
                            f[e++] = h & 63 | 128
                        }
                    }
                    b = e === f.length ? f : f.subarray(0, e)
                }
                Gl(a, c, 2);
                Cl(a.D, b.length);
                Fl(a, a.D.end());
                Fl(a, b)
            }
        }, Ql),
        go, ho = void 0;
    ho = ho === void 0 ? Ol : ho;
    go = new mn(function(a, b, c, d, e) {
        if (a.j !== 2) return !1;
        d = wm(void 0, d);
        var f = G(b, "state is only maintained on arrays.")[X] | 0;
        Y(b, f, !0);
        Vm(b, f, c).push(d);
        Pj(a, d, e);
        return !0
    }, function(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) {
                var g = a,
                    h = c,
                    k = e,
                    l = sn(b[f], d);
                l != null && (h = Hl(g, h), k(l, g), Il(g, h))
            }
            a = nk(b);
            a & 1 || mk(b, a | 1)
        }
    }, Nl, ho);
    var io = Sn(function(a, b, c) {
            if (a.j !== 0) return !1;
            Un(b, c, Rj(a));
            return !0
        }, function(a, b, c) {
            a.Aa(c, pl(b))
        }, Sl),
        jo = Tn(function(a, b, c) {
            if (a.j !== 0 && a.j !== 2) return !1;
            var d = G(b, "state is only maintained on arrays.")[X] | 0;
            Y(b, d, !0);
            b = Vm(b, d, c);
            a.j == 2 ? Wj(a, Cj, b) : b.push(Rj(a));
            return !0
        }, function(a, b, c) {
            b = Rn(pl, b, !0);
            if (b != null && b.length) {
                c = Hl(a, c);
                for (var d = 0; d < b.length; d++) Cl(a.D, b[d]);
                Il(a, c)
            }
        }, Sl),
        ko = Sn(function(a, b, c) {
            if (a.j !== 0) return !1;
            Un(b, c, Uj(a));
            return !0
        }, function(a, b, c) {
            a.Dd(c, nl(b))
        }, Yl),
        lo = Tn(Vn, function(a,
            b, c) {
            b = Rn(nl, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) a.Dd(c, b[d])
        }, Yl),
        mo = Tn(Vn, function(a, b, c) {
            b = Rn(nl, b, !0);
            if (b != null && b.length) {
                c = Hl(a, c);
                for (var d = 0; d < b.length; d++) a.D.Dd(b[d]);
                Il(a, c)
            }
        }, Yl);
    var po = function() {
        var a = no,
            b = oo;
        D(!0);
        this.ca = 4156379;
        this.Af = a;
        this.cb = b;
        this.md = 0;
        this.Bb = Zm;
        this.defaultValue = void 0;
        this.hb = a.Ij != null ? Fk : void 0;
        this.we = void 0;
        D(!0, "lazyParse must be undefined or LAZILY_PARSE_LATE_LOADED_EXTENSIONS_SYMBOL")
    };
    po.prototype.register = function() {
        Ig(this)
    };

    function qo(a) {
        if (a instanceof ln) return a.constructor.V
    };
    (function() {
        var a = Oa.jspbGetTypeName;
        Oa.jspbGetTypeName = a ? function(b) {
            return a(b) || qo(b)
        } : qo
    })();
    var ro = ln;

    function so(a, b) {
        return function(c, d) {
            var e = {
                Ad: !0
            };
            d && Object.assign(e, d);
            c = Mj(c, void 0, void 0, e);
            try {
                var f = new a,
                    g = yk(f);
                Jn(b)(g, c);
                var h = f
            } finally {
                c.ce()
            }
            return h
        }
    }

    function to(a) {
        return function() {
            var b = new El;
            Pn(yk(Jb(this, ln)), b, Cn(vn, Mn, Nn, a));
            Fl(b, b.D.end());
            for (var c = new Uint8Array(b.ub), d = b.Md, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            D(f == c.length);
            b.Md = [c];
            return c
        }
    }

    function uo(a) {
        return function(b) {
            Gb(a);
            if (b == null || b == "") b = Jb(new a, ln);
            else {
                Fb(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Ga`" + Qa(b) + "`" + b);
                ok(b, 32);
                b = new a(b)
            }
            return b
        }
    };
    var $m = function(a) {
        ro.call(this, a)
    };
    q($m, ro);
    $m.prototype.Lf = function() {
        return en(this, 2)
    };
    $m.V = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var vo = [0, fo, -1];
    $m.prototype.O = to(vo);
    var wo = function(a) {
        ro.call(this, a)
    };
    q(wo, ro);
    var xo = function(a, b) {
            return hn(a, 2, b)
        },
        yo = function(a, b) {
            return hn(a, 3, b)
        },
        zo = function(a, b) {
            return hn(a, 4, b)
        },
        Ao = function(a, b) {
            return hn(a, 5, b)
        },
        Bo = function(a, b) {
            return hn(a, 9, b)
        },
        Co = function(a, b) {
            var c = $m;
            Fm(a);
            D(Z(a));
            var d = wk ? a[F(xk)] : a.B;
            var e = G(d, "state is only maintained on arrays.")[X] | 0;
            Y(d, e);
            if (b == null) Jm(d, e, 10);
            else {
                var f = b;
                if (!Array.isArray(f)) throw a = "Expected array but got " + Qa(f) + ": " + f, Wk(a);
                for (var g = f = b === kk ? 7 : G(b, "state is only maintained on arrays.")[X] | 0, h = Um(f), k = h || Object.isFrozen(b),
                        l = !0, m = !0, u = 0; u < b.length; u++) {
                    var r = b[u];
                    tl(r, F(c));
                    h || (r = Hk(r), l && (l = !r), m && (m = r))
                }
                h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
                k && f === g || (b = Yk(b), g = 0, f = Sm(f, e));
                f !== g && mk(b, f);
                Ok(b);
                e = Jm(d, e, 10, b);
                2 & f || zm(f) || Gm(d, e)
            }
            return a
        },
        Do = function(a, b) {
            return fn(a, 11, b)
        },
        Eo = function(a, b) {
            return hn(a, 1, b)
        },
        Fo = function(a, b) {
            return fn(a, 7, b)
        };
    wo.V = "wireless.mdl.UserAgentClientHints";
    wo.prototype.O = to([0, fo, -4, go, vo, eo, ko, fo, go, vo, eo]);
    var Go = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Ho(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function Io(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function Jo(a) {
        if (!Io(a)) return null;
        var b = Ho(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Go).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Ko(a) {
        var b;
        return Do(Co(Ao(xo(Eo(zo(Fo(Bo(yo(new wo, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new $m;
            d = hn(d, 1, c.brand);
            return hn(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function Lo(a) {
        var b, c;
        return (c = (b = Jo(a)) == null ? void 0 : b.then(function(d) {
            return Ko(d)
        })) != null ? c : null
    };
    var Mo = function(a, b, c, d) {
        a = a === void 0 ? window : a;
        b = b === void 0 ? null : b;
        c = c === void 0 ? new Va : c;
        d = d === void 0 ? Jf("current") : d;
        ce.call(this);
        var e = this;
        this.global = a;
        this.Da = b;
        this.I = c;
        this.Le = d;
        this.ig = Id(function() {
            return Md(e.global, "pagehide")
        }).g(sg(this.I, 941));
        this.hg = Id(function() {
            return Md(e.global, "load")
        }).g(sg(this.I, 738), Ve(1));
        this.ji = Id(function() {
            return Md(e.global, "resize")
        }).g(sg(this.I, 741));
        this.onMessage = Id(function() {
            return Md(e.global, "message")
        }).g(sg(this.I, 740));
        this.document = new qi(this.global,
            this);
        this.m = new ug(new zg(this.N, this.I), new yg(this.N, this.I));
        this.J = new qe(new Dg(this), new Ih(this), new sf(this, new Hg(this)), new sf(this, new Lh(this)), new sf(this, new Gh(this)))
    };
    q(Mo, ce);
    var No = function(a) {
            try {
                return !!a.global.sharedStorage
            } catch (b) {
                return b
            }
        },
        Eg = function(a) {
            var b = a.global;
            return !!a.global.HTMLFencedFrameElement && !!b.fence && typeof b.fence.reportEvent === "function"
        };
    Mo.prototype.Pb = function(a) {
        Eg(this) && this.global.fence.reportEvent(a)
    };
    Mo.prototype.ee = function() {
        return this.ig.g(sg(this.I, 942), V(this.i, 1), N(function() {}))
    };
    var Oo = function(a) {
            var b = new Mo(a.global.top, a.Da);
            b.J = a.J;
            return b
        },
        Po = function(a, b) {
            b.start();
            return Md(b, "message").g(sg(a.I, 740))
        };
    Mo.prototype.postMessage = function(a, b, c) {
        c = c === void 0 ? [] : c;
        this.global.postMessage(a, b, c)
    };
    Mo.prototype.Mf = function() {
        return Kg(this.global) ? this.global.width : 0
    };
    Mo.prototype.Jf = function() {
        return Kg(this.global) ? this.global.height : 0
    };
    var Qo = function(a, b) {
        try {
            var c = Ai(b, a.global);
            return {
                left: c.left,
                top: c.top,
                width: c.Mf(),
                height: c.Jf()
            }
        } catch (d) {
            return wi
        }
    };
    Mo.prototype.validate = function() {
        var a = this.J.M() || Eg(this);
        return this.global && this.m.ha() && a
    };
    var Yh = function(a) {
        return (a = Lo(a.global)) ? Sc(a) : null
    };
    ea.Object.defineProperties(Mo.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.sharedStorage
                } catch (a) {}
            }
        },
        localStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.localStorage
                } catch (a) {}
            }
        },
        N: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        lc: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !Kg(this.global.top)
            }
        },
        ke: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.lc || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.N.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.N.ResizeObserver
            }
        },
        Yg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });
    var Ro = !dh && !Wg();

    function So(a, b) {
        if (/-[a-z]/.test(b)) return null;
        if (Ro && a.dataset) {
            if (Yg() && !(b in a.dataset)) return null;
            a = a.dataset[b];
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + String(b).replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var To = {},
        Uo = (To["data-google-av-cxn"] = "_avicxn_", To["data-google-av-cpmav"] = "_cvu_", To["data-google-av-metadata"] = "_avm_", To["data-google-av-adk"] = "_adk_", To["data-google-av-btr"] = void 0, To["data-google-av-override"] = void 0, To["data-google-av-dm"] = void 0, To["data-google-av-immediate"] = void 0, To["data-google-av-aid"] = void 0, To["data-google-av-naid"] = void 0, To["data-google-av-inapp"] = void 0, To["data-google-av-slift"] = void 0, To["data-google-av-itpl"] = void 0, To["data-google-av-ext-cxn"] = void 0, To["data-google-av-rs"] =
            void 0, To["data-google-av-flags"] = void 0, To["data-google-av-turtlex"] = void 0, To["data-google-av-ufs-integrator-metadata"] = void 0, To["data-google-av-vattr"] = void 0, To["data-google-av-vrus"] = void 0, To),
        Vo = {},
        Wo = (Vo["data-google-av-adk"] = "googleAvAdk", Vo["data-google-av-btr"] = "googleAvBtr", Vo["data-google-av-cpmav"] = "googleAvCpmav", Vo["data-google-av-dm"] = "googleAvDm", Vo["data-google-av-ext-cxn"] = "googleAvExtCxn", Vo["data-google-av-immediate"] = "googleAvImmediate", Vo["data-google-av-inapp"] = "googleAvInapp",
            Vo["data-google-av-itpl"] = "googleAvItpl", Vo["data-google-av-metadata"] = "googleAvMetadata", Vo["data-google-av-naid"] = "googleAvNaid", Vo["data-google-av-override"] = "googleAvOverride", Vo["data-google-av-rs"] = "googleAvRs", Vo["data-google-av-slift"] = "googleAvSlift", Vo["data-google-av-cxn"] = "googleAvCxn", Vo["data-google-av-aid"] = void 0, Vo["data-google-av-flags"] = "googleAvFlags", Vo["data-google-av-turtlex"] = "googleAvTurtlex", Vo["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", Vo["data-google-av-vattr"] =
            "googleAvVattr", Vo["data-google-av-vrus"] = "googleAvVurs", Vo);

    function Xo(a, b) {
        if (a.l === void 0) return null;
        try {
            var c;
            var d = (c = a.l.getAttribute(b)) != null ? c : null;
            if (d !== null) return d
        } catch (g) {}
        try {
            var e = Uo[b];
            if (e && (d = a.l[e], d !== void 0)) return d
        } catch (g) {}
        try {
            var f = Wo[b];
            if (f) return So(a.l, f)
        } catch (g) {}
        return null
    }

    function Yo(a) {
        return N(function(b) {
            return Xo(b, a)
        })
    };
    var Zo = J(function(a) {
        return N(function(b) {
            return a.map(function(c) {
                return Xo(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), N(function(a) {
        var b = y(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (b !== null) return [];
            throw new me;
        }
        return a.split("|")
    }));
    var $o = function() {
        return J(Fd(function(a) {
            return a.element.g(Zo, Oe(function() {
                return M([""])
            })).g(N(function(b) {
                return {
                    oa: b,
                    Xc: a
                }
            }))
        }), Xe(function(a) {
            return a.oa.sort().join(";")
        }), N(function(a) {
            return a.Xc
        }))
    };

    function ap() {
        return Fd(function(a) {
            return Sc(bp(a)).g(Mh(a.i))
        })
    }

    function bp(a) {
        return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
            return new $h(b)
        })
    };

    function cp(a) {
        var b = a.hg,
            c = a.document.ii;
        return Td(M({}), c, b).g(N(function() {
            return a
        }))
    };
    var ep = N(dp);

    function dp(a) {
        var b = Number(Xo(a, "data-google-av-rs"));
        if (!isNaN(b) && b !== 0) return b;
        var c;
        return (a = (c = a.l) == null ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function fp() {
        return J(O(function(a) {
            return a !== void 0
        }), N(function(a) {
            return a
        }))
    };

    function gp() {
        return function(a) {
            var b = [];
            return a.g(O(function(c) {
                if (c.l === void 0 || b.some(function(d) {
                        return d.l === c.l
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function hp(a, b) {
        b = b === void 0 ? Hc : b;
        return Td(cp(a), b).g(ap(), gp(), fp(), V(a.i, 1))
    };

    function ip(a, b) {
        return new K(function(c) {
            var d = !1,
                e = Array(b.length);
            e.fill(void 0);
            var f = new Set,
                g = new Set,
                h = function(u, r) {
                    a.ng ? (e[r] = u, f.add(r), d || (d = !0, Ya(a, function() {
                        d = !1;
                        c.next(Ob(e))
                    }, 1))) : c.error(new ne(r))
                },
                k = function(u, r) {
                    g.add(r);
                    f.add(r);
                    Ya(a, function() {
                        c.error(u)
                    }, 1)
                },
                l = function(u) {
                    g.add(u);
                    Ya(a, function() {
                        g.size === b.length && c.complete()
                    }, 1)
                },
                m = b.map(function(u, r) {
                    return u.subscribe(function(t) {
                        return void h(t, r)
                    }, function(t) {
                        return void k(t, r)
                    }, function() {
                        return void l(r)
                    })
                });
            return function() {
                m.forEach(function(u) {
                    return void u.unsubscribe()
                })
            }
        })
    };

    function jp(a, b, c) {
        function d() {
            if (b.Da) {
                var x = b.Da,
                    A = x.next;
                var P = {
                    creativeId: b.fc.getName(c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: h,
                    erroredSignalKey: k
                };
                P = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: we(b.m.now(), new ue(0, b.m.timeline)),
                    instanceId: b.fc.getName(b.tb),
                    creativeState: P
                };
                A.call(x, P)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, h = null, k = null, l = {}, m = new Set, u = [], r = [], t = y(e), w = t.next(), v = {}; !w.done; v = {
                ma: void 0
            }, w = t.next()) v.ma = w.value, w = a[v.ma],
            w instanceof W ? (l[v.ma] = w.value, m.add(v.ma), b.Da && (f[String(v.ma)] = ye(w.value))) : (w = w.g(Q(function(x, A) {
                    return re(x) || re(A) ? !1 : x === A
                }), N(function(x) {
                    return function(A) {
                        b.Da && (f[String(x.ma)] = ye(A), d());
                        var P = {};
                        return P[x.ma] = A, P
                    }
                }(v)), Oe(function(x) {
                    return function(A) {
                        if (A instanceof ne) throw new pe(String(x.ma));
                        throw A;
                    }
                }(v)), lf(function(x) {
                    return function() {
                        m.add(x.ma)
                    }
                }(v), function(x) {
                    return function(A) {
                        k = String(x.ma);
                        h = String(A);
                        d()
                    }
                }(v), function(x) {
                    return function() {
                        m.has(x.ma) || (g = !0, d())
                    }
                }(v))),
                r.push(v.ma), u.push(w));
        (a = Object.keys(f).length > 0) && d();
        t = ip(b.i, u).g(Oe(function(x) {
            if (x instanceof ne) throw new oe(String(r[x.Hh]));
            throw x;
        }), N(function(x) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(z(x))))
        }));
        return (u = u.length > 0) && a ? Td(M(Object.freeze(l)), t) : u ? t : M(Object.freeze(l))
    };

    function kp(a, b, c, d) {
        var e = lp(mp(np(), op), pp, qp);
        return a.I.Ub.bind(a.I)(733, function() {
            var f = {};
            try {
                return b.g(Oe(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Hc
                }), Fd(function(g) {
                    try {
                        var h = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), Hc
                    }
                    var k = {};
                    return jp(h, a, g.tb).g(lf(function(l) {
                        k = l
                    }), ff(1), md()).g(e, Oe(function(l) {
                        d(Object.assign({}, k, {
                            error: l
                        }));
                        return Hc
                    }), af(void 0), N(function() {
                        return !0
                    }))
                })).g(hf(function(g) {
                    return g + 1
                }, 0), Oe(function(g) {
                    d(Object.assign({},
                        f, {
                            error: g
                        }));
                    return Hc
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), Hc
            }
        })()
    };

    function rp(a, b) {
        return J(T(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new K(function(g) {
                e(d, f, function(h) {
                    g.next(Object.assign({}, c, {
                        ab: h
                    }));
                    g.complete()
                });
                return function() {}
            }) : Ud
        }), O(function(c) {
            return c.ab
        }))
    };
    var pp = J(O(function(a) {
        var b = a.J;
        var c = a.ac;
        var d = a.Vb;
        var e = a.Pb;
        var f = a.lb;
        var g = a.Oa;
        a = a.Zb;
        return g !== void 0 && a !== void 0 && b !== void 0 && c !== void 0 && d !== void 0 && (!f || e !== void 0)
    }), kf(function(a) {
        return !(a.Vf === !1 && a.wf !== void 0)
    }, !1), O(function(a) {
        var b = a.Vf;
        var c = a.gd;
        var d = a.Vi;
        a = a.ac;
        return d ? !!c && a !== void 0 && (a == null ? void 0 : a.length) > 0 : !!b
    }), rp(function(a) {
        return a.Zb
    }, function(a) {
        return a.Oa
    }), N(function(a) {
        a.lb || a.Vb(a.ac, a).forEach(function(b) {
            a.J.K(b).sendNow()
        })
    }), Ve(1), Te());

    function sp(a) {
        var b = new Map;
        if (typeof a !== "object" || a === null) return b;
        Object.values(a).forEach(function(c) {
            c && typeof c.ka === "function" && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function tp(a, b, c) {
        var d = up,
            e = vp;
        c = c === void 0 ? .01 : c;
        return function(f) {
            c > 0 && Math.random() <= c && (a.global.HTMLFencedFrameElement && a.global.fence && typeof a.global.fence.reportEvent === "function" && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                xf: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                nh: f.error instanceof Error && f.error.name ?
                    String(f.error.name) : null,
                kh: String(a.I.Ag),
                mh: f.escapedQueryId
            }), d(Object.assign({}, f, {
                X: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (h) {
                            return {}
                        }
                    }
                }(),
                oa: [b]
            }), sp(f)).forEach(function(g) {
                a.J.K(g).sendNow()
            }))
        }
    };
    var qp = J(N(function(a) {
        var b = a.J;
        var c = a.th;
        if (b === void 0 || c === void 0) return !1;
        if (a.wf !== void 0) return !0;
        if (c === null) return !1;
        for (a = 0; a < c; a++) b.K("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(Math.random() * 1E7)).sendNow();
        return !0
    }), kf(function(a) {
        return !a
    }), Te());
    var wp = J(O(function(a) {
        return !!a.gd
    }), O(function(a) {
        var b = a.shouldSendExplicitDisplayMeasurablePing;
        a = a.jb;
        var c, d;
        return (d = b && ((c = a == null ? void 0 : a.length) != null ? c : 0) > 0) != null ? d : !1
    }), O(function(a) {
        return a.X !== void 0 && a.jb !== void 0 && a.wb !== void 0 && a.Gb !== void 0 && a.J !== void 0
    }), N(function(a) {
        return Object.assign({}, a, {
            wd: sp(a)
        })
    }), N(function(a) {
        a.wb(Object.assign({}, a, {
            oa: a.jb,
            X: a.X,
            Ac: a.Gb,
            Mc: 3,
            Cc: "m"
        }), a.wd).forEach(function(b) {
            a.J.K(b).sendNow()
        });
        return !0
    }), kf(function(a) {
        return !a
    }), Te());
    var vp = function(a) {
        return {
            id: a.Ac,
            mcvt: a.uc,
            p: a.Yc,
            asp: a.Aj,
            tm: a.xd,
            tu: a.yd,
            mtos: a.vc,
            tos: a.Jc,
            v: a.Xg,
            bin: a.Ld,
            avms: a.fg,
            bs: a.lf,
            mc: a.dg,
            "if": a.gh,
            vu: a.ih,
            app: a.kb,
            mse: a.ye,
            mtop: a.ze,
            itpl: a.me,
            adk: a.Kd,
            exk: a.Cj,
            rs: a.Sa,
            la: a.Zf,
            cr: a.re,
            uach: a.Kc,
            vs: a.Mc,
            r: a.Cc,
            pay: a.Bh,
            co: a.Zg,
            rst: a.Rg,
            rpt: a.Qg,
            isd: a.Fh,
            lsd: a.Uh,
            context: a.kh,
            msg: a.errorMessage,
            stack: a.xf,
            name: a.nh,
            ec: a.Ch,
            sfr: a.Me,
            met: a.cc,
            wmsd: a.Ue,
            pv: a.ak,
            epv: a.Ej,
            pbe: a.Tf,
            fle: a.Dh,
            vae: a.Eh,
            spb: a.xg,
            sfl: a.wg,
            ffslot: a.Oh,
            reach: a.Ii,
            io2: a.Bd,
            rxdbg: a.fk,
            omida: a.Oj,
            omidp: a.Vj,
            omidpv: a.Wj,
            omidor: a.Uj,
            omidv: a.Yj,
            omids: a.Xj,
            omidam: a.Nj,
            omidct: a.Pj,
            omidia: a.Sj,
            omiddc: a.Qj,
            omidlat: a.Tj,
            omiddit: a.Rj,
            qid: a.mh
        }
    };

    function lp() {
        var a = B.apply(0, arguments);
        return function(b) {
            var c = b.g(ff(1), md());
            b = a.map(function(d) {
                return c.g(d, af(!0))
            });
            return Ad(b).g(Ve(1), Te())
        }
    };

    function mp() {
        var a = B.apply(0, arguments);
        return function(b) {
            var c = b.g(ff(1), md());
            b = a.map(function(d) {
                return c.g(d, af(!0))
            });
            return Td.apply(null, z(b)).g(Ve(1), Te())
        }
    };

    function np() {
        var a = lp(wp, xp),
            b = yp;
        return function(c) {
            var d = c.g(ff(1), md());
            c = d.g(a, af(!0));
            d = d.g(J(b, ff(), md()), af(!0));
            c = Ad([c, d]);
            return Yd(c, d).g(Ve(1), Te())
        }
    };
    var yp = function(a) {
        var b = [];
        return a.g(N(function(c) {
            var d = c.J,
                e = c.uh,
                f = c.Jc,
                g = c.Oi,
                h = c.X,
                k = c.Ni,
                l = c.yg,
                m = c.wb,
                u = c.Se,
                r = c.gd,
                t = c.Tf,
                w = c.xg,
                v = c.wg,
                x = c.Qe;
            if (!c.Ff || !r || c.vc === void 0 || f === void 0 || g === void 0 || h === void 0 || k === void 0 || m === void 0 || d === void 0) return !1;
            if (c.lb) {
                if (l === void 0) return !1;
                g = c.Pb;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: x != null ? x : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!(t || v || l)) return !1;
            x = sp(c);
            var A;
            u = (A = u == null ? void 0 : u.sa(x).value) != null ? A : !1;
            A = m(Object.assign({},
                c, {
                    Ac: k,
                    Mc: u ? 4 : 3,
                    Cc: l != null ? l : "u",
                    X: h,
                    oa: g
                }), x);
            if (t) {
                for (; b.length > g.length;) c = void 0, (c = b.shift()) == null || c.deactivate();
                A.forEach(function(S, la) {
                    la >= b.length ? b.push(d.K(S)) : b[la].url = S
                });
                return w && e && l !== void 0 ? (A.forEach(function(S) {
                    e.K(S).sendNow()
                }), !0) : l !== void 0
            }
            if (w && e && l !== void 0) return A.forEach(function(S) {
                e.K(S).sendNow()
            }), !0;
            if (v && e) {
                for (; b.length > g.length;) w = void 0, (w = b.shift()) == null || w.deactivate();
                var P = m(Object.assign({}, c, {
                        Ac: k,
                        Mc: u ? 4 : 3,
                        Cc: l != null ? l : "u",
                        X: h,
                        oa: ["https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&lidartos"]
                    }),
                    x)[0];
                A.forEach(function(S, la) {
                    la >= b.length ? b.push(d.K(P, {
                        vf: !0
                    })) : b[la].url = P
                });
                return l !== void 0 ? (A.forEach(function(S) {
                    e.K(S).sendNow()
                }), !0) : l !== void 0
            }
            return l !== void 0 ? (A.forEach(function(S) {
                d.K(S).sendNow()
            }), !0) : !1
        }), kf(function(c) {
            return !c
        }), Te())
    };

    function zp(a) {
        return function(b) {
            return b.g(N(function(c) {
                a.ng || Db("Assertion on queued Observable output failed");
                return c
            }))
        }
    };

    function Ap(a) {
        return function(b) {
            return new K(function(c) {
                var d = !1,
                    e = b.g(zp(a)).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                Ya(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function Bp(a, b) {
        return function(c) {
            return c.g(T(function(d) {
                return new K(function(e) {
                    function f() {
                        h.disconnect();
                        k.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && d.l !== void 0) {
                        var h = new g(function(l) {
                            e.next(l)
                        });
                        h.observe(d.l, b);
                        var k = d.released.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var Cp = {
        yj: 0,
        cj: 1,
        ej: 2,
        dj: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function Dp(a, b) {
        var c = b.g(Bp(a, {
            attributes: !0
        }), V(a.i, 1));
        return Ad([b, c.g(V(a.i, 1), Ap(a.i))]).g(N(function(d) {
            return y(d).next().value
        }), Yo("data-google-av-dm"), N(Ep))
    }

    function Ep(a) {
        return a && a in Cp ? Number(a) : 2
    };

    function Fp(a) {
        if (a.Yh === 3) return null;
        if (a.yg !== void 0) {
            var b = a.fh === !1 ? "n" : null;
            if (b !== null) return b
        }
        return a.cd instanceof ge ? "msf" : a.Rd instanceof he ? "c" : a.dh === !1 ? "pv" : a.cd || a.Rd ? "x" : null
    }
    var op = J(O(function(a) {
        return a.jb !== void 0 && a.X !== void 0 && a.wb !== void 0 && a.Gb !== void 0 && a.J !== void 0
    }), O(function(a) {
        return Fp(a) !== null
    }), rp(function(a) {
        return a.Qc
    }, function(a) {
        return a.Oa
    }), N(function(a) {
        if (a.lb) {
            var b = a.Pb;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: (c = a.Qe) != null ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = Fp(a);
            if (d === "x") {
                var e, f = (e = a.cd) != null ? e : a.Rd;
                f && (b = f.stack, c = f.message)
            }
            a.wb(Object.assign({}, a, {
                oa: a.jb,
                X: a.X,
                Ac: a.Gb,
                Mc: 2,
                Cc: d,
                errorMessage: c,
                xf: b
            }), sp(a)).forEach(function(g) {
                a.J.K(g).sendNow()
            })
        }
    }), Ve(1), Te());
    var Gp = function() {
            this.startTime = Math.floor(Date.now() / 1E3 - 1704067200);
            this.sequenceNumber = 0
        },
        Hp = function(a) {
            var b = a.sequenceNumber.toString(10).padStart(2, "0");
            b = "" + a.startTime + b;
            a.sequenceNumber < 99 && a.sequenceNumber++;
            return b
        };

    function Ip(a, b) {
        return typeof a === "string" ? encodeURIComponent(a) : typeof a === "number" ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return Ip(c, b)
        }).join(",") : a instanceof ue ? a.toString() : a && typeof a.ka === "function" ? Ip(a.sa(b).value, b) : a === !0 ? "1" : a === !1 ? "0" : a === void 0 || a === null ? null : a instanceof Gp ? Hp(a) : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function Jp(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = y(c);
            c = d.next().value;
            d = d.next().value;
            d = Ip(d, b);
            return d === null ? "" : c + "=" + d
        }).filter(function(c) {
            return c !== ""
        });
        return a.length ? a.join("&") : ""
    };
    var Kp = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
        kc = hc(ic(), "google3.javascript.ads.common.url_macros_substitutor", Wb).Vh;

    function Lp(a, b) {
        return a.replace(Kp, function(c, d) {
            try {
                var e = b !== null && d in b ? b[d] : void 0;
                if (e == null) return lc("No value supplied for unsupported macro: " + d), c;
                if (e.toString() == null) return lc("The toString method of value returns null for macro: " + d), c;
                e = e.toString();
                if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",");
                lc("Null value supplied for macro: " + d)
            } catch (f) {
                lc("Failed to set macro: " + d)
            }
            return c
        })
    };

    function Mp(a, b) {
        var c = Object.assign({}, a),
            d = a.Kc;
        c = (delete c.Kc, c);
        c = a.X(c);
        var e = Jp(c, b);
        return Lb(a.oa, function(f) {
            var g = "";
            typeof d === "string" && (g = "&" + Jp({
                uach: d
            }, b));
            var h = {};
            return Lp(f, (h.VIEWABILITY = e, h)) + g
        })
    };

    function up(a, b) {
        var c = a.X(a),
            d = Jp(c, b);
        return d ? Lb(a.oa, function(e) {
            e = e.indexOf("?") >= 0 ? e : e + "?";
            e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
            return e + d
        }) : a.oa
    };

    function Np(a, b) {
        return Lb(a, function(c) {
            if (typeof b.Kc === "string") {
                var d = "&" + Jp({
                    uach: b.Kc
                }, new Map);
                return c.substring(c.length - 7) == "&adurl=" ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var xp = J(O(function(a) {
        return a.X !== void 0 && a.jb !== void 0 && a.wb !== void 0 && a.Gb !== void 0 && a.J !== void 0
    }), N(function(a) {
        return Object.assign({}, a, {
            wd: sp(a)
        })
    }), O(function(a) {
        var b = a.Se;
        var c = a.gd;
        a = a.wd;
        var d;
        return !!c && ((d = b == null ? void 0 : b.sa(a).value) != null ? d : !1)
    }), rp(function(a) {
        return a.Rc
    }, function(a) {
        return a.Oa
    }), N(function(a) {
        var b = a.J,
            c = a.Qe;
        if (a.lb) {
            var d = a.Pb;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: c != null ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.wb(Object.assign({},
            a, {
                oa: a.jb,
                X: a.X,
                Ac: a.Gb,
                Mc: 4,
                Cc: "v"
            }), a.wd);
        (d = a.Td) && d.length > 0 && a.Vb && a.Vb(d, a).forEach(function(e) {
            b.K(e).sendNow()
        });
        (d = a.Te) && d.length > 0 && a.Vb && a.Vb(d, a).forEach(function(e) {
            b.K(e).sendNow()
        });
        c.forEach(function(e) {
            b.K(e, {
                Xb: a.ue
            }).sendNow()
        });
        return !0
    }), kf(function(a) {
        return !a
    }), Te());

    function Op(a, b, c, d) {
        var e = Object.keys(c).map(function(h) {
                return h
            }),
            f = e.filter(function(h) {
                var k = c[h];
                h = d[h];
                return k instanceof W && h instanceof W && k.value === h.value
            }),
            g = f.reduce(function(h, k) {
                var l = {};
                return Object.assign({}, h, (l[k] = c[k], l))
            }, {});
        return e.reduce(function(h, k) {
            if (f.indexOf(k) >= 0) return h;
            var l = {};
            return Object.assign({}, h, (l[k] = b.g(T(function(m) {
                return (m = m ? c[k] : d[k]) && (m instanceof K || I(m.nb) && I(m.subscribe)) ? m : m.T(a)
            })), l))
        }, g)
    };

    function Pp(a) {
        return J(N(function() {
            return !0
        }), R(!1), V(a, 1))
    };

    function Qp(a) {
        return a.length <= 0 ? Hc : Ad(a.map(function(b) {
            var c = 0;
            return b.g(N(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).g(O(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), N(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function Rp(a, b) {
        a.Ca && (a.qb = a.Ca);
        a.Ca = b;
        a.qb && a.qb.value ? (b = Math.max(0, we(b.timestamp, a.qb.timestamp)), a.totalTime += b, a.qa += b) : a.qa = 0;
        return a
    }

    function Sp() {
        return J(hf(Rp, {
            totalTime: 0,
            qa: 0
        }), N(function(a) {
            return a.totalTime
        }))
    }

    function Tp() {
        return J(hf(Rp, {
            totalTime: 0,
            qa: 0
        }), N(function(a) {
            return a.qa
        }))
    };

    function Up(a, b) {
        return J(Yo("data-google-av-metadata"), N(function(c) {
            if (c === null) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            if (c.length === 0) return b(void 0);
            c = c[0].slice(1).join("=");
            return b(c)
        }))
    };
    var Vp = {
        Yi: "asmreq",
        Zi: "asmres"
    };
    var Wp = function(a) {
        ro.call(this, a)
    };
    q(Wp, ro);
    Wp.prototype.qg = function(a) {
        gn(this, 1, a)
    };
    Wp.V = "tagging.common.osd.AdSpeedMetricsRequest";
    Wp.prototype.O = to([0, io]);
    var Xp = function(a) {
        ro.call(this, a)
    };
    q(Xp, ro);
    Xp.V = "tagging.common.osd.AdSpeedMetricsResponse.Box";
    var Yp = [0, ao, -3];
    Xp.prototype.O = to(Yp);
    var Zp = function(a) {
        ro.call(this, a)
    };
    q(Zp, ro);
    Zp.prototype.qg = function(a) {
        gn(this, 1, a)
    };
    var $p = uo(Zp);
    Zp.V = "tagging.common.osd.AdSpeedMetricsResponse";
    Zp.prototype.O = to([0, io, eo, Yp, ao, -1]);

    function aq(a, b) {
        var c = c === void 0 ? Oo(a) : c;
        var d = new MessageChannel;
        b = b.g(N(function(f) {
            return Number(f)
        }), O(function(f) {
            return !isNaN(f) && f !== 0
        }), lf(function(f) {
            var g = new Wp;
            g.qg(f);
            f = {
                type: "asmreq",
                payload: g.Ta()
            };
            c.postMessage(f, "*", [d.port2])
        }), Ve(1));
        var e = Po(a, d.port1).g(O(function(f) {
                return typeof f.data === "object"
            }), N(function(f) {
                var g = f.data,
                    h = Object.values(Vp).includes(g.type);
                g = typeof g.payload === "string";
                if (!h || !g || f.data.type !== "asmres") return null;
                try {
                    return $p(f.data.payload)
                } catch (k) {
                    return null
                }
            }),
            O(function(f) {
                return f !== null
            }), N(function(f) {
                return f
            }));
        return b.g(T(function(f) {
            return M(f).g(Re(e))
        }), O(function(f) {
            var g = y(f);
            f = g.next().value;
            g = g.next().value;
            if (pl(Im(g, 1)) != null) {
                var h = h === void 0 ? 0 : h;
                var k;
                g = ((k = pl(Im(g, 1))) != null ? k : h) === f
            } else g = !1;
            return g
        }), N(function(f) {
            f = y(f);
            f.next();
            return f.next().value
        }), Mh(a.i))
    };

    function bq(a, b, c) {
        var d = b.rc.g(Ve(1), T(function() {
            return aq(a, c)
        }), O(function(f) {
            return cn(f, 2) && Mm(f, Xp, 3) && nl(Im(f, 4)) != null && nl(Im(f, 5)) != null
        }), Ve(1), Mh(a.i));
        b = d.g(N(function(f) {
            var g = Zm(f, Xp, 3);
            g = dn(g, 2);
            f = Zm(f, Xp, 3);
            f = dn(f, 1);
            return {
                x: g,
                y: f
            }
        }), Q(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), V(a.i, 1));
        var e = d.g(N(function(f) {
            return dn(f, 4)
        }), V(a.i, 1));
        d = d.g(N(function(f) {
            return dn(f, 5)
        }), V(a.i, 1));
        return {
            Fh: e,
            Tg: b,
            Uh: d
        }
    };

    function cq(a, b) {
        return b.rc.g(Ve(1), N(function() {
            return a.m.now().round()
        }))
    };
    var dq = N(function(a) {
        return [a.value.Y.width, a.value.Y.height]
    });

    function eq(a, b) {
        return function(c) {
            return Qp(b.map(function(d) {
                return c.g(a(d))
            }))
        }
    };

    function fq() {
        var a;
        return J(lf(function(b) {
            return void(a = b.timestamp)
        }), Tp(), N(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };
    var gq = function(a, b) {
            this.nf = a;
            this.options = b;
            this.pe = this.ne = null
        },
        hq = function(a, b) {
            b ? a.pe || (b = Object.assign({}, a.options, {
                delay: 100,
                trackVisibility: !0
            }), a.pe = new IntersectionObserver(a.nf, b)) : a.ne || (a.ne = new IntersectionObserver(a.nf, a.options))
        },
        iq = function(a, b) {
            a = b ? a.pe : a.ne;
            if (!a) throw new je;
            return a
        };
    gq.prototype.observe = function(a, b) {
        iq(this, a).observe(b)
    };
    gq.prototype.unobserve = function(a, b) {
        iq(this, a).unobserve(b)
    };
    gq.prototype.disconnect = function(a) {
        iq(this, a).disconnect()
    };
    gq.prototype.takeRecords = function(a) {
        return iq(this, a).takeRecords()
    };
    var jq = {
        fa: "ns",
        ja: wi,
        Y: wi,
        da: new L,
        U: "ns",
        L: wi,
        W: wi,
        pa: {
            x: 0,
            y: 0
        }
    };

    function kq(a, b) {
        return xi(a.Y, b.Y) && xi(a.L, b.L) && xi(a.ja, b.ja) && xi(a.W, b.W) && a.U === b.U && a.da === b.da && a.fa === b.fa && a.pa.x === b.pa.x && a.pa.y === b.pa.y
    };

    function lq(a, b) {
        return function(c) {
            return function(d) {
                var e = d.g(ef(new L), md());
                d = c.element.g(Q());
                e = e.g(N(function(f) {
                    return f.value
                }));
                return Ad([d, e, b]).g(N(function(f) {
                    var g = y(f);
                    f = g.next().value;
                    var h = g.next().value;
                    g = g.next().value;
                    if (f.l === void 0) var k = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        k = f.l.getBoundingClientRect();
                        var l = f.l,
                            m = a.global,
                            u = new vh(0, 0);
                        var r = (r = yh(l)) ? r.defaultView : window;
                        if (Jg(r, "parent")) {
                            do {
                                if (r == m) {
                                    var t = l,
                                        w = yh(t);
                                    Hb(t, "Parameter is required");
                                    var v = new vh(0, 0);
                                    var x =
                                        (w ? yh(w) : document).documentElement;
                                    t != x && (t = Eh(t), w = zh(w), w = Ah(w.hc), v.x = t.left + w.x, v.y = t.top + w.y)
                                } else v = D(l), v = Eh(v), v = new vh(v.left, v.top);
                                u.x += v.x;
                                u.y += v.y
                            } while (r && r != m && r != r.parent && (l = r.frameElement) && (r = r.parent))
                        }
                        k = {
                            top: u.y,
                            left: u.x,
                            width: k.width,
                            height: k.height
                        }
                    }
                    k = zi(k, h.pa);
                    m = yi(k, h.ja);
                    u = a.m.now();
                    r = Object;
                    l = r.assign;
                    if (g !== 2 || a.lc || m.width <= 0 || m.height <= 0) var A = !1;
                    else try {
                        var P = a.document.elementFromPoint(m.left + m.width / 2, m.top + m.height / 2);
                        A = P ? !mq(P, f) : !1
                    } catch (S) {
                        A = !1
                    }
                    return {
                        timestamp: u,
                        value: l.call(r, {}, h, {
                            U: "geo",
                            W: A ? jq.W : m,
                            L: k
                        })
                    }
                }), Mh(a.i))
            }
        }
    }

    function mq(a, b, c) {
        c = c === void 0 ? 0 : c;
        return a.l === void 0 || b.l === void 0 ? !1 : a.l === b.l || Ch(b.l, function(d) {
            return d === a.l
        }) ? !0 : b.l.ownerDocument && b.l.ownerDocument.defaultView && b.l.ownerDocument.defaultView === b.l.ownerDocument.defaultView.top ? !1 : c < 10 && b.l.ownerDocument && b.l.ownerDocument.defaultView && b.l.ownerDocument.defaultView.frameElement ? mq(a, new $h(b.l.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function nq(a) {
        return function(b) {
            return b.g(a.ResizeObserver ? oq(a) : pq(a), ff(1), md())
        }
    }

    function oq(a) {
        return function(b) {
            return b.g(T(function(c) {
                var d = a.ResizeObserver;
                if (!d || c.l === void 0) return M(jq.L);
                var e = (new K(function(f) {
                    function g() {
                        c.l !== void 0 && h.unobserve(c.l);
                        h.disconnect();
                        k.unsubscribe()
                    }
                    if (c.l === void 0) return f.complete(),
                        function() {};
                    var h = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    h.observe(c.l);
                    var k = c.released.subscribe(g);
                    return g
                })).g(sg(a.I, 736), N(function(f) {
                    return f.contentRect
                }));
                return Td(M(c.l.getBoundingClientRect()), e)
            }), Q(xi))
        }
    }

    function pq(a) {
        return function(b) {
            var c = b.g(Bp(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.ji;
            c = Td(b.g(N(function() {
                return Zh("resize")
            })), c, d);
            return Ad(b, c).g(sg(a.I, 737), N(function(e) {
                e = y(e).next().value;
                return e.l === void 0 ? void 0 : e.l.getBoundingClientRect()
            }), fp(), Q(xi))
        }
    };

    function qq(a, b) {
        var c = rq(a, b).g(ff(1), md());
        return function(d) {
            return function(e) {
                e = e.g(T(function(f) {
                    return f.element
                }), Q());
                return Ad([c, e]).g(T(function(f) {
                    var g = y(f);
                    f = g.next().value;
                    g = g.next().value;
                    return sq(a, f.Mh, nq(a), f.hi, d, f.wh, g)
                }), Mh(a.i))
            }
        }
    }

    function tq(a, b, c) {
        var d = qq(a, c)(b);
        return function(e) {
            var f = d(M(e));
            return function(g) {
                return Ad([g, f]).g(N(function(h) {
                    var k = y(h);
                    h = k.next().value;
                    k = k.next().value;
                    var l = zi(k.value.L, h.value.pa),
                        m = yi(zi(k.value.W, h.value.pa), h.value.ja);
                    return {
                        timestamp: h.timestamp.maximum(k.timestamp),
                        value: Object.assign({}, h.value, {
                            U: "nio",
                            W: m,
                            L: l
                        })
                    }
                }))
            }
        }
    }

    function uq(a) {
        return N(function(b) {
            return b.value.fa !== "nio" ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    ja: Qo(a, !0),
                    Y: Qo(a, !0)
                })
            })
        })
    }

    function vq(a, b) {
        return M(b).g(a, N(function() {
            return b
        }))
    }

    function rq(a, b) {
        return a.m.timeline !== se ? cd(new ge(2)) : a.MutationObserver ? typeof IntersectionObserver === "undefined" ? cd(new ge(0)) : (new K(function(c) {
            var d = new L,
                e = new gq(d.next.bind(d), {
                    threshold: [].concat(z(b))
                });
            c.next({
                hi: d.g(sg(a.I, 735)),
                Mh: e,
                wh: function(f) {
                    f = e.takeRecords(f);
                    f.length > 0 && d.next(f)
                }
            })
        })).g(Ve(1), ff(1), md()) : cd(new ge(1))
    }

    function wq(a) {
        return Rc(a.sort(function(b, c) {
            return b.time - c.time
        }), rd)
    }

    function sq(a, b, c, d, e, f, g) {
        return new K(function(h) {
            function k() {
                w || (w = !0, g.l !== void 0 && b.unobserve(e, g.l), m.unsubscribe(), t.unsubscribe(), r.unsubscribe(), v.unsubscribe())
            }
            if (g.l !== void 0) {
                hq(b, e);
                b.observe(e, g.l);
                var l = new Gc({
                        timestamp: a.m.now(),
                        value: Object.assign({}, jq, {
                            fa: "nio",
                            U: "nio"
                        })
                    }),
                    m = d.g(Fd(function(x) {
                        return wq(x)
                    }), O(function(x) {
                        return x.target === g.l
                    }), N(function(x) {
                        return {
                            timestamp: new ue(x.time, se),
                            value: {
                                fa: "nio",
                                ja: x.rootBounds || wi,
                                Y: x.rootBounds || Qo(a, !0),
                                da: u,
                                U: "nio",
                                W: x.intersectionRect,
                                L: x.boundingClientRect,
                                pa: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: x.isIntersecting,
                                cg: x.isVisible
                            }
                        }
                    }), ef(l), md()).subscribe(h),
                    u = new L,
                    r = u.subscribe(function() {
                        f(e);
                        h.next({
                            timestamp: a.m.now(),
                            value: l.value.value
                        });
                        g.l !== void 0 && (b.unobserve(e, g.l), b.observe(e, g.l))
                    }),
                    t = vq(c, g).subscribe(function() {
                        u.next()
                    }),
                    w = !1,
                    v = g.released.subscribe(function() {
                        return k()
                    });
                return k
            }
        })
    };

    function xq(a, b) {
        var c = a.ee().g(N(function() {
            return "b"
        }));
        return Yd(b, c).g(Ve(1), V(a.i, 1))
    };

    function yq(a) {
        return function(b) {
            var c;
            return b.g(lf(function(d) {
                return void(c = d.timestamp)
            }), N(function(d) {
                return d.value
            }), a, N(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };

    function zq(a) {
        return a.W.width * a.W.height / (a.L.width * a.L.height)
    }
    var Aq = yq(J(N(function(a) {
            var b;
            return (b = a.bd) != null ? b : zq(a)
        }), N(function(a) {
            return isFinite(a) ? a : 0
        }))),
        Bq = yq(J(N(function(a) {
            var b;
            return (b = a.bd) != null ? b : zq(a)
        }), N(function(a) {
            return isFinite(a) ? a : -1
        })));
    var Cq = function(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    };
    Cq.prototype.Z = function(a) {
        return a instanceof Cq ? this.a.Z(a.a) && this.b.Z(a.b) : !1
    };
    Cq.prototype.ra = function(a) {
        var b = this.a.ra(a).value,
            c = this.b.ra(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    ea.Object.defineProperties(Cq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        F: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.F.timestamp.maximum(this.b.F.timestamp),
                    b = this.a.F.timestamp.equals(a) ? this.a.F.value : this.a.ra(a).value,
                    c = this.b.F.timestamp.equals(a) ? this.b.F.value : this.b.ra(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });
    var Dq = function(a, b) {
        this.input = a;
        this.od = b;
        this.F = {
            timestamp: this.input.F.timestamp,
            value: this.od(this.input.F.value)
        }
    };
    Dq.prototype.Z = function(a) {
        return a instanceof Dq ? this.input.Z(a.input) && this.od === a.od : !1
    };
    Dq.prototype.ra = function(a) {
        a = this.input.ra(a);
        return {
            timestamp: a.timestamp,
            value: this.od(a.value)
        }
    };
    ea.Object.defineProperties(Dq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function Eq(a, b, c) {
        c = c === void 0 ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };
    var Fq = function(a, b, c) {
        this.clock = a;
        this.F = b;
        this.active = c
    };
    Fq.prototype.Z = function(a) {
        return a instanceof Fq ? this.active === a.active && this.clock.timeline === a.clock.timeline && Eq(this.F, a.F) : !1
    };
    Fq.prototype.ra = function(a) {
        return {
            timestamp: a,
            value: this.F.value + (this.active ? Math.max(0, we(a, this.F.timestamp)) : 0)
        }
    };
    var Gq = function() {};
    Gq.prototype.ka = function() {
        return this.ra(this.clock.now())
    };
    Gq.prototype.sa = function(a) {
        var b = this.clock.timeline,
            c, d = (c = a.get(b)) != null ? c : this.clock.now();
        a.set(b, d);
        return this.ra(d)
    };
    Gq.prototype.map = function(a) {
        return new Hq(this, a)
    };
    Gq.prototype.ta = function(a) {
        return new Iq(this, a)
    };
    var Iq = function() {
        Cq.apply(this, arguments);
        this.map = Gq.prototype.map;
        this.ta = Gq.prototype.ta;
        this.ka = Gq.prototype.ka;
        this.sa = Gq.prototype.sa
    };
    q(Iq, Cq);
    var Jq = function() {
        Fq.apply(this, arguments);
        this.map = Gq.prototype.map;
        this.ta = Gq.prototype.ta;
        this.ka = Gq.prototype.ka;
        this.sa = Gq.prototype.sa
    };
    q(Jq, Fq);
    var Hq = function() {
        Dq.apply(this, arguments);
        this.map = Gq.prototype.map;
        this.ta = Gq.prototype.ta;
        this.ka = Gq.prototype.ka;
        this.sa = Gq.prototype.sa
    };
    q(Hq, Dq);

    function Kq(a, b) {
        a.Ca && (a.qb = a.Ca);
        a.Ca = b;
        a.qb && a.qb.value ? (b = Math.max(0, we(b.timestamp, a.qb.timestamp)), a.totalTime += b, a.qa += b) : a.qa = 0;
        return a
    }

    function Lq(a) {
        return J(hf(Kq, {
            totalTime: 0,
            qa: 0
        }), N(function(b) {
            return new Jq(a, {
                timestamp: b.Ca.timestamp,
                value: b.totalTime
            }, b.Ca.value)
        }))
    }

    function Mq(a) {
        return J(hf(Kq, {
            totalTime: 0,
            qa: 0
        }), N(function(b) {
            return new Jq(a, {
                timestamp: b.Ca.timestamp,
                value: b.qa
            }, b.Ca.value)
        }))
    };

    function Nq(a) {
        return J(Mq(a), N(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };
    var Oq = function(a, b) {
        this.F = b;
        this.ka = Gq.prototype.ka;
        this.sa = Gq.prototype.sa;
        this.map = Gq.prototype.map;
        this.ta = Gq.prototype.ta;
        this.clock = a
    };
    Oq.prototype.Z = function(a) {
        return a.active
    };
    Oq.prototype.ra = function() {
        return this.F
    };
    ea.Object.defineProperties(Oq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function Pq(a, b) {
        return b.g(N(function(c) {
            return new Oq(a.m, {
                timestamp: a.m.now(),
                value: c
            })
        }))
    };

    function Qq(a, b) {
        return a >= 1 ? !0 : a <= 0 ? !1 : a >= b
    };

    function Rq(a) {
        return function(b) {
            return b.g(mf(a), N(function(c) {
                var d = y(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: Qq(c.value, d)
                }
            }))
        }
    };
    var Sq = N(function(a) {
        if (a.value.fa === "omid") {
            if (a.value.U === "nio") return "omio";
            if (a.value.U === "geo") return "omgeo"
        }
        return a.value.U === "geo" || a.value.U === "nio" ? a.value.fa : a.value.U
    });

    function Tq() {
        return J(O(function(a, b) {
            return b > 0
        }), Uq, R(-1), Q())
    }
    var Uq = J(O(function(a) {
        return !isNaN(a)
    }), hf(function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), Q());
    var Vq = yq(J(N(function(a) {
        return a.W.width * a.W.height / (a.ja.width * a.ja.height)
    }), N(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function Wq(a, b, c) {
        return a ? Ad([b, c]).g(O(function(d) {
            var e = y(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), N(function(d) {
            var e = y(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function Xq(a) {
        return function(b) {
            var c = b.g(Aq),
                d = b.g(Vq);
            return a instanceof K ? a.g(T(function(e) {
                return Wq(e, c, d)
            })) : Wq(a.value, c, d)
        }
    };
    var Yq = J(yq(N(function(a) {
        a = a.bd ? a.L.width * a.L.height * a.bd / (a.Y.width * a.Y.height) : a.W.width * a.W.height / (a.Y.width * a.Y.height);
        return isFinite(a) ? a : 0
    })));

    function Zq(a, b, c, d) {
        var e = d.dd,
            f = d.Zd,
            g = d.Gg,
            h = d.hf,
            k = d.ve,
            l = d.eg,
            m = d.hd;
        d = d.Dg;
        b = $q(a, c, b);
        c = ar(a, c);
        d = br(b, d);
        var u = cr(a, e, l, b),
            r = u.g(N(function(C) {
                return C.value
            }), Q(), V(a, 1), hf(function(C, da) {
                return Math.max(C, da)
            }, 0)),
            t = u.g(N(function(C) {
                return C.value
            }), Tq(), V(a, 1)),
            w = b.g(Bq, N(function(C) {
                return C.value
            }), Ve(2), Q(), V(a, 1));
        g = dr(a, b, g, h);
        var v = g.g(R(!1), Q(), N(function(C) {
            return C ? k : f
        }));
        h = u.g(Rq(v), Q(), V(a, 1));
        var x = Ad([h, b]).g(O(function(C) {
            var da = y(C);
            C = da.next().value;
            da = da.next().value;
            return C.timestamp.equals(da.timestamp)
        }), N(function(C) {
            var da = y(C);
            C = da.next().value;
            da = da.next().value;
            return {
                visible: C.value,
                geometry: da.value.L
            }
        }), hf(function(C, da) {
            return !da.visible && C.visible ? C : da
        }, {
            visible: !1,
            geometry: wi
        }), N(function(C) {
            return C.geometry
        }), R(wi), V(a, 1), Q(xi));
        l = l instanceof K ? l.g(Q(), Ue()) : Ud;
        v = Ad([l, v]).g(Ue());
        var A = b.g(O(function(C) {
                return C.value.fa !== "ns" && C.value.U !== "ns"
            }), hf(function(C) {
                return C + 1
            }, 0), R(0), V(a, 1)),
            P = c.g(Ue(!0), R(!1), V(a, 1));
        P = Ad([m, P]).g(N(function(C) {
            var da =
                y(C);
            C = da.next().value;
            da = da.next().value;
            return C && !da
        }), V(a, 1));
        var S = b.g(Yq, Q()),
            la = S.g(N(function(C) {
                return C.value
            }), hf(function(C, da) {
                return Math.max(C, da)
            }, 0), Q(), V(a, 1)),
            H = S.g(N(function(C) {
                return C.value
            }), Tq(), V(a, 1));
        return {
            Ke: l,
            Hc: v,
            xa: {
                ri: b,
                fg: b.g(Sq),
                Yc: x.g(Q(xi)),
                visible: h.g(Q(Eq)),
                Oe: u.g(Q(Eq)),
                dg: r,
                ci: t,
                lf: b.g(dq, Q(Pb)),
                Qi: S,
                Wh: la,
                bi: H,
                cd: c,
                da: (new W(new L)).T(a),
                Zf: g,
                dd: e,
                hd: m,
                Ff: P,
                Ri: A,
                Th: w,
                Bd: d
            }
        }
    }

    function ar(a, b) {
        return b.g(O(function() {
            return !1
        }), N(function(c) {
            return c
        }), Oe(function(c) {
            return (new W(c)).T(a)
        }))
    }

    function br(a, b) {
        a = Ad([a, b]).g(N(function(e) {
            var f = y(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.cg
        }), Q());
        var c = a.g(N(function(e) {
                return e === void 0 ? !0 : e
            }), hf(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(hf(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), N(function(e) {
                return !!e
            }));
        return Ad([b, $d(a, c, d)]).g(N(function(e) {
            var f = y(e);
            e = f.next().value;
            var g = y(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    }

    function $q(a, b, c) {
        return b.g(Xd(Ud), V(a, 1)).g(Q(function(d, e) {
            return Eq(d, e, kq)
        }), R({
            timestamp: c.now(),
            value: jq
        }), V(a, 1))
    }

    function cr(a, b, c, d) {
        c = d.g(Xq(c), yq(N(function(e) {
            return Math.round(e * 100) / 100
        })), V(a, 1));
        return b instanceof W ? c : Ad([c, b]).g(N(function(e) {
            var f = y(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), Q(Eq), V(a, 10))
    }

    function dr(a, b, c, d) {
        b = [b.g(N(function(e) {
            return e.value.L.width * e.value.L.height >= 242500
        }))];
        c instanceof K && b.push(c.g(N(function(e) {
            return !!e
        })));
        c = Ad(b);
        return d ? c.g(N(function(e) {
            return e.some(function(f) {
                return f
            })
        }), R(!1), Q(), V(a, 1)) : (new W(!1)).T(a)
    };
    var er = function(a) {
            this.m = a;
            this.vd = null;
            this.timeout = new L
        },
        gr = function(a, b) {
            fr(a);
            a.vd = a.m.setTimeout(function() {
                return void a.timeout.next()
            }, b)
        },
        fr = function(a) {
            a.vd !== null && (a.m.clearTimeout(a.vd), a.vd = null)
        };

    function hr(a, b, c, d) {
        var e = ir.zg,
            f = new er(b);
        c = c.g(R(void 0), T(function() {
            fr(f);
            return d
        })).g(N(function(g) {
            fr(f);
            var h = g.F,
                k = g.active;
            h.value >= e || !k || (k = b.now(), k = Math.max(0, we(k, h.timestamp)), gr(f, Math.max(0, e - h.value - k)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return Ad([c, Td(f.timeout, M(void 0))]).g(N(function(g) {
            return y(g).next().value
        }), kf(function(g) {
            return !g.ka().value
        }, !0), V(a, 1))
    };

    function jr(a) {
        var b = new Jq(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return J(Mq(a), hf(function(c, d) {
            return c.F.value > d.F.value ? new Jq(a, c.F, !1) : d
        }, b), N(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function kr(a) {
        return function(b) {
            return J(Rq(M(b)), jr(a))
        }
    };

    function lr(a) {
        return function(b) {
            return J(yq(N(function(c) {
                return Qq(c, b)
            })), Lq(a), N(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function mr(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.ta(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function nr(a, b) {
        return a.ta(b).map(function(c) {
            var d = y(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function or(a, b, c, d, e, f) {
        var g = pr;
        if (g.length > 1)
            for (var h = 0; h < g.length - 1; h++)
                if (g[h] < g[h + 1]) throw Error();
        h = f.g(R(void 0), T(function() {
            return d.g(Nq(a))
        }), Q(function(k, l) {
            return k.Z(l)
        }), V(b, 1));
        f = f.g(R(void 0), T(function() {
            return d.g(jr(a))
        }), Q(function(k, l) {
            return k.Z(l)
        }), V(b, 1));
        return {
            xd: e.g(R(void 0), T(function() {
                return c.g(N(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: !0
                    }
                }), Lq(a))
            }), Q(function(k, l) {
                return k.Z(l)
            }), V(b, 1)),
            yd: e.g(R(void 0), T(function() {
                return c.g(N(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: k.value === 0
                    }
                }), Lq(a))
            }), Q(function(k, l) {
                return k.Z(l)
            }), V(b, 1)),
            vc: e.g(R(void 0), T(function() {
                return c.g(eq(kr(a), g))
            }), N(mr), Q(function(k, l) {
                return k.Z(l)
            }), V(b, 1)),
            Jc: e.g(R(void 0), T(function() {
                return c.g(eq(lr(a), g), N(function(k) {
                    return k.map(function(l, m) {
                        return m > 0 ? nr(l, k[m - 1]) : l
                    })
                }))
            }), N(mr), Q(function(k, l) {
                return k.Z(l)
            }), V(b, 1)),
            uc: f,
            bb: h.g(Q(function(k, l) {
                return k.Z(l)
            }), V(b, 1))
        }
    };

    function qr(a) {
        var b;
        if (b = rr(a)) b = !sr(a, "abgcp") && !sr(a, "abgc") && !(typeof a.id === "string" && a.id === "abgb") && !(typeof a.id === "string" && a.id === "mys-abgc") && !sr(a, "cbb");
        return b
    }

    function sr(a, b) {
        return a.classList ? a.classList.contains(b) : (" " + a.className + " ").indexOf(" " + b + " ") > -1
    }

    function rr(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && b.height >= 30 && b.width >= 30
        } catch (c) {
            return !1
        }
    }

    function tr(a, b) {
        if (a.l === void 0 || !a.l.children) return a;
        for (var c = Ob(a.l.children); c.length;) {
            var d = b ? c.filter(qr) : c.filter(rr);
            if (d.length === 1) return new $h(d[0]);
            if (d.length > 1) break;
            c = Rb(c, function(e) {
                return Ob(e.children)
            })
        }
        return a
    }

    function ur(a, b, c, d, e) {
        if (c) return {
            Xc: b,
            rb: M(null)
        };
        c = b.element.g(N(function(f) {
            a: if (f.l === void 0 || rr(f.l)) f = {
                    pd: f,
                    rb: "mue"
                };
                else {
                    var g = tr(f, e);
                    if (g.l !== void 0 && rr(g.l)) f = {
                        pd: g,
                        rb: "ie"
                    };
                    else {
                        if (d || a.ke)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    pd: new $h(g),
                                    rb: "ce"
                                };
                                break a
                            }
                        f = {
                            pd: f,
                            rb: "mue"
                        }
                    }
                }return f
        }), jf());
        return {
            Xc: {
                tb: b.tb,
                element: c.g(N(function(f) {
                    return f.pd
                }))
            },
            rb: c.g(N(function(f) {
                return f.rb
            }))
        }
    };

    function vr(a, b, c, d) {
        var e = d.dd,
            f = d.Zd,
            g = d.Gg,
            h = d.hf,
            k = d.ve,
            l = d.eg,
            m = d.hd;
        d = d.Dg;
        b = wr(a, c, b);
        c = xr(a, c);
        d = yr(b, d);
        var u = zr(a, e, l, b),
            r = u.g(N(function(H) {
                return H.value
            }), Q(), V(a, 1), hf(function(H, C) {
                return Math.max(H, C)
            }, 0)),
            t = u.g(N(function(H) {
                return H.value
            }), Tq(), V(a, 1)),
            w = b.g(Bq, N(function(H) {
                return H.value
            }), Ve(2), Q(), V(a, 1));
        g = Ar(a, b, g, h);
        var v = g.g(R(!1), Q(), N(function(H) {
            return H ? k : f
        }));
        h = u.g(Rq(v), Q(), V(a, 1));
        var x = Ad([h, b]).g(O(function(H) {
                var C = y(H);
                H = C.next().value;
                C = C.next().value;
                return H.timestamp.equals(C.timestamp)
            }),
            N(function(H) {
                var C = y(H);
                H = C.next().value;
                C = C.next().value;
                return {
                    visible: H.value,
                    geometry: C.value.L
                }
            }), hf(function(H, C) {
                return !C.visible && H.visible ? H : C
            }, {
                visible: !1,
                geometry: wi
            }), N(function(H) {
                return H.geometry
            }), R(wi), V(a, 1), Q(xi));
        l = l instanceof K ? l.g(Q(), Ue()) : Ud;
        v = Ad([l, v]).g(Ue());
        var A = b.g(O(function(H) {
                return H.value.fa !== "ns" && H.value.U !== "ns"
            }), hf(function(H) {
                return H + 1
            }, 0), R(0), V(a, 1)),
            P = c.g(Ue(!0), R(!1), V(a, 1));
        P = Ad([m, P]).g(N(function(H) {
            var C = y(H);
            H = C.next().value;
            C = C.next().value;
            return H &&
                !C
        }), V(a, 1));
        var S = b.g(Yq, Q()),
            la = S.g(N(function(H) {
                return H.value
            }), hf(function(H, C) {
                return Math.max(H, C)
            }, 0), Q(), V(a, 1));
        a = S.g(N(function(H) {
            return H.value
        }), Tq(), V(a, 1));
        return {
            Ke: l,
            Hc: v,
            xa: {
                ri: b,
                fg: b.g(Sq),
                Yc: x.g(Q(xi)),
                visible: h.g(Q(Eq)),
                Oe: u.g(Q(Eq)),
                dg: r,
                ci: t,
                lf: b.g(dq, Q(Pb)),
                Qi: S,
                Wh: la,
                bi: a,
                cd: c,
                da: b.g(N(function(H) {
                    return H.value.da
                })),
                Zf: g,
                dd: e,
                hd: m,
                Ff: P,
                Ri: A,
                Th: w,
                Bd: d
            }
        }
    }

    function xr(a, b) {
        return b.g(O(function() {
            return !1
        }), N(function(c) {
            return c
        }), Oe(function(c) {
            return (new W(c)).T(a)
        }))
    }

    function wr(a, b, c) {
        return b.g(Xd(Ud), V(a, 1)).g(Q(function(d, e) {
            return Eq(d, e, kq)
        }), R({
            timestamp: c.now(),
            value: jq
        }), V(a, 1))
    }

    function zr(a, b, c, d) {
        c = d.g(Xq(c), yq(N(function(e) {
            return Math.round(e * 100) / 100
        })), V(a, 1));
        return b instanceof W ? c : Ad([c, b]).g(N(function(e) {
            var f = y(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), Q(Eq), V(a, 1))
    }

    function Ar(a, b, c, d) {
        b = [b.g(N(function(e) {
            return e.value.L.width * e.value.L.height >= 242500
        }))];
        c instanceof K && b.push(c.g(N(function(e) {
            return !!e
        })));
        c = Ad(b);
        return d ? c.g(N(function(e) {
            return e.some(function(f) {
                return f
            })
        }), R(!1), Q(), V(a, 1)) : (new W(!1)).T(a)
    }

    function yr(a, b) {
        a = Ad([a, b]).g(N(function(e) {
            var f = y(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.cg
        }), Q());
        var c = a.g(N(function(e) {
                return e === void 0 ? !0 : e
            }), hf(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(hf(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), N(function(e) {
                return !!e
            }));
        return Ad([b, $d(a, c, d)]).g(N(function(e) {
            var f = y(e);
            e = f.next().value;
            var g = y(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    };
    var Br = J(Yo("data-google-av-itpl"), N(function(a) {
        return Number(a)
    }), N(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var Cr = {
            Xi: "addEventListener",
            hj: "getMaxSize",
            ij: "getScreenSize",
            jj: "getState",
            kj: "getVersion",
            vj: "removeEventListener",
            qj: "isViewable"
        },
        Dr = function(a, b) {
            this.ua = null;
            this.Kh = new L;
            b = b || this.Si;
            var c = a.ke,
                d = !a.lc;
            if (c && d) {
                var e = a.global.top.mraid;
                if (e) {
                    this.Wc = b(e);
                    this.ua = e;
                    this.sb = 3;
                    return
                }
            }(a = a.global.mraid) ? (this.Wc = b(a), this.ua = a, this.sb = c ? d ? 2 : 1 : 0) : (this.sb = -1, this.Wc = 2)
        };
    Dr.prototype.addEventListener = function(a, b) {
        return this.Qb("addEventListener", a, b)
    };
    Dr.prototype.removeEventListener = function(a, b) {
        return this.Qb("removeEventListener", a, b)
    };
    Dr.prototype.Lf = function() {
        var a = this.Qb("getVersion");
        return typeof a === "string" ? a : ""
    };
    Dr.prototype.getState = function() {
        var a = this.Qb("getState");
        return typeof a === "string" ? a : ""
    };
    var Er = function(a) {
            a = a.Qb("isViewable");
            return typeof a === "boolean" ? a : !1
        },
        Fr = function(a) {
            if (a.ua) return a = a.ua.AFMA_LIDAR, typeof a === "string" ? a : void 0
        };
    Dr.prototype.Si = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(Cr).every(function(b) {
            return typeof a[b] === "function"
        }) ? 0 : 1 : 2 : 1
    };
    Dr.prototype.Qb = function(a) {
        var b = B.apply(1, arguments);
        if (this.ua) try {
            return this.ua[a].apply(this.ua, z(b))
        } catch (c) {
            this.Kh.next(a)
        }
    };
    ea.Object.defineProperties(Dr.prototype, {
        uf: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.ua) {
                    var a = this.ua.AFMA_LIDAR_EXP_1;
                    return a === void 0 ? void 0 : !!a
                }
            },
            set: function(a) {
                this.ua && (this.ua.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function Gr(a, b) {
        return (new Dr(a)).sb !== -1 ? (new W(!0)).T(a.i) : b.g(Yo("data-google-av-inapp"), N(function(c) {
            return c !== null
        }), V(a.i, 1))
    };
    var Ir = function(a, b) {
            var c = this;
            this.m = a;
            this.xe = this.nd = null;
            this.wi = b.g(Q()).subscribe(function(d) {
                Hr(c);
                c.xe = d
            })
        },
        Jr = function(a, b) {
            Hr(a);
            a.nd = a.m.setTimeout(function() {
                var c;
                return void((c = a.xe) == null ? void 0 : c.next())
            }, b)
        },
        Hr = function(a) {
            a.nd !== null && a.m.clearTimeout(a.nd);
            a.nd = null
        };
    Ir.prototype.dispose = function() {
        Hr(this);
        this.wi.unsubscribe();
        this.xe = null
    };

    function Kr(a, b, c, d, e) {
        var f = ir.zg;
        var g = g === void 0 ? new Ir(b, d) : g;
        return (new K(function(h) {
            var k = c.g(R(void 0), T(function() {
                return Lr(e)
            })).g(N(function(l) {
                var m = l.value;
                l = l.timestamp;
                var u = m.visible;
                m = m.bb;
                var r = m >= f;
                r || !u ? Hr(g) : (l = Math.max(0, we(b.now(), l)), Jr(g, Math.max(0, f - m - l)));
                return r
            }), hf(function(l, m) {
                return m || l
            }, !1), Q()).subscribe(h);
            return function() {
                g.dispose();
                k.unsubscribe()
            }
        })).g(kf(function(h) {
            return !h
        }, !0), V(a, 1))
    }

    function Lr(a) {
        return Qp([a, a.g(fq())]).g(N(function(b) {
            var c = y(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    bb: c.value
                }
            }
        }), Q(function(b, c) {
            return Eq(b, c, function(d, e) {
                return d.bb === e.bb && d.visible === e.visible
            })
        }))
    };

    function Mr(a, b) {
        return {
            Kd: b.g(Yo("data-google-av-adk")),
            ac: b.g(Yo("data-google-av-btr"), Q(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Td: b.g(Yo("data-google-av-cpmav"), Q(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Te: b.g(Yo("data-google-av-vrus"), Q(), N(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            hh: Dp(a, b),
            flags: b.g(Yo("data-google-av-flags"), Q()),
            kb: Gr(a, b),
            re: b.g(Up("cr", function(c) {
                return c ===
                    "1"
            }), Q()),
            Ph: b.g(Up("omid", function(c) {
                return c === "1"
            }), Q()),
            me: b.g(Br),
            metadata: b.g(Yo("data-google-av-metadata")),
            Sa: b.g(ep),
            oa: b.g(Zo),
            Wi: b.g(Up("la", function(c) {
                return c === "1"
            }), Q()),
            lb: b.g(Yo("data-google-av-turtlex"), N(function(c) {
                return c !== null
            }), Q()),
            ue: b.g(Yo("data-google-av-vattr"), N(function(c) {
                return c !== null
            }), Q())
        }
    };

    function Nr() {
        return J(Tp(), hf(function(a, b) {
            return Math.max(a, b)
        }, 0), N(function(a) {
            return Math.round(a)
        }))
    };

    function Or(a) {
        return J(Rq(M(a)), Nr())
    };

    function Pr(a, b, c, d, e) {
        c = c.g(N(function() {
            return !1
        }));
        d = Ad([e, d]).g(T(function(f) {
            f = y(f).next().value;
            return Qr(b, f)
        }));
        return Td(M(!1), c, d).g(Q(), V(a.i, 1))
    }

    function Qr(a, b) {
        return a.g(N(function(c) {
            return b || c === 0 || c === 2
        }))
    };
    var Rr = [33, 32],
        Sr = J(Br, N(function(a) {
            return Rr.indexOf(a) >= 0
        }), Q());

    function Tr(a, b, c, d, e, f) {
        var g = c.g(N(function(k) {
                return k === 9
            })),
            h = b.element.g(Sr);
        c = e.g(O(function(k) {
            return k
        }), T(function() {
            return Ad([g, h])
        }), N(function(k) {
            var l = y(k);
            k = l.next().value;
            return !l.next().value || k
        }), Q());
        f = Ad([c, d.g(Q()), f]).g(N(function(k) {
            var l = y(k);
            k = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return ur(a, b, !k, m, l)
        }), ff(1), md());
        d = f.g(N(function(k) {
            return k.Xc
        }));
        f = f.g(T(function(k) {
            return k.rb
        }), R(null), Q(), V(a.i, 1));
        return {
            Qa: d,
            cc: f
        }
    };

    function Ur(a) {
        var b = b === void 0 ? !1 : b;
        return J(T(function(c) {
            return ti(a.document, c, b)
        }), V(a.i, 1))
    };
    var Vr = function(a, b, c, d, e, f) {
        this.rc = b.element.g(Ur(a), V(a.i, 1));
        this.ug = Pr(a, c, b.element, this.rc, d);
        c = Tr(a, b, e, d, this.ug, f);
        d = c.cc;
        this.Qa = c.Qa;
        this.cc = d;
        this.Ue = Td((new W(1)).T(a.i), b.element.g(Ve(1), N(function() {
            return 2
        }), V(a.i, 1)), this.rc.g(Ve(1), N(function() {
            return 3
        }), V(a.i, 1)), this.ug.g(O(Boolean), Ve(1), N(function() {
            return 0
        }), V(a.i, 1))).g(kf(function(g) {
            return g !== 0
        }, !0), V(a.i, 0))
    };

    function Wr(a, b) {
        return a && b === 0 ? 15 : a || b !== 1 ? null : 14
    }

    function Xr(a, b, c) {
        return b instanceof K ? b.g(T(function(d) {
            return (d = Wr(d, c)) ? cd(new ge(d)) : a
        })) : (b = Wr(b.value, c)) ? cd(new ge(b)) : a
    };

    function Yr(a) {
        var b = new ge(13);
        if (a.length < 1) return {
            chain: Hc,
            Pd: Hc
        };
        var c = new L,
            d = a[0];
        return {
            chain: a.slice(1).reduce(function(e, f) {
                return e.g(Oe(function(g) {
                    c.next(g);
                    return f
                }))
            }, d).g(Oe(function(e) {
                c.next(e);
                return cd(b)
            }), ef(new L), md()),
            Pd: c
        }
    };
    var Zr = function() {};
    var $r = function(a, b) {
        this.context = a;
        this.Li = b
    };
    q($r, Zr);
    $r.prototype.Za = function(a, b) {
        var c = this.Li.map(function(f) {
                return f.Za(a, b)
            }),
            d = Yr(c.map(function(f) {
                return f.gb
            })),
            e = d.Pd.g(as());
        return {
            gb: d.chain.g(V(this.context.i, 1)),
            Ya: Object.assign.apply(Object, [{
                Me: e,
                hk: d.Pd
            }].concat(z(c.map(function(f) {
                return f.Ya
            }))))
        }
    };
    var as = function() {
        return hf(function(a, b) {
            b instanceof ge ? a.push(b.Zh) : a.push(-1);
            return a
        }, [])
    };

    function bs(a, b) {
        var c = a.g(ef(new L), md());
        return T(function(d) {
            return c.g(b(d))
        })
    };

    function cs(a, b) {
        if (a.lc) return cd(new ge(6));
        var c = new L;
        return Td(M({}), b, c).g(N(function() {
            return {
                timestamp: a.m.now(),
                value: {
                    fa: "geo",
                    ja: ds(a),
                    Y: Qo(a, !0),
                    da: c,
                    pa: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Mh(a.i))
    }

    function ds(a) {
        var b = Qo(a, !1);
        if (!a.ke || !Kg(a.global.parent) || a.global.parent === a.global) return b;
        var c = new Mo(a.global.parent, a.Da);
        c.J = a.J;
        c = ds(c);
        a = a.global.frameElement.getBoundingClientRect();
        return yi(zi(yi(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };
    var es = function(a, b) {
        this.context = a;
        this.pb = b
    };
    q(es, Zr);
    es.prototype.Za = function(a, b) {
        var c = bs(cs(this.context, this.pb), lq(this.context, b.Sa));
        return {
            gb: Xr(a.Qa.g(c), b.kb, 0),
            Ya: {}
        }
    };
    var fs = function(a, b, c) {
        c = c === void 0 ? qq(a, b) : c;
        this.context = a;
        this.Nh = c
    };
    q(fs, Zr);
    fs.prototype.Za = function(a, b) {
        var c = this.Nh(b.Eg);
        return {
            gb: Xr(a.Qa.g(c, uq(this.context)), b.kb, 0),
            Ya: {}
        }
    };

    function gs(a, b, c, d, e) {
        var f = f === void 0 ? new Dr(a) : f;
        var g = g === void 0 ? qf(a.m, 500) : g;
        var h = h === void 0 ? qf(a.m, 100) : h;
        e = M(f).g(hs(c), lf(function(k) {
            d.next(k.sb)
        }), is(a, h), js(a), ks(a, e), ff(1), md());
        f = new L;
        b = Td(M({}), b, f);
        return e.g(ls(a, f, b, g, c), V(a.i, 1))
    }

    function ks(a, b) {
        return J(function(c) {
            return Ad([c, b])
        }, We(function(c) {
            var d = y(c);
            c = d.next().value;
            return d.next().value !== 9 || Er(c) ? M(!0) : ms(a, c, "viewableChange").g(O(function(e) {
                return y(e).next().value
            }), Ve(1))
        }), N(function(c) {
            return y(c).next().value
        }))
    }

    function hs(a) {
        return T(function(b) {
            if (b.sb === -1) return a.next("if"), cd(new ge(7));
            if (b.Wc !== 0) switch (b.Wc) {
                case 1:
                    return a.next("mm"), cd(new ge(18));
                case 2:
                    return a.next("ng"), cd(new ge(17));
                default:
                    return a.next("i"), cd(new ge(8))
            }
            return M(b)
        })
    }

    function is(a, b) {
        return We(function() {
            var c = a.hg;
            return ri(a.document) === "complete" ? M(!0) : c.g(We(function() {
                return b
            }))
        })
    }

    function js(a) {
        return T(function(b) {
            return b.getState() !== "loading" ? M(b) : ms(a, b, "ready").g(N(function() {
                return b
            }))
        })
    }

    function ls(a, b, c, d, e) {
        return T(function(f) {
            var g = Fr(f);
            if (typeof g !== "string") return e.next("nc"), cd(new ge(9));
            f.uf !== void 0 && (f.uf = !0);
            g = ms(a, f, g, ns);
            var h = {
                version: f.Lf(),
                sb: f.sb
            };
            g = g.g(N(function(l) {
                return os.apply(null, [a, b, f, h].concat(z(l)))
            }));
            var k = d.g(lf(function() {
                e.next("mt")
            }), T(function() {
                return cd(new ge(10))
            }));
            g = Yd(g, k);
            return Ad([g, c]).g(N(function(l) {
                l = y(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.m.now()
                })
            }))
        })
    }

    function ns(a, b) {
        return (b === null || typeof b === "number") && (a === null || !!a && typeof a.height === "number" && typeof a.width === "number" && typeof a.x === "number" && typeof a.y === "number")
    }

    function os(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : wi;
        c = c.Qb("getMaxSize");
        var g = c != null && typeof c.width === "number" && typeof c.height === "number" ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var h = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(h) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: h,
                height: g
            }
        }
        a = {
            value: {
                ja: e,
                Y: c,
                fa: "mraid",
                da: b,
                pa: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.m.now()
        };
        return Object.assign({}, a, d, {
            Bj: f
        })
    }

    function ms(a, b, c, d) {
        d = d === void 0 ? function() {
            return !0
        } : d;
        return (new K(function(e) {
            var f = a.I.Ub(745, function() {
                e.next(B.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).g(O(function(e) {
            return d.apply(null, z(e))
        }))
    };
    var ps = function(a, b) {
        this.context = a;
        this.pb = b
    };
    q(ps, Zr);
    ps.prototype.Za = function(a, b) {
        var c = new ed(1),
            d = new ed(1),
            e = bs(gs(this.context, this.pb, c, d, b.Sa), lq(this.context, b.Sa));
        return {
            gb: Xr(a.Qa.g(e), b.kb, 1),
            Ya: {
                ye: c.g(V(this.context.i, 1)),
                ze: d.g(V(this.context.i, 1))
            }
        }
    };

    function qs(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function rs(a, b) {
        var c = c === void 0 ? null : c;
        var d = new L,
            e = void 0,
            f = a.Ef,
            g = d.g(N(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.m.now()
                }) : null
            }), O(function(k) {
                return k !== null
            }), N(function(k) {
                return k
            }));
        b = Ad([Td(f, g), b]);
        var h = c;
        return b.g(O(function(k) {
            k = y(k).next().value;
            h === null && (h = k.value.Sg);
            return k.value.Sg === h
        }), lf(function(k) {
            return void(e = y(k).next().value)
        }), N(function(k) {
            var l = y(k);
            k = l.next().value;
            l = l.next().value;
            try {
                var m = k.value.data,
                    u = k.timestamp,
                    r = m.viewport,
                    t, w, v = Object.assign({},
                        r, {
                            width: (t = r == null ? void 0 : r.width) != null ? t : 0,
                            height: (w = r == null ? void 0 : r.height) != null ? w : 0,
                            x: 0,
                            y: 0,
                            bk: r ? r.width * r.height : 0
                        }),
                    x = ss(v),
                    A = m.adView,
                    P = A.measuringElement && A.containerGeometry ? ss(A.containerGeometry) : ss(A.geometry),
                    S = ss(A.geometry),
                    la = A.reasons.some(qs),
                    H = la ? wi : ss(A.onScreenGeometry),
                    C;
                l && (C = A.percentageInView / 100);
                l && la && (C = 0);
                return {
                    timestamp: u,
                    value: {
                        fa: "omid",
                        ja: P,
                        Y: x,
                        da: d,
                        U: "omid",
                        L: S,
                        pa: {
                            x: P.left,
                            y: P.top
                        },
                        W: H,
                        bd: C
                    }
                }
            } catch (fc) {
                ih(fc, th());
                var da, Cc;
                m = (Cc = (da = fc) == null ? void 0 : da.message) !=
                    null ? Cc : "An unknown error occurred";
                da = "Error while processing geometryChange event: " + JSON.stringify(k.value) + "; " + m;
                throw Error(da);
            }
        }), ff(1), md())
    }

    function ss(a) {
        var b, c, d, e;
        return {
            left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
            top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
            width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
            height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0)
        }
    };

    function ts(a, b, c, d) {
        c = c === void 0 ? Ud : c;
        var e = a.i;
        if (b === null) return cd(new ge(20));
        if (!b.validate()) return cd(new ge(21));
        var f;
        d = us(e, b, d).g(N(function(g) {
            var h = g.value;
            g = g.timestamp;
            var k = b.m,
                l = a.m;
            if (k.timeline !== g.timeline) throw new le;
            g = new ue(g.value - k.now().value + l.now().value, l.timeline);
            return f = {
                value: h,
                timestamp: g
            }
        }));
        return Td(d, c.g(N(function() {
            return f
        }))).g(O(function(g) {
            return g !== void 0
        }), N(function(g) {
            return g
        }), V(a.i, 1))
    }

    function us(a, b, c) {
        return rs(b, c).g(V(a, 1), N(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    pa: {
                        x: d.value.L.left,
                        y: d.value.L.top
                    },
                    ja: d.value.W,
                    Y: d.value.Y,
                    fa: d.value.U,
                    da: d.value.da
                }
            }
        }))
    };
    var vs = function(a, b, c) {
        this.na = a;
        this.P = b;
        this.pb = c
    };
    q(vs, Zr);
    vs.prototype.Za = function(a, b) {
        var c = b.Sa;
        b = ts(this.P, this.na, this.pb, b.gg);
        c = bs(b, lq(this.P, c));
        return {
            gb: a.Qa.g(c),
            Ya: {}
        }
    };
    var ws = function(a, b, c) {
        this.na = a;
        this.P = b;
        this.sh = c
    };
    q(ws, Zr);
    ws.prototype.Za = function(a, b) {
        var c = ts(this.P, this.na, void 0, b.gg);
        b = tq(this.P, b.Eg, this.sh);
        c = bs(c, b);
        return {
            gb: a.Qa.g(c),
            Ya: {}
        }
    };

    function xs(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function ys(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };

    function zs(a) {
        return a.document.li.g(N(function(b) {
            return b === "visible"
        }), Q(), V(a.i, 1))
    };
    var As;
    As = ["2025110501"].slice(-1)[0].substring(0, 8);

    function Bs(a, b, c) {
        var d;
        return b.g(Q(), T(function(e) {
            return c.g(N(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), R(!1), V(a.i, 1))
    };

    function Cs(a) {
        return J(yq(N(function(b) {
            return Qq(b, a)
        })), Sp(), N(function(b) {
            return Math.round(b)
        }))
    };

    function Ds(a, b, c, d, e) {
        var f = pr;
        if (f.length > 1)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.g(R(void 0), T(function() {
            return c.g(fq())
        }), Q(), V(a, 1));
        e = e.g(R(void 0), T(function() {
            return c.g(Nr())
        }), Q(), V(a, 1));
        return {
            xd: d.g(R(void 0), T(function() {
                return b.g(N(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: !0
                    }
                }), Sp())
            }), Q(), V(a, 1)),
            yd: d.g(R(void 0), T(function() {
                return b.g(N(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: h.value === 0
                    }
                }), Sp())
            }), Q(), V(a, 1)),
            vc: d.g(R(void 0), T(function() {
                return b.g(eq(Or,
                    f))
            }), Q(Pb), V(a, 1)),
            Jc: d.g(R(void 0), T(function() {
                return b.g(eq(Cs, f), N(function(h) {
                    return h.map(function(k, l) {
                        return l > 0 ? k - h[l - 1] : k
                    })
                }))
            }), Q(Pb), V(a, 1)),
            uc: e,
            bb: g.g(Q(Eq), V(a, 1))
        }
    };

    function Es(a, b, c) {
        var d = c.g(N(function(e) {
            return {
                value: e,
                timestamp: a.m.now()
            }
        }), Q(Eq));
        return b instanceof K ? b.g(Q(), T(function(e) {
            return e ? (new W({
                value: !1,
                timestamp: a.m.now()
            })).T(a.i) : d
        })) : b.value === !1 ? d : new W(!1)
    }

    function Fs(a, b, c, d, e, f, g) {
        var h = ir;
        b = b instanceof K ? b.g(R(!1), Q()) : b;
        var k = !(Zg() || $g());
        c = Es(a, c, d);
        a = g.Qa.g(Pp(a.i));
        return Object.assign({}, h, {
            dd: c,
            Gg: e,
            hf: k,
            eg: b,
            hd: a,
            Dg: f
        })
    };

    function Gs(a) {
        a = a.global;
        if (typeof a.__google_lidar_ === "undefined") return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if (typeof b === "number" && b > 0 && (a = a.__google_lidar_radf_, typeof a === "function")) try {
            a()
        } catch (c) {}
        return !0
    }

    function Hs(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (b.__google_lidar_radf_ !== void 0) return Hc;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new L;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.g(sg(a.I, 743))
    };
    var Is = function(a) {
            var b = this;
            this.te = !1;
            this.Ce = [];
            this.Be = [];
            a(function(c) {
                b.te = !0;
                b.resolution = c;
                b.evaluate()
            }, function(c) {
                b.si = c;
                b.evaluate()
            })
        },
        Js = function(a) {
            return new Is(function(b, c) {
                var d = [],
                    e = 0;
                a.forEach(function(f, g) {
                    f.then(function(h) {
                        d[g] = h;
                        ++e === a.length && b(d)
                    }).catch(function(h) {
                        c(h)
                    })
                })
            })
        };
    Is.prototype.evaluate = function() {
        var a = this.resolution,
            b = this.si;
        if (b !== void 0 || this.te) this.te && this.Ce.forEach(function(c) {
            return void c(a)
        }), b !== void 0 && this.Be.forEach(function(c) {
            return void c(b)
        }), this.Ce = [], this.Be = []
    };
    Is.prototype.then = function(a) {
        this.Ce.push(a);
        this.evaluate();
        return this
    };
    Is.prototype.catch = function(a) {
        this.Be.push(a);
        this.evaluate();
        return this
    };
    var Ks = function(a) {
        this.children = a;
        this.qe = !1;
        this.Qd = []
    };
    Ks.prototype.complete = function() {
        var a = this;
        this.qe = !0;
        this.Qd.forEach(function(b) {
            return void b(a)
        });
        this.Qd.splice(0)
    };
    Ks.prototype.onComplete = function(a) {
        this.qe ? a(this) : this.Qd.push(a)
    };
    Ks.prototype.ab = function(a) {
        var b = this.children.map(function(c) {
            return c.ab(a)
        });
        return b.find(function(c) {
            return c !== 2
        }) === void 0 ? 2 : this.completed ? 0 : b.some(function(c) {
            return c === 1
        }) ? 1 : 0
    };
    ea.Object.defineProperties(Ks.prototype, {
        completed: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.qe
            }
        }
    });
    var Ls = function() {
        var a = B.apply(0, arguments);
        Ks.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            d.onComplete(function() {
                --c === 0 && b.complete()
            })
        })
    };
    q(Ls, Ks);
    Ls.prototype.clone = function() {
        return new(Function.prototype.bind.apply(Ls, [null].concat(z(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    Ls.prototype.Pe = function(a, b) {
        var c = this;
        if (!this.completed) {
            var d = this.events.find(function(e) {
                return e.ab(a) === 1
            });
            d !== void 0 && d.Pe(a, function() {
                c.completed || b()
            })
        }
    };
    var Ms = function(a, b) {
        Ks.call(this, []);
        this.Yd = a;
        this.jd = Symbol(b);
        this.mi = a
    };
    q(Ms, Ks);
    Ms.prototype.clone = function() {
        var a = new Ms(this.mi, this.jd.description);
        a.jd = this.jd;
        return a
    };
    Ms.prototype.ab = function(a) {
        return a !== this.event ? 2 : this.completed || this.Yd === 0 ? 0 : 1
    };
    Ms.prototype.Pe = function(a, b) {
        this.ab(a) === 1 && (this.Yd--, b(), this.Yd === 0 && this.complete())
    };
    ea.Object.defineProperties(Ms.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.jd
            }
        }
    });
    var Ns = function(a) {
        Ms.call(this, 1, a)
    };
    q(Ns, Ms);
    var Os = function(a, b, c) {
        var d = B.apply(3, arguments);
        this.Na = a;
        this.ph = b;
        this.Vd = c;
        this.tc = new Set;
        this.Jb = d;
        if (this.Na.P) this.context = this.Na.P;
        else if (this.Na.na) this.context = this.Na.na;
        else throw Error("Ja");
        var e = d.reduce(function(h, k) {
            k.subscribedEvents.forEach(function(l) {
                return void h.add(l)
            });
            return h
        }, new Set);
        e = y(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                yf: void 0
            }, f = e.next()) {
            g.yf = f.value;
            f = d.filter(function(h) {
                return function(k) {
                    return k.controlledEvents.indexOf(h.yf) >= 0
                }
            }(g));
            if (f.length ===
                0) throw Error("Ka");
            if (f.length > 1) throw Error("La");
        }
    };
    Os.prototype.start = function() {
        var a = this;
        this.Jb.forEach(function(b) {
            return void b.start(a.Na)
        });
        this.Vd.start(this.Na, this.xh.bind(this), this.Cb.bind(this), function() {})
    };
    Os.prototype.dispose = function() {
        var a = this;
        this.Vd.dispose();
        this.tc.forEach(function(b) {
            return void a.Cb(b)
        });
        this.Jb.forEach(function(b) {
            return void b.dispose()
        })
    };
    var Ps = function(a, b) {
            b = {
                measuringCreativeIds: [].concat(z(a.tc.values())).map(function(c) {
                    return a.context.fc.getName(c)
                }),
                hasCreativeSourceCompleted: !!a.Vd.ud,
                colleagues: a.Jb.map(function(c) {
                    return {
                        name: c.name,
                        controlledEvents: c.controlledEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        }),
                        subscribedEvents: c.subscribedEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        })
                    }
                }),
                ephemeralCreativeStateChanges: b
            };
            b = {
                specMajor: 2,
                specMinor: 0,
                specPatch: 0,
                instanceId: a.context.fc.getName(a.context.tb),
                timestamp: we(a.context.m.now(), new ue(0, a.context.m.timeline)),
                mediatorState: b
            };
            de(a.context, b)
        },
        Qs = function(a, b, c, d, e) {
            var f = {};
            Ps(a, (f[b] = {
                events: [{
                    timestamp: c,
                    description: d,
                    status: e
                }]
            }, f))
        };
    Os.prototype.xh = function(a, b, c) {
        var d = this;
        if (!this.tc.has(a)) {
            var e = this.ph.clone();
            this.tc.add(a);
            Ps(this, {});
            var f = !1,
                g = [];
            this.Jb.forEach(function(h) {
                var k = function(l, m, u) {
                    var r = d.context.fc.getName(a),
                        t = we(d.context.m.now(), new ue(0, d.context.m.timeline)),
                        w, v = (w = l.description) != null ? w : "n/a";
                    if (h.controlledEvents.indexOf(l) < 0 || e.ab(l) !== 1) return u(!1), Qs(d, r, t, v, 1), new Is(function(A) {
                        return void A()
                    });
                    var x = new Is(function(A) {
                        e.Pe(l, function() {
                            d.Jb.filter(function(P) {
                                return P.subscribedEvents.indexOf(l) >=
                                    0
                            }).forEach(function(P) {
                                return void P.handleEvent(a, l, m)
                            });
                            A()
                        })
                    });
                    return new Is(function(A) {
                        x.then(function() {
                            u(!0);
                            Qs(d, r, t, v, 2);
                            A()
                        })
                    })
                };
                h.he(a, b, c, function(l, m, u) {
                    return f ? k(l, m, u) : new Is(function(r) {
                        g.push(function() {
                            k(l, m, u).then(function() {
                                r()
                            })
                        })
                    })
                }, function(l) {
                    try {
                        d.context.J.K("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=colleague-executed&name=" + l, {
                            ia: "GET"
                        }).sendNow()
                    } catch (m) {}
                })
            });
            f = !0;
            g.forEach(function(h) {
                return void h()
            })
        }
    };
    Os.prototype.Cb = function(a) {
        this.tc.delete(a);
        this.Jb.forEach(function(b) {
            b.Cb(a)
        });
        Ps(this, {})
    };
    var Rs = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? !1 : b;
            this.valueType = "boolean"
        },
        Ss = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? 0 : b;
            this.valueType = "number"
        };
    var Ts = {
        considerOmidZOrderOcclusions: [new Rs("100006"), !1],
        extraPings: [new Ss("45362137"), 0],
        extrapolators: [new Rs("45377435"), !1],
        rxlidarStatefulBeacons: [new Rs("45372163"), !1],
        shouldIgnoreAdChoicesIcon: [new Rs("45382077"), !1],
        dedicatedViewableAttributionPing: [new Ss("45389692"), 0],
        useReachIntegrationPolyfill: [new Rs("45407239"), !1],
        useReachIntegrationSharedStorage: [new Rs("45407240", !0), !0],
        sendBrowserIdInsteadOfVPID: [new Rs("45407241"), !1],
        waitForImpressionColleague: [new Rs("45430682"), !1],
        fetchLaterBeacons: [new Rs("45618478"), !1],
        rxInNonrx: [new Rs("45642405"), !1],
        addQueryIdToErrorPing: [new Rs("45653435"), !1],
        shouldSendExplicitDisplayMeasurablePing: [new Rs("45658589"), !1],
        reachUseCreateWorklet: [new Rs("45661569"), !1],
        tosCustomTimeoutMillis: [new Ss("45706257", 36E5), 36E5],
        shouldCacheTimeMetricsInLocalStorage: [new Rs("45722991"), !1]
    };

    function Us(a) {
        return Object.entries(Ts).reduce(function(b, c) {
            var d = y(c);
            c = d.next().value;
            var e = y(d.next().value);
            d = e.next().value;
            e = e.next().value;
            var f;
            if (a == null) var g = void 0;
            else a: {
                var h = a.Bf[d.key];
                if (d.valueType === "proto") {
                    try {
                        var k = JSON.parse(h);
                        if (Array.isArray(k)) {
                            g = k;
                            break a
                        }
                    } catch (l) {}
                    g = d.defaultValue
                } else g = typeof h === typeof d.defaultValue ? h : d.defaultValue
            }
            b[c] = (f = g) != null ? f : e;
            return b
        }, {})
    };
    var Xm = function(a) {
        ro.call(this, a)
    };
    q(Xm, ro);
    var Vs = function(a) {
        return sl(Im(a, 3))
    };
    Xm.prototype.de = function() {
        return cn(this, 4, !0)
    };
    var Ws = function(a) {
        return gl(Im(a, 5))
    };
    Xm.prototype.ed = function() {
        return dn(this, 6)
    };
    Xm.V = "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
    var Xs = [0, fo, -2, eo, -1, ao];
    Xm.prototype.O = to(Xs);
    var Ys = function(a) {
        ro.call(this, a)
    };
    q(Ys, ro);
    Ys.prototype.getType = function() {
        var a = a === void 0 ? 0 : a;
        var b = kl(Im(this, 6));
        return b != null ? b : a
    };
    var Zs = uo(Ys);
    Ys.V = "ads.geo.GeoTargetMessage";
    var $s = function(a) {
        ro.call(this, a)
    };
    q($s, ro);
    n = $s.prototype;
    n.Gf = function() {
        return en(this, 2)
    };
    n.Hf = function() {
        return sl(Im(this, 2))
    };
    n.de = function() {
        return cn(this, 3, !0)
    };
    n.If = function() {
        return Zm(this, Ys, 4)
    };
    n.rg = function(a) {
        return bn(this, Ys, 4, a)
    };
    n.Kf = function() {
        return Pm(this, 7, kl, void 0 === Qk ? 2 : 4)
    };
    n.ff = function(a) {
        return kn(this, 7, a)
    };
    n.sg = function(a) {
        return fn(this, 9, a)
    };
    n.ed = function() {
        return dn(this, 10)
    };
    $s.V = "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
    var at = [0, io, -4, ko, eo, ao, Xn, io, Xn, io, ao, io, -1, [0, ao, -3], jo, $n, io, Zn, -1, ao, -1, Zn, Xn, [0, Zn, ao, -1, ko, Xn, Zn], Wn, io, [0, ao, -1]];
    Ys.prototype.O = to(at);
    var bt = [0, fo, -1, eo, at, bo, -1, lo, ao, eo, ao];
    $s.prototype.O = to(bt);
    var ct = function(a) {
        ro.call(this, a)
    };
    q(ct, ro);
    ct.prototype.Gf = function() {
        return en(this, 1)
    };
    ct.prototype.Hf = function() {
        return sl(Im(this, 1))
    };
    ct.prototype.ed = function() {
        return dn(this, 2)
    };
    ct.V = "ads.branding.measurement.client.serving.integrations.shared.SharedMetadata";
    var dt = [0, fo, ao];
    ct.prototype.O = to(dt);
    var et = function(a) {
        ro.call(this, a)
    };
    q(et, ro);
    var ft = function(a) {
        return Zm(a, $s, 1)
    };
    et.V = "ads.branding.measurement.client.serving.IntegratorMetadata";
    var gt = [0, bt, Xs, dt];
    et.prototype.O = to(gt);
    var ht = so(et, gt);
    var jt = function() {
        this.Bf = {}
    };
    var kt = function() {
        this.tf = !1;
        this.qf = new Map
    };
    kt.prototype.start = function(a, b, c, d) {
        var e = this;
        if (this.ud === void 0 && a.P) {
            var f = a.P;
            this.pf = d;
            c = !this.tf && Gs(f);
            d = this.tf ? Hc : Hs(f);
            d = hp(f, d);
            this.ud = (c ? Hc : d.g(N(function(g) {
                var h = h === void 0 ? Symbol() : h;
                return Object.freeze({
                    tb: h,
                    element: (new W(g)).T(f.i)
                })
            }), $o())).subscribe(function(g) {
                var h = g.tb;
                e.qf.set(h, g);
                g.element.g(Ve(1)).subscribe(function(k) {
                    var l = Xo(k, "data-google-av-flags"),
                        m = new jt;
                    if (l !== null) try {
                        var u = JSON.parse(l)[0];
                        l = "";
                        for (var r = 0; r < u.length; r++) l += String.fromCharCode(u.charCodeAt(r) ^
                            "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(r % 10));
                        m.Bf = JSON.parse(l)
                    } catch (w) {}
                    m = Us(m);
                    k = Xo(k, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (k !== null) try {
                            var t = ht(k);
                            break a
                        } catch (w) {}
                        t = new et
                    }
                    b(h, t, m)
                })
            });
            c && this.dispose();
            a.na && Mf(a.na)
        }
    };
    kt.prototype.dispose = function() {
        var a, b;
        (a = this.ud) == null || (b = a.unsubscribe) == null || b.call(a);
        this.ud = void 0;
        var c;
        (c = this.pf) == null || c.call(this);
        this.pf = void 0
    };
    var lt = function(a) {
        ro.call(this, a)
    };
    q(lt, ro);
    var mt = function(a, b) {
        return hn(a, 1, b)
    };
    lt.V = "contentads.bow.rendering.client.TurtleDoveReportingData";
    lt.prototype.O = to([0, fo, ao, fo, -5, ko, fo, -4]);

    function nt() {
        var a = Pg();
        return a ? Mb("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;Version/8.0 Safari/601.1 WPE;WebOS".split(";"), function(b) {
            return ab(a, b)
        }) || ab(a, "OMI/") && !ab(a, "XiaoMi/") ? !0 : ab(a, "Presto") && ab(a, "Linux") && !ab(a, "X11") && !ab(a, "Android") && !ab(a, "Mobi") : !1
    };
    var ir = Object.freeze({
            zg: 1E3,
            Zd: .5,
            ve: .3
        }),
        pr = Object.freeze([1, .75, ir.Zd, ir.ve, 0]),
        ot = function(a, b, c, d, e, f, g) {
            this.pi = a;
            this.Ib = b;
            this.Eb = c;
            this.Zb = d;
            this.Qc = e;
            this.Rc = f;
            this.Ld = g;
            this.name = "rxlidar";
            this.Xh = new ed;
            this.controlledEvents = [];
            this.subscribedEvents = [];
            this.Wd = new ed;
            this.Ga = new ed;
            this.controlledEvents.push(this.Zb, this.Qc, this.Rc);
            this.subscribedEvents.push(this.Eb)
        };
    n = ot.prototype;
    n.start = function(a) {
        if (this.fe === void 0 && a.P) {
            var b;
            if ((b = this.Ib) != null) var c = b;
            else {
                b = a.P;
                var d = (c = a.na) != null ? c : null;
                c = {
                    oh: .01,
                    ai: qf(b.m, 36E5),
                    pb: b.m.Ha(100).g(V(b.i, 1)),
                    na: d
                }
            }
            this.Ib = c;
            a = a.P;
            this.fe = pt(a, this.Wd.g(V(a.i, 1)), this.Ib.oh, this.Ib.ai, this.Ib.pb, this.Ib.na, this.Ga.g(R(!1), V(a.i, 1)), this.Zb, this.Qc, this.Rc, this.Ld).subscribe(this.Xh)
        }
    };
    n.dispose = function() {
        this.Wd.complete();
        this.Ga.complete();
        var a;
        (a = this.fe) == null || a.unsubscribe();
        this.fe = void 0
    };
    n.he = function(a, b, c, d, e) {
        if (!Mm(b, Xm, 2) || Zm(b, Xm, 2).de()) {
            this.Wd.next(Object.assign({}, this.pi.qf.get(a), {
                metadata: b,
                experimentState: c,
                ik: a,
                Oa: d
            }));
            var f, g;
            e((g = (f = Zm(b, Xm, 2)) == null ? void 0 : f.ed()) != null ? g : -1)
        }
    };
    n.Cb = function() {};
    n.handleEvent = function(a, b) {
        b === this.Eb && (this.Ga.next(!0), this.Ga.complete())
    };

    function pt(a, b, c, d, e, f, g, h, k, l, m) {
        var u = zs(a).g(N(function(t) {
                return !t
            })),
            r = new $r(a, [new fs(a, pr), new es(a, e), new ws(f, a, pr), new vs(f, a, e), new ps(a, e)]);
        return kp(a, b, function(t, w) {
            var v = Mr(t, w.element),
                x = v.Kd,
                A = v.ac,
                P = v.Td,
                S = v.Te,
                la = v.hh,
                H = v.kb,
                C = v.Ph,
                da = v.me,
                Cc = v.re,
                fc = v.Sa,
                pd = v.oa,
                Ma = v.Wi,
                vg = v.lb;
            v = v.ue;
            var wg, kb = (wg = Vs(Ym(w.metadata))) != null ? wg : "";
            wg = mt(new lt, atob(kb)).Ta();
            kb = (new W(w.experimentState)).T(t.i);
            var on = new W(new sf(t, new Hg(t))),
                pn = kb.g(N(function(E) {
                        return E.fetchLaterBeacons
                    }),
                    R(!1), Q(), V(t.i, 1)),
                au = pn.g(N(function(E) {
                    return E && (new Dg(t)).M({
                        vf: !0
                    })
                }), lf(function(E) {
                    E && on.value.K("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&start&control&fle=1&sfl=1").sendNow()
                })),
                Ce = kb.g(N(function(E) {
                    return E.shouldIgnoreAdChoicesIcon
                })),
                Na = H.g(Re(C), N(function(E) {
                    var lb = y(E);
                    E = lb.next().value;
                    lb = lb.next().value;
                    (E = E || lb) || ((E = ab(Pg(), "CrKey") && !(ab(Pg(), "CrKey") && ab(Pg(), "SmartSpeaker")) || ab(Pg(), "PlayStation") || ab(Pg(), "Roku") || nt() || ab(Pg(), "Xbox")) ||
                        (E = Pg(), E = ab(E, "AppleTV") || ab(E, "Apple TV") || ab(E, "CFNetwork") || ab(E, "tvOS")), E || (E = Pg(), E = ab(E, "sdk_google_atv_x86") || ab(E, "Android TV")));
                    return E
                }));
            C = new Vr(t, w, la, H, fc, Ce);
            Ce = kb.g(N(function(E) {
                return E.considerOmidZOrderOcclusions
            }));
            var Ec, Ab = (Ec = Ws(Ym(w.metadata))) != null ? Ec : !1;
            Ec = r.Za(C, {
                kb: H,
                Eg: Ab,
                Sa: fc,
                gg: Ce
            });
            var $a = Ec.gb,
                De = Ec.Ya;
            Ec = De.ye;
            Ce = De.ze;
            De = De.Me;
            Ab = (new W(Ab)).T(t.i);
            var jc = Fs(t, Cc, Na, u, Ma, Ab, C);
            Ma = vr(t.i, t.m, $a, jc);
            Na = Ds(t.i, Ma.xa.Oe, Ma.xa.visible, Ma.Ke, Ma.Hc);
            Ab = Kr(t.i, t.m,
                Ma.Hc, Ma.xa.da, Ma.xa.visible);
            $a = Zq(t.i, t.m, $a, jc);
            jc = or(t.m, t.i, $a.xa.Oe, $a.xa.visible, $a.Ke, $a.Hc);
            var Ni = {
                    Se: hr(t.i, t.m, $a.Hc, jc.uc)
                },
                Oi = kb.g(N(function(E) {
                    return E.extrapolators
                }), R(!1));
            $a = Op(t.i, Oi, Object.assign({}, $a.xa, jc, Ni), Object.assign({}, Ma.xa, {
                Se: Pq(t, Ab),
                vc: Pq(t, Na.vc),
                Jc: Pq(t, Na.Jc),
                uc: Pq(t, Na.uc),
                bb: Na.bb.g(N(function(E) {
                    return new Oq(t.m, E)
                })),
                xd: Pq(t, Na.xd),
                yd: Pq(t, Na.yd)
            }));
            Na = xq(t, d.g(Ue("t")));
            Ab = (f !== null && f.validate() ? f.Fi : Ud).g(V(t.i, 1), Ue("u"));
            Na = Yd(Na, Ab);
            Ab = Bs(t, $a.da,
                Na.g(O(function(E) {
                    return E !== null
                })));
            jc = qt(t, C, x);
            Ni = rt(t, Na, w.element);
            Oi = jc.Tg.g(R({
                x: 0,
                y: 0
            }));
            var du = kb.g(N(function(E) {
                    return E.rxlidarStatefulBeacons
                }), R(!1), Q(), lf(function(E) {
                    Jh = E
                }), V(t.i, 1)),
                qn = da.g(N(function(E) {
                    return E === 40 || E === 41 || E === 42
                })),
                eu = kb.g(N(function(E) {
                    return E.waitForImpressionColleague
                }), R(!1), Q(), V(t.i, 1)),
                fu = b.g(N(function(E) {
                    var lb;
                    return E.experimentState.addQueryIdToErrorPing ? (lb = Zm(E.metadata, ct, 3)) == null ? void 0 : lb.Hf() : void 0
                }));
            return Object.assign({}, {
                J: new W(t.J),
                Gb: new W("lidar2"),
                Ni: new W("lidartos"),
                Xg: new W(As),
                Ld: new W(m),
                Rd: new W(t.validate() ? null : new he),
                dh: new W(si(t.document)),
                X: new W(vp),
                wf: Na,
                yg: Na,
                dk: Ab,
                gd: g,
                Vi: eu,
                Oa: new W(w.Oa),
                Zb: new W(h),
                Qc: new W(k),
                Rc: new W(l),
                gh: new W(t.lc ? 1 : void 0),
                ih: new W(t.Yg ? 1 : void 0),
                kb: H,
                lb: vg,
                Qe: new W(wg),
                Pb: vg.g(O(function(E) {
                    return E
                }), N(function() {
                    return t.Pb.bind(t)
                })),
                ye: Ec.g(V(t.i, 1)),
                ze: Ce.g(V(t.i, 1)),
                th: kb.g(N(function(E) {
                    return E.extraPings
                })),
                Tf: du,
                Dh: pn,
                wg: au,
                ue: v,
                Oh: qn,
                Eh: kb.g(N(function(E) {
                    return E.dedicatedViewableAttributionPing
                })),
                uh: on,
                xg: new W(Jh && (new Ih(t)).M({
                    ia: "GET"
                })),
                Ii: new W(Number(w.experimentState.useReachIntegrationSharedStorage) << 0 + Number(w.experimentState.useReachIntegrationPolyfill) << 1 + Number(w.experimentState.sendBrowserIdInsteadOfVPID) << 2),
                fh: w.element.g(N(function(E) {
                    return E !== null
                })),
                jb: pd,
                Oi: pd,
                Td: P.g(R([])),
                Te: S.g(R([])),
                Bh: P.g(N(function(E) {
                    return E.length > 0 ? !0 : null
                }), R(null), Q()),
                ac: A.g(R([]), V(t.i, 1)),
                Hj: kb,
                shouldSendExplicitDisplayMeasurablePing: kb.g(N(function(E) {
                    return E.shouldSendExplicitDisplayMeasurablePing
                })),
                Kd: x,
                cc: C.cc,
                me: da.g(R(0), V(t.i, 1)),
                Yh: la,
                Sa: fc.g(R(0), V(t.i, 1)),
                wb: qn.g(N(function(E) {
                    return E ? Mp : up
                })),
                Vb: new W(Np),
                re: Cc,
                Vf: C.rc.g(Pp(t.i)),
                Ue: C.Ue
            }, $a, {
                Yc: Ad([$a.Yc, Oi]).g(N(function(E) {
                    var lb = y(E);
                    E = lb.next().value;
                    lb = lb.next().value;
                    return zi(E, lb)
                }), Q(xi))
            }, jc, {
                Kc: Xh(t),
                Ch: Ni,
                Me: De,
                Bd: Ma.xa.Bd,
                Zg: new W(new Gp),
                escapedQueryId: fu
            })
        }, tp(a, "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=" + m + "&v=" + As, c))
    }

    function qt(a, b, c) {
        var d = d === void 0 ? Oa : d;
        var e, f;
        d = ((e = d.performance) == null ? void 0 : (f = e.timing) == null ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            Rg: new W(d),
            Qg: cq(a, b)
        }, bq(a, b, c))
    }

    function rt(a, b, c) {
        return b.g(O(function(d) {
            return d !== null
        }), T(function() {
            return c
        }), N(function(d) {
            var e = bp(a);
            return e.length > 0 && e.indexOf(d) >= 0
        }), N(function(d) {
            return !d
        }))
    };
    var st = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.Eb = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "impression";
        this.je = new Map
    };
    n = st.prototype;
    n.start = function(a) {
        this.Na = a
    };
    n.dispose = function() {
        this.je.clear()
    };
    n.he = function(a, b, c, d) {
        if (b = this.Na) c = new tt(b, c, this.Eb, d), this.je.set(a, c)
    };
    n.Cb = function(a) {
        this.je.delete(a)
    };
    n.handleEvent = function() {};
    var tt = function(a, b, c, d) {
        var e = this;
        this.context = a;
        this.Eb = c;
        this.Cg = function() {};
        this.Sf = [];
        this.Qf = "&avradf=1";
        this.Rf = Js([]);
        this.Ga = new ed;
        c = a.na;
        var f = c !== null && (c == null ? void 0 : c.validate()),
            g, h = (g = a.P) == null ? void 0 : g.i;
        this.Ga.g(R(!b.waitForImpressionColleague), V(h, 1));
        this.Ki = f ? c == null ? void 0 : c.Pf.g(Ve(1), Ue(!0), R(!1)) : (new W(!0)).T(h);
        this.Cg = function(k, l) {
            e.Ga.next(!0);
            e.Ga.complete();
            Ad([e.Ga, e.Ki]).subscribe(function(m) {
                var u = y(m);
                m = u.next().value;
                u = u.next().value;
                if (!u) return Ud;
                m && u &&
                    d(e.Eb, k, l);
                return !0
            })
        };
        this.init(a.P)
    };
    tt.prototype.init = function(a) {
        var b = this;
        this.zc = a.global.document;
        this.Sf.push(ut(this));
        var c = {};
        this.Rf = Js(this.Sf);
        this.Rf.then(function() {
            b.Qf = "&vis=" + xs(b.zc) + "&uach=0&ms=0";
            c.paramString = b.Qf;
            c.view_type = "DELAYED_IMPRESSION";
            b.Cg(c, function() {})
        })
    };
    var ut = function(a) {
        return new Is(function(b) {
            var c = ys(a.zc);
            if (c)
                if (xs(a.zc) === 3) {
                    var d = function() {
                        var e = a.zc;
                        typeof e.removeEventListener === "function" && e.removeEventListener(c, d, !1);
                        b(!0)
                    };
                    Fh(a.zc, c, d)
                } else b(!0)
        })
    };

    function vt(a) {
        var b = Yh(a);
        return b ? b.g(N(function(c) {
            var d;
            c = (d = an(c).find(function(f) {
                return sl(Im(f, 1)) === "Google Chrome"
            })) == null ? void 0 : sl(Im(d, 2));
            if (!c) return !1;
            var e;
            return ((e = y(c.split(".").map(function(f) {
                return Number(f)
            })).next().value) != null ? e : 0) >= 121
        })) : Oh.T(a.i)
    };

    function wt(a, b) {
        b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=reach&proto=" + encodeURIComponent(Uh(b.O()));
        a.J.K(b, {
            ia: "GET"
        }).sendNow()
    };

    function xt(a) {
        return [{
            Ab: 2,
            Fc: !1,
            dc: !0,
            filterIds: yt(a == null ? void 0 : a.productionFilterIds)
        }, {
            Ab: 2,
            Fc: !0,
            dc: !0,
            filterIds: yt(a == null ? void 0 : a.testFilterIds)
        }, {
            Ab: 2,
            Fc: !1,
            dc: !1,
            filterIds: yt(a == null ? void 0 : a.testFilterIds)
        }]
    }

    function yt(a) {
        if (a !== void 0 && typeof BigInt === "function") return a.map(function(b) {
            return BigInt(b)
        })
    };
    var zt = function(a) {
        ro.call(this, a)
    };
    q(zt, ro);
    var At = function(a, b) {
            return jn(a, 1, b)
        },
        Bt = function(a, b) {
            return hn(a, 2, b)
        },
        Ct = function(a, b) {
            return hn(a, 3, b)
        };
    zt.prototype.Gc = function(a) {
        return hn(this, 10, a)
    };
    zt.prototype.If = function() {
        return Zm(this, Ys, 11)
    };
    zt.prototype.rg = function(a) {
        return bn(this, Ys, 11, a)
    };
    zt.V = "ads.branding.measurement.client.frontend.integrations.reach.ReachStatusMessage";
    zt.prototype.O = to([0, ko, fo, -1, ko, -2, fo, -1, ao, fo, at, lo, ao]);
    var Dt = function(a) {
            this.context = a;
            this.points = []
        },
        Et = function(a, b) {
            Ha(function(c) {
                if (c.u == 1) return c.wa = 0, c.Fa = 2, va(c, b(), 4);
                if (c.u != 2) return c.return(c.ba);
                ya(c);
                a.flush();
                return za(c, 0)
            })
        };
    Dt.prototype.flush = function() {
        if (!(this.points.length <= 0)) {
            var a = new zt;
            At(a, 9);
            var b = xt().length;
            Km(a, 13, b == null ? b : ml(b));
            kn(a, 12, this.points);
            this.points.splice(0);
            wt(this.context, a)
        }
    };

    function Ft() {
        this.blockSize = -1
    };

    function Gt(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.Vc = Oa.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.zd = this.Fb = 0;
        this.C = [];
        this.gi = a;
        this.Uf = b;
        this.Ui = Oa.Int32Array ? new Int32Array(64) : Array(64);
        Ht === void 0 && (Ht = Oa.Int32Array ? new Int32Array(It) : It);
        this.reset()
    }
    Ua(Gt, Ft);
    for (var Jt = [], Kt = 0; Kt < 63; Kt++) Jt[Kt] = 0;
    var Lt = [].concat(128, Jt);
    Gt.prototype.reset = function() {
        this.zd = this.Fb = 0;
        this.C = Oa.Int32Array ? new Int32Array(this.Uf) : Ob(this.Uf)
    };
    var Mt = function(a) {
        var b = a.Vc;
        D(b.length == a.blockSize);
        for (var c = a.Ui, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
        b = a.C[0] | 0;
        d = a.C[1] | 0;
        e = a.C[2] | 0;
        for (var f = a.C[3] | 0, g = a.C[4] | 0, h = a.C[5] | 0, k = a.C[6] | 0, l = a.C[7] | 0, m = 0; m < 64; m++) {
            var u = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                r = (l + ((g >>> 6 | g << 26) ^ (g >>> 11 |
                    g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^ ~g & k) + (Ht[m] | 0) | 0) + (c[m] | 0) | 0) | 0;
            l = k;
            k = h;
            h = g;
            g = f + r | 0;
            f = e;
            e = d;
            d = b;
            b = r + u | 0
        }
        a.C[0] = a.C[0] + b | 0;
        a.C[1] = a.C[1] + d | 0;
        a.C[2] = a.C[2] + e | 0;
        a.C[3] = a.C[3] + f | 0;
        a.C[4] = a.C[4] + g | 0;
        a.C[5] = a.C[5] + h | 0;
        a.C[6] = a.C[6] + k | 0;
        a.C[7] = a.C[7] + l | 0
    };
    Gt.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.Fb;
        if (typeof a === "string")
            for (; c < b;) this.Vc[d++] = a.charCodeAt(c++), d == this.blockSize && (Mt(this), d = 0);
        else if (Ra(a))
            for (; c < b;) {
                var e = a[c++];
                if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("Ma");
                this.Vc[d++] = e;
                d == this.blockSize && (Mt(this), d = 0)
            } else throw Error("Na");
        this.Fb = d;
        this.zd += b
    };
    Gt.prototype.digest = function() {
        var a = [],
            b = this.zd * 8;
        this.Fb < 56 ? this.update(Lt, 56 - this.Fb) : this.update(Lt, this.blockSize - (this.Fb - 56));
        for (var c = 63; c >= 56; c--) this.Vc[c] = b & 255, b /= 256;
        Mt(this);
        for (c = b = 0; c < this.gi; c++)
            for (var d = 24; d >= 0; d -= 8) a[b++] = this.C[c] >> d & 255;
        return a
    };
    var It = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        Ht;

    function Nt() {
        Gt.call(this, 8, Ot)
    }
    Ua(Nt, Gt);
    var Ot = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var oo = function(a) {
        ro.call(this, a)
    };
    q(oo, ro);
    oo.V = "EventIdMessage";
    var Pt = function(a) {
        ro.call(this, a)
    };
    q(Pt, ro);
    Pt.prototype.Sb = function(a) {
        return gn(this, 4, a)
    };
    Pt.prototype.Kf = function() {
        return Pm(this, 8, kl, void 0 === Qk ? 2 : 4)
    };
    Pt.prototype.ff = function(a) {
        return kn(this, 8, a)
    };
    Pt.prototype.sg = function(a) {
        return fn(this, 9, a)
    };
    Pt.V = "ads.branding.measurement.client.frontend.integrations.reach.ContextIdMessage";
    var Qt = [0, Yn, co, -1];
    oo.prototype.O = to(Qt);
    Pt.prototype.O = to([0, Qt, eo, -1, io, -3, mo, eo]);
    var no = function(a) {
        ro.call(this, a, 1)
    };
    q(no, ro);
    no.V = "proto2.bridge.MessageSet";
    var Rt = {};
    no[Rk] = Rt;
    var St = so(oo, Qt);
    Rt[4156379] = {
        Kj: new po
    };
    var Tt = function() {
        var a;
        this.message = a = a === void 0 ? new Pt : a
    };
    Tt.prototype.Gc = function(a) {
        var b = this.message;
        a = St(Wh(a));
        this.message = bn(b, oo, 1, a);
        return this
    };
    var Ut = function(a, b) {
        var c = fn(a.message, 2, b.Ab === 2);
        b = fn(c, 3, !b.Fc);
        a.message = b;
        return a
    };
    Tt.prototype.Sb = function(a) {
        this.message = this.message.Sb(Math.max(1, a));
        return this
    };
    var Vt = function(a, b) {
            a.message = a.message.ff(b);
            return a
        },
        Wt = function(a) {
            var b = As.match(/m\d{12}/g),
                c = As.match(/\d{8}/g);
            if (b && b.length > 0) {
                b = b[0].slice(1);
                c = a.message;
                var d = Number(b.slice(0, 8));
                c = gn(c, 5, d);
                d = Number(b.slice(8, 10));
                c = gn(c, 6, d);
                b = Number(b.slice(10, 12));
                b = gn(c, 7, b);
                a.message = b;
                return a
            }
            if (c && c.length > 0) return b = gn(a.message, 5, Number(c[0])), b = Km(b, 6), b = Km(b, 7), a.message = b, a;
            As === "unreleased" && (b = Km(a.message, 5), b = gn(b, 6, 0), b = Km(b, 7), a.message = b);
            return a
        };
    Tt.prototype.encode = function() {
        var a = this.message,
            b = Uh(a.O());
        b.length > 64 && (a = a.Sb(1), b = Uh(a.O()));
        b.length > 64 && (a = Km(a, 6), b = Uh(a.O()));
        b.length > 64 && (a = Km(a, 7), b = Uh(a.O()));
        b.length > 64 && (a = Km(a, 5), b = Uh(a.O()));
        return b
    };

    function Xt(a, b) {
        if (b === void 0 || b.length === 0) return wt(a, At(new zt, 7)), [ee(0)].filter(function(d) {
            return d !== void 0
        });
        var c = ee(-2147483648);
        return c === void 0 ? [] : b.map(function(d) {
            var e = d % c;
            d !== e && wt(a, At(new zt, 6));
            return e
        })
    };

    function Yt(a, b) {
        var c = c === void 0 ? BigInt(0) : c;
        return {
            bucket: a,
            value: b ? 1 : 16384,
            filteringId: c
        }
    };

    function Zt(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        if (b.length >= 24) throw Error("Oa");
        return [96 | b.length].concat(z(b))
    }

    function $t(a) {
        if (a.length >= 24) throw Error("Pa");
        return [160 | a.length].concat(z(a.sort(bu).map(function(b) {
            return [].concat(z(b[0]), z(b[1]))
        }).flat()))
    }

    function cu(a) {
        if (a.length >= 24) throw Error("Qa");
        return [128 | a.length].concat(z(a.flat()))
    }

    function gu(a, b) {
        for (var c = []; a > 0;) c.push(Number(a % BigInt(255))), a /= BigInt(255);
        for (; c.length < b;) c.push(0);
        return c.reverse()
    }

    function bu(a, b) {
        a = a[0];
        b = b[0];
        if (a.length !== b.length) return a.length - b.length;
        for (var c = 0; c < a.length; c++)
            if (a[c] !== b[c]) return a[c] - b[c];
        return 0
    };

    function hu(a, b, c, d) {
        var e = Yt(BigInt(c), d);
        b = {
            shared_info: JSON.stringify({
                api: "shared-storage",
                report_id: "PRE_WORKLET_ERROR",
                reporting_origin: "https://www.googleadservices.com",
                scheduled_report_time: String((new Date).getUTCSeconds()),
                version: "polyfill"
            }),
            aggregation_service_payloads: [],
            context_id: b,
            aggregation_coordinator_origin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com"
        };
        d ? (b.debug_key = "0", b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0",
                debug_cleartext_payload: iu([e])
            })) :
            b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0"
            });
        try {
            var f, g;
            (f = a.global) == null || (g = f.fetch) == null || g.call(f, "https://www.googleadservices.com/.well-known/private-aggregation/report-shared-storage", {
                method: "POST",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify(b)
            }).catch(function() {})
        } catch (h) {}
    }

    function iu(a) {
        a = $t([
            [Zt("data"), cu(a.map(function(b) {
                return $t([
                    [Zt("value"), [68].concat(z(gu(BigInt(b.value), 4)))],
                    [Zt("bucket"), [80].concat(z(gu(b.bucket, 16)))],
                    [Zt("filteringId"), [68].concat(z(gu(b.filteringId, 4)))]
                ])
            }))],
            [Zt("operation"), Zt("histogram")]
        ]);
        return btoa(String.fromCharCode.apply(String, z(new Uint8Array(a))))
    };
    var ju = {},
        ku = (ju[2] = "prod", ju[1] = "canary", ju);

    function lu(a, b, c, d) {
        var e, f, g, h, k, l, m, u;
        return Ha(function(r) {
            switch (r.u) {
                case 1:
                    e = xt(c);
                    f = function(t) {
                        e.forEach(function(w) {
                            var v, x = Wt(Ut(Vt((new Tt).Gc(c.escapedQueryId), (v = c.trafficTypes) != null ? v : [0]), w)).Sb(-1).encode();
                            hu(a, x, t, w.dc)
                        })
                    };
                    g = No(a);
                    if (g instanceof Error) return f(-16), h = Ct(Bt(At(new zt, 8), g.name), g.message), wt(a, h), r.return();
                    d.points.push(7);
                    k = mu(a, c, e);
                    return va(r, c.experimentState.reachUseCreateWorklet ? nu(a, b, f) : ou(a, b, f), 2);
                case 2:
                    return l = r.ba, va(r, k, 3);
                case 3:
                    return m = r.ba,
                        d.points.push(8), u = e.map(function(t) {
                            var w, v, x;
                            return pu(a, l, t, m, (w = c.deviceType) != null ? w : 1, c.escapedQueryId, (v = c.trafficTypes) != null ? v : [0], (x = c.isProductSplitVpidLogsExperiment) != null ? x : !1, function(A) {
                                var P, S = Wt(Ut(Vt((new Tt).Gc(c.escapedQueryId), (P = c.trafficTypes) != null ? P : [0]).Sb(-1), t)).encode();
                                hu(a, S, A, t.dc)
                            })
                        }), va(r, Promise.all(u), 4);
                case 4:
                    d.points.push(9), r.u = 0
            }
        })
    }

    function ou(a, b, c) {
        var d, e, f;
        return Ha(function(g) {
            switch (g.u) {
                case 1:
                    d = a.sharedStorage;
                    if (!d) return g.return(Promise.reject(Error("Ra")));
                    wa(g, 2);
                    return va(g, d.worklet.addModule(b), 4);
                case 4:
                    g.u = 3;
                    g.wa = 0;
                    break;
                case 2:
                    e = xa(g), c(-17), f = Ct(Bt(At(new zt, 1), e.name), e.message), wt(a, f);
                case 3:
                    return g.return(d)
            }
        })
    }

    function nu(a, b, c) {
        var d, e, f;
        return Ha(function(g) {
            if (g.u == 1) {
                d = a.sharedStorage;
                if (!d) return g.return(Promise.reject(Error("Ra")));
                wa(g, 2);
                return va(g, d.createWorklet(b, {
                    dataOrigin: "script-origin"
                }), 4)
            }
            if (g.u != 2) return g.return(g.ba);
            e = xa(g);
            c(-17);
            f = Ct(Bt(At(new zt, 1), e.name), e.message);
            wt(a, f);
            return g.return(Promise.reject(e))
        })
    }

    function mu(a, b, c) {
        var d, e, f;
        return Ha(function(g) {
            if (g.u == 1) return d = [].concat(z(new Set(c.map(function(h) {
                return h.Ab
            })))), e = d.map(function(h) {
                return qu(a, b, h)
            }), va(g, Promise.all(e), 2);
            f = g.ba;
            return g.return(new Map(f.map(function(h, k) {
                return [d[k], h]
            })))
        })
    }

    function qu(a, b, c) {
        var d, e, f, g, h, k, l, m, u;
        return Ha(function(r) {
            switch (r.u) {
                case 1:
                    return e = (d = b.clientsideModelFilename) != null ? d : "model_person_country_code_XX_person_region_code_5858.json", f = void 0, g = 1, h = {
                        method: "GET"
                    }, k = 200, l = b.geoTargetMessage ? Zs(b.geoTargetMessage) : void 0, m = (new zt).Gc(b.escapedQueryId).rg(l), wa(r, 2), va(r, a.global.fetch(ru(c, e), h), 4);
                case 4:
                    f = r.ba;
                    k = f.status;
                    if (f.ok) {
                        r.Ia(5);
                        break
                    }
                    return va(r, a.global.fetch(ru(c, "model_person_country_code_XX_person_region_code_5858.json"), h), 6);
                case 6:
                    f = r.ba, g = 2;
                case 5:
                    r.u = 3;
                    r.wa = 0;
                    break;
                case 2:
                    u = xa(r), k = -1, u instanceof Error && Ct(Bt(m, u.name), u.message);
                case 3:
                    var t = At(m, 2);
                    Km(t, 9, k == null ? k : ml(k));
                    if (!f || !f.ok) return t = jn(m, 4, 4), t = hn(t, 8, e), hn(t, 7, ""), wt(a, m), r.return();
                    t = jn(m, 4, g);
                    hn(t, 7, g === 1 ? e : "");
                    wt(a, m);
                    return va(r, f.text(), 7);
                case 7:
                    return r.return(r.ba)
            }
        })
    }

    function ru(a, b) {
        return "https://www.googletagservices.com/agrp/" + ku[a] + "/" + b
    }

    function pu(a, b, c, d, e, f, g, h, k) {
        var l, m, u, r, t, w, v;
        return Ha(function(x) {
            switch (x.u) {
                case 1:
                    l = d.get(c.Ab);
                    if (l === void 0) return x.return();
                    var A = ee(-2147483648);
                    if (A === void 0) A = -1;
                    else {
                        var P = Number,
                            S = new Nt;
                        S.update(l);
                        var la = S.digest();
                        S = BigInt(0);
                        la = y(la);
                        for (var H = la.next(); !H.done; H = la.next()) S = (S * BigInt(256) + BigInt(H.value)) % A;
                        A = P(S)
                    }
                    m = A;
                    A = Wt(Ut(Vt((new Tt).Gc(f), g), c).Sb(m));
                    A.message = A.message.sg(h);
                    u = A.encode();
                    r = {
                        contextId: u,
                        aggregationCoordinatorOrigin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
                        filteringIdMaxBytes: 4
                    };
                    t = {
                        modelJson: l,
                        modelHash: m,
                        deviceType: e,
                        enableDebugMode: c.dc,
                        reportBrowserIdInsteadOfVPID: c.Fc,
                        filterIds: Xt(a, c.filterIds)
                    };
                    w = b.run("google_reach", {
                        privateAggregationConfig: r,
                        data: t,
                        keepAlive: !0
                    });
                    if (w === void 0) {
                        x.Ia(2);
                        break
                    }
                    wa(x, 3);
                    return va(x, w, 5);
                case 5:
                    x.u = 2;
                    x.wa = 0;
                    break;
                case 3:
                    v = xa(x), k(-18), A = v, la = Ct(Bt(At(new zt, 3), (P = A == null ? void 0 : A.name) != null ? P : "unknown"), (S = A == null ? void 0 : A.message) != null ? S : ""), wt(a, la);
                case 2:
                    A = At(new zt, 5), A = jn(A, 5, c.Ab === 1 ? 1 : 2), A = jn(A, 6, c.Fc ?
                        1 : 2), wt(a, A), x.u = 0
            }
        })
    };
    var su = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.De = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "reach";
        this.Bc = new Map
    };
    n = su.prototype;
    n.start = function(a) {
        a.P && (this.context = a.P)
    };
    n.dispose = function() {
        this.Bc.forEach(function(a) {
            return void a.dispose()
        });
        this.Bc.clear()
    };
    n.he = function(a, b, c, d, e) {
        var f = this,
            g = this.context;
        if (g) {
            var h = new Dt(g);
            Et(h, function() {
                var k, l, m, u;
                return Ha(function(r) {
                    if (r.u == 1) {
                        h.points.push(1);
                        if (Mm(b, $s, 1) && !ft(b).de()) return r.return();
                        h.points.push(2);
                        return No(g) ? va(r, jd(vt(g)), 2) : r.return()
                    }
                    if (r.u != 3) {
                        k = r.ba;
                        if (!k) return r.return();
                        h.points.push(3);
                        l = new tu(g, b, f.De, c, d, h);
                        f.Bc.set(a, l);
                        return va(r, l.run(), 3)
                    }
                    e((u = (m = ft(b)) == null ? void 0 : m.ed()) != null ? u : -1);
                    r.u = 0
                })
            })
        }
    };
    n.Cb = function(a) {
        var b;
        (b = this.Bc.get(a)) == null || b.dispose();
        this.Bc.delete(a)
    };
    n.handleEvent = function() {};
    var tu = function(a, b, c, d, e, f) {
        this.context = a;
        this.metadata = b;
        this.De = c;
        this.experimentState = d;
        this.Oa = e;
        this.Sd = f
    };
    tu.prototype.run = function() {
        var a = this,
            b, c;
        return Ha(function(d) {
            if (d.u == 1) return b = {}, va(d, new Promise(function(e) {
                a.Oa(a.De, b, e)
            }), 2);
            c = d.ba;
            if (!c) return d.return();
            a.Sd.points.push(4);
            return va(d, uu(a), 0)
        })
    };
    var uu = function(a) {
            var b, c, d, e, f, g, h, k, l, m, u, r, t, w, v, x, A, P;
            return Ha(function(S) {
                var la = a.experimentState,
                    H = (l = (b = ft(a.metadata)) == null ? void 0 : b.Gf()) != null ? l : "",
                    C = (m = (c = ft(a.metadata)) == null ? void 0 : c.Kf()) != null ? m : void 0,
                    da = (d = ft(a.metadata)) == null ? void 0 : sl(Im(d, 1)),
                    Cc = (u = (e = ft(a.metadata)) == null ? void 0 : (f = e.If()) == null ? void 0 : f.Ta()) != null ? u : void 0,
                    fc = (r = (g = ft(a.metadata)) == null ? void 0 : dn(g, 8)) != null ? r : void 0,
                    pd = vu;
                var Ma = (h = ft(a.metadata)) == null ? void 0 : Pm(h, 5, nl, Qk === Qk ? 2 : 4);
                pd = pd(a, (t = Ma) != null ?
                    t : void 0);
                Ma = vu;
                var vg = (k = ft(a.metadata)) == null ? void 0 : Pm(k, 6, nl, Qk === Qk ? 2 : 4);
                v = {
                    experimentState: la,
                    escapedQueryId: H,
                    trafficTypes: C,
                    isProductSplitVpidLogsExperiment: !0,
                    clientsideModelFilename: da,
                    geoTargetMessage: Cc,
                    deviceType: fc,
                    productionFilterIds: pd,
                    testFilterIds: Ma(a, (w = vg) != null ? w : void 0)
                };
                if (a.experimentState.reachUseCreateWorklet) return P = a.context.Le[2], a.Sd.points.push(10), va(S, lu(a.context, P, v, a.Sd), 0);
                x = a.context.Le[0];
                A = btoa(JSON.stringify(v));
                return va(S, vi(a.context.document, x, A), 0)
            })
        },
        vu = function(a, b) {
            if (b !== void 0) return b.map(function(c) {
                var d;
                return String((d = ee(c)) != null ? d : 0)
            })
        };
    tu.prototype.dispose = function() {};
    var wu = Jf("m202511050101".match(/^m\d{10}$/g) !== null ? "m202511050101" : "current"),
        xu;
    a: {
        try {
            var yu = new mg;
            xu = new Lf(yu, "doubleclickbygoogle.com-omid", void 0, wu);
            break a
        } catch (a) {}
        xu = void 0
    }
    var zu = xu,
        Au = {
            P: new Mo(void 0, void 0, void 0, wu),
            na: zu
        };
    (function(a) {
        if (a && Bg(a)) {
            var b = Ag(a);
            if (b) {
                a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-start2", {
                    method: "GET",
                    cache: "no-cache",
                    keepalive: !0,
                    mode: "no-cors"
                });
                try {
                    b("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-later2", {
                        method: "GET",
                        cache: "no-cache",
                        mode: "no-cors",
                        activateAfter: 96E4
                    })
                } catch (c) {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-fallback2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                }
                a.ig.subscribe(function() {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-pagehide2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                })
            }
        }
    })(Au.P);
    (function(a, b, c) {
        var d = new Ns("impression"),
            e = new Ns("begin to render"),
            f = new Ns("unmeasurable"),
            g = new Ns("viewable"),
            h = new Ns("reach vpid"),
            k = new Ls(d, h, e, g, f),
            l = new kt,
            m = new st(d.event);
        b = new ot(l, c, d.event, e.event, f.event, g.event, b);
        h = new su(h.event);
        var u = new Os(a, k, l, m, b, h);
        u.start();
        return {
            dispose: function() {
                return void u.dispose()
            },
            colleagues: {
                Fj: m,
                gk: b,
                ck: h
            }
        }
    })(Au, 7);
}).call(this);